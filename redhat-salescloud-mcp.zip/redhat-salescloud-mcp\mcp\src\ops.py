"""High-level Sales Cloud operations used by the MCP server and CLI."""

from __future__ import annotations

import json
from typing import Any

from .auth import AuthRequired, get_auth
from .salesforce import (
    SessionExpired,
    extract_salesforce_id,
    flatten_record,
    infer_sobject,
)

AUTH_HINT = (
    "Call salescloud_auth so the associate can sign in with Red Hat SSO + FreeOTP "
    "in Chrome, then retry."
)

DEFAULT_OPP_FIELDS = (
    "Id, Name, AccountId, Account.Name, StageName, Amount, CloseDate, "
    "OwnerId, Owner.Name, Probability, Type, NextStep, LastModifiedDate, "
    "IsClosed, IsWon, ForecastCategoryName, Description"
)
MIN_OPP_FIELDS = "Id, Name, StageName, Amount, CloseDate, Owner.Name, Account.Name, IsClosed"

DEFAULT_ACCOUNT_FIELDS = (
    "Id, Name, Type, Industry, Phone, Website, Owner.Name, BillingCity, "
    "BillingCountry, BillingState, Description"
)
MIN_ACCOUNT_FIELDS = "Id, Name, Type, Phone, Website, Owner.Name"

DEFAULT_CONTACT_FIELDS = (
    "Id, Name, FirstName, LastName, Email, Title, Phone, MobilePhone, "
    "AccountId, Account.Name, Owner.Name"
)
MIN_CONTACT_FIELDS = "Id, Name, Email, Title, Phone, Account.Name"

DEFAULT_LEAD_FIELDS = (
    "Id, Name, Company, Email, Title, Phone, Status, LeadSource, Owner.Name, CreatedDate"
)
MIN_LEAD_FIELDS = "Id, Name, Company, Email, Status, Owner.Name"


def _soql_escape(value: str) -> str:
    return (value or "").replace("\\", "\\\\").replace("'", "\\'")


def _sosl_escape(value: str) -> str:
    # SOSL FIND { } — escape reserved braces and logical operators crudely
    text = (value or "").strip()
    for ch in ("\\", "{", "}", "'", '"'):
        text = text.replace(ch, " ")
    return " ".join(text.split())


async def with_client(coro_fn):
    auth = get_auth()
    try:
        client = await auth.ensure_client()
        return await coro_fn(client)
    except SessionExpired:
        auth.clear_client()
        try:
            client = await auth.ensure_client()
            return await coro_fn(client)
        except (SessionExpired, AuthRequired) as e:
            raise AuthRequired(str(e) if str(e) else AUTH_HINT) from e


async def whoami() -> dict[str, Any]:
    """Return identity from a valid saved session. Does not open Chrome."""
    auth = get_auth()
    session = await auth.probe_saved_session()
    if not session:
        raise AuthRequired(
            "Not signed in to Red Hat Sales Cloud as an associate. Call "
            "salescloud_auth, complete associate SSO + FreeOTP in Chrome, then retry."
        )
    return {
        "name": session.get("name"),
        "username": session.get("username") or session.get("preferred_username"),
        "email": session.get("email"),
        "user_id": session.get("user_id"),
        "org_id": session.get("organization_id"),
        "instance_url": session.get("instance_url"),
        "captured_at": session.get("captured_at"),
        "checked_at": session.get("checked_at"),
    }


def _current_user_id() -> str:
    session = get_auth().load_session() or {}
    uid = session.get("user_id")
    if not uid:
        raise RuntimeError("Could not resolve current Salesforce user id. Call salescloud_auth first.")
    return str(uid)


async def run_query(soql: str) -> dict[str, Any]:
    async def _go(client):
        result = await client.query(soql)
        result["records"] = [flatten_record(r) for r in result.get("records") or []]
        return result

    return await with_client(_go)


async def run_search(query: str, limit: int = 25) -> dict[str, Any]:
    find = _sosl_escape(query)
    if not find:
        raise ValueError("Search query is empty")
    limit = max(1, min(int(limit or 25), 50))
    sosl = (
        f"FIND {{{find}}} IN ALL FIELDS RETURNING "
        f"Account(Id, Name, Type, Owner.Name LIMIT {limit}), "
        f"Contact(Id, Name, Email, Title, Account.Name LIMIT {limit}), "
        f"Opportunity(Id, Name, StageName, Amount, CloseDate, Account.Name LIMIT {limit}), "
        f"Lead(Id, Name, Company, Email, Status LIMIT {limit})"
    )

    async def _go(client):
        result = await client.search(sosl)
        raw_records = result.get("searchRecords") or []
        grouped: dict[str, list] = {"Account": [], "Contact": [], "Opportunity": [], "Lead": [], "Other": []}
        flat_records = []
        for rec in raw_records:
            obj = None
            if isinstance(rec, dict) and isinstance(rec.get("attributes"), dict):
                obj = rec["attributes"].get("type")
            rec = flatten_record(rec)
            if not obj:
                obj = infer_sobject(str(rec.get("Id") or "")) or "Other"
            rec["_object"] = obj
            rec["_url"] = _record_url(obj, rec.get("Id")) if obj != "Other" else None
            grouped.setdefault(obj, []).append(rec)
            flat_records.append(rec)
        return {"query": query, "records": flat_records, "grouped": grouped}

    return await with_client(_go)


async def get_record(record_id: str, object_name: str | None = None) -> dict[str, Any]:
    rid = extract_salesforce_id(record_id)
    obj = object_name or infer_sobject(rid)
    if not obj:
        raise ValueError(
            f"Could not infer Salesforce object from '{record_id}'. "
            "Pass object_name (Account, Opportunity, Contact, Lead, …)."
        )

    async def _go(client):
        return flatten_record(await client.get_sobject(obj, rid))

    data = await with_client(_go)
    data["_object"] = obj
    data["_id"] = rid
    data["_url"] = _record_url(obj, rid)
    return data


async def describe_object(object_name: str) -> dict[str, Any]:
    async def _go(client):
        return await client.describe(object_name)

    return await with_client(_go)


async def get_report(report_id: str) -> dict[str, Any]:
    rid = extract_salesforce_id(report_id)

    async def _go(client):
        raw = await client.get_report(rid, include_details=True)
        return _summarize_report(raw, rid)

    return await with_client(_go)


def _summarize_report(raw: Any, report_id: str) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {"report_id": report_id, "raw": raw}
    meta = raw.get("reportMetadata") or {}
    ext = raw.get("reportExtendedMetadata") or {}
    col_info = ext.get("detailColumnInfo") or {}
    detail_cols = meta.get("detailColumns") or list(col_info.keys())
    rows: list[dict[str, Any]] = []
    for _key, block in (raw.get("factMap") or {}).items():
        for row in block.get("rows") or []:
            cells = row.get("dataCells") or []
            record: dict[str, Any] = {}
            for idx, col in enumerate(detail_cols):
                label_name = (col_info.get(col) or {}).get("label") or col
                val: Any = ""
                if idx < len(cells):
                    cell = cells[idx]
                    val = cell.get("label")
                    if val in (None, ""):
                        val = cell.get("value")
                record[label_name] = val
            if any(v not in (None, "") for v in record.values()):
                rows.append(record)
    return {
        "report_id": report_id,
        "name": meta.get("name") or raw.get("attributes", {}).get("reportName"),
        "developer_name": meta.get("developerName"),
        "detail_columns": detail_cols,
        "row_count": len(rows),
        "rows": rows[:500],
        "rows_truncated": max(len(rows) - 500, 0),
    }


async def list_opportunities(
    *,
    mine: bool = True,
    open_only: bool = True,
    stage: str | None = None,
    account_name: str | None = None,
    name_contains: str | None = None,
    close_date_from: str | None = None,
    close_date_to: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    limit = max(1, min(int(limit or 50), 200))
    clauses: list[str] = []
    if open_only:
        clauses.append("IsClosed = false")
    if mine:
        clauses.append("OwnerId = :user")  # placeholder, replaced after whoami
    if stage:
        clauses.append(f"StageName = '{_soql_escape(stage)}'")
    if account_name:
        clauses.append(f"Account.Name LIKE '%{_soql_escape(account_name)}%'")
    if name_contains:
        clauses.append(f"Name LIKE '%{_soql_escape(name_contains)}%'")
    if close_date_from:
        clauses.append(f"CloseDate >= {_soql_escape(close_date_from)}")
    if close_date_to:
        clauses.append(f"CloseDate <= {_soql_escape(close_date_to)}")

    where = ""
    if clauses:
        where = " WHERE " + " AND ".join(clauses)

    async def _go(client):
        soql_where = where
        if mine:
            uid = _current_user_id()
            soql_where = soql_where.replace("OwnerId = :user", f"OwnerId = '{uid}'")
        soql = (
            f"SELECT {DEFAULT_OPP_FIELDS} FROM Opportunity{soql_where} "
            f"ORDER BY CloseDate ASC NULLS LAST LIMIT {limit}"
        )
        try:
            result = await client.query(soql)
        except RuntimeError as e:
            if "INVALID_FIELD" not in str(e) and "No such column" not in str(e):
                raise
            soql = (
                f"SELECT {MIN_OPP_FIELDS} FROM Opportunity{soql_where} "
                f"ORDER BY CloseDate ASC NULLS LAST LIMIT {limit}"
            )
            result = await client.query(soql)
        records = [flatten_record(r) for r in result.get("records") or []]
        for rec in records:
            rec["_url"] = _record_url("Opportunity", rec.get("Id"))
        return {"soql": soql, "totalSize": result.get("totalSize", len(records)), "records": records}

    return await with_client(_go)


async def get_opportunity(record_id: str, include_related: bool = True) -> dict[str, Any]:
    rid = extract_salesforce_id(record_id)
    opp = await get_record(rid, "Opportunity")
    if not include_related:
        return opp

    async def _go(client):
        related: dict[str, Any] = {}
        queries = {
            "contact_roles": (
                "SELECT Id, Role, IsPrimary, ContactId, Contact.Name, Contact.Email, Contact.Title "
                f"FROM OpportunityContactRole WHERE OpportunityId = '{rid}'"
            ),
            "line_items": (
                "SELECT Id, Quantity, UnitPrice, TotalPrice, Description, PricebookEntry.Name, "
                f"Product2.Name FROM OpportunityLineItem WHERE OpportunityId = '{rid}'"
            ),
            "activities": (
                "SELECT Id, Subject, Status, ActivityDate, Owner.Name, Description "
                f"FROM Task WHERE WhatId = '{rid}' ORDER BY ActivityDate DESC NULLS LAST LIMIT 20"
            ),
        }
        for key, soql in queries.items():
            try:
                result = await client.query(soql)
                related[key] = [flatten_record(r) for r in result.get("records") or []]
            except Exception as e:
                related[key] = {"error": str(e)}
        return related

    opp["related"] = await with_client(_go)
    return opp


async def list_accounts(
    *,
    mine: bool = False,
    name_contains: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    limit = max(1, min(int(limit or 50), 200))
    clauses: list[str] = []
    if mine:
        clauses.append("OwnerId = :user")
    if name_contains:
        clauses.append(f"Name LIKE '%{_soql_escape(name_contains)}%'")
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""

    async def _go(client):
        soql_where = where
        if mine:
            uid = _current_user_id()
            soql_where = soql_where.replace("OwnerId = :user", f"OwnerId = '{uid}'")
        soql = (
            f"SELECT {DEFAULT_ACCOUNT_FIELDS} FROM Account{soql_where} "
            f"ORDER BY LastModifiedDate DESC LIMIT {limit}"
        )
        try:
            result = await client.query(soql)
        except RuntimeError as e:
            if "INVALID_FIELD" not in str(e):
                raise
            soql = (
                f"SELECT {MIN_ACCOUNT_FIELDS} FROM Account{soql_where} "
                f"ORDER BY Name ASC LIMIT {limit}"
            )
            result = await client.query(soql)
        records = [flatten_record(r) for r in result.get("records") or []]
        for rec in records:
            rec["_url"] = _record_url("Account", rec.get("Id"))
        return {"soql": soql, "totalSize": result.get("totalSize", len(records)), "records": records}

    return await with_client(_go)


async def get_account(record_id: str, include_related: bool = True) -> dict[str, Any]:
    rid = extract_salesforce_id(record_id)
    account = await get_record(rid, "Account")
    if not include_related:
        return account

    async def _go(client):
        related: dict[str, Any] = {}
        queries = {
            "contacts": (
                f"SELECT {MIN_CONTACT_FIELDS} FROM Contact WHERE AccountId = '{rid}' "
                "ORDER BY LastModifiedDate DESC LIMIT 50"
            ),
            "opportunities": (
                f"SELECT {MIN_OPP_FIELDS} FROM Opportunity WHERE AccountId = '{rid}' "
                "ORDER BY CloseDate DESC NULLS LAST LIMIT 50"
            ),
        }
        for key, soql in queries.items():
            try:
                result = await client.query(soql)
                related[key] = [flatten_record(r) for r in result.get("records") or []]
            except Exception as e:
                related[key] = {"error": str(e)}
        return related

    account["related"] = await with_client(_go)
    return account


async def list_contacts(
    *,
    account_id: str | None = None,
    email: str | None = None,
    name_contains: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    limit = max(1, min(int(limit or 50), 200))
    clauses: list[str] = []
    if account_id:
        clauses.append(f"AccountId = '{_soql_escape(extract_salesforce_id(account_id))}'")
    if email:
        clauses.append(f"Email LIKE '%{_soql_escape(email)}%'")
    if name_contains:
        clauses.append(f"Name LIKE '%{_soql_escape(name_contains)}%'")
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""

    async def _go(client):
        soql = (
            f"SELECT {DEFAULT_CONTACT_FIELDS} FROM Contact{where} "
            f"ORDER BY LastModifiedDate DESC LIMIT {limit}"
        )
        try:
            result = await client.query(soql)
        except RuntimeError as e:
            if "INVALID_FIELD" not in str(e):
                raise
            soql = f"SELECT {MIN_CONTACT_FIELDS} FROM Contact{where} ORDER BY Name ASC LIMIT {limit}"
            result = await client.query(soql)
        records = [flatten_record(r) for r in result.get("records") or []]
        for rec in records:
            rec["_url"] = _record_url("Contact", rec.get("Id"))
        return {"soql": soql, "totalSize": result.get("totalSize", len(records)), "records": records}

    return await with_client(_go)


async def list_leads(
    *,
    mine: bool = True,
    status: str | None = None,
    name_contains: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    limit = max(1, min(int(limit or 50), 200))
    clauses: list[str] = []
    if mine:
        clauses.append("OwnerId = :user")
    if status:
        clauses.append(f"Status = '{_soql_escape(status)}'")
    if name_contains:
        clauses.append(
            f"(Name LIKE '%{_soql_escape(name_contains)}%' OR Company LIKE '%{_soql_escape(name_contains)}%')"
        )
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""

    async def _go(client):
        soql_where = where
        if mine:
            uid = _current_user_id()
            soql_where = soql_where.replace("OwnerId = :user", f"OwnerId = '{uid}'")
        soql = (
            f"SELECT {DEFAULT_LEAD_FIELDS} FROM Lead{soql_where} "
            f"ORDER BY LastModifiedDate DESC LIMIT {limit}"
        )
        try:
            result = await client.query(soql)
        except RuntimeError as e:
            if "INVALID_FIELD" not in str(e):
                raise
            soql = f"SELECT {MIN_LEAD_FIELDS} FROM Lead{soql_where} ORDER BY Name ASC LIMIT {limit}"
            result = await client.query(soql)
        records = [flatten_record(r) for r in result.get("records") or []]
        for rec in records:
            rec["_url"] = _record_url("Lead", rec.get("Id"))
        return {"soql": soql, "totalSize": result.get("totalSize", len(records)), "records": records}

    return await with_client(_go)


def _record_url(object_name: str, record_id: str | None) -> str | None:
    if not record_id:
        return None
    from .config import load_config

    lightning = load_config().lightning_url.rstrip("/")
    return f"{lightning}/lightning/r/{object_name}/{record_id}/view"


def to_text(payload: Any) -> str:
    return json.dumps(payload, indent=2, default=str)
