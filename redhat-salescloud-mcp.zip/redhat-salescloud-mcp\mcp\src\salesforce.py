"""Salesforce REST / SOQL / SOSL client using a harvested browser session id."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import quote

import httpx

def _salesforce_id(value: Any, prefix: str) -> str | None:
    """userinfo sometimes returns a full identity URL instead of a 15/18-char Id."""
    if not value:
        return None
    text = str(value).strip()
    if text.startswith(prefix) and len(text) in (15, 18):
        return text
    for part in reversed(text.rstrip("/").split("/")):
        if part.startswith(prefix) and len(part) in (15, 18):
            return part
    return text


ID_PREFIXES = {
    "001": "Account",
    "003": "Contact",
    "006": "Opportunity",
    "00Q": "Lead",
    "00T": "Task",
    "00U": "Event",
    "005": "User",
    "00O": "Report",
    "500": "Case",
    "00P": "Attachment",
    "701": "Campaign",
    "00a": "Note",
}


class SessionExpired(RuntimeError):
    """Salesforce rejected the harvested sid — user must SSO + FreeOTP again."""


def _is_session_error(status: int, body: Any) -> bool:
    if status == 401:
        return True
    if isinstance(body, list) and body:
        code = str((body[0] or {}).get("errorCode") or "")
        if code in {"INVALID_SESSION_ID", "INVALID_SESSION", "SESSION_EXPIRED"}:
            return True
    return False


async def probe_identity(instance_url: str, sid: str, api_version: str) -> dict[str, Any]:
    """Validate sid and return identity fields."""
    headers = {
        "Authorization": f"Bearer {sid}",
        "Accept": "application/json",
        "Cookie": f"sid={sid}",
    }
    instance_url = instance_url.rstrip("/")
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        r = await client.get(f"{instance_url}/services/oauth2/userinfo", headers=headers)
        body: Any
        try:
            body = r.json()
        except Exception:
            body = r.text
        if _is_session_error(r.status_code, body):
            raise SessionExpired("Salesforce session expired")
        r.raise_for_status()
        if not isinstance(body, dict):
            raise RuntimeError(f"Unexpected identity response: {body!r}")

        # Prefer REST host from userinfo when present
        rest = ((body.get("urls") or {}).get("rest") or "")
        rest_instance = instance_url
        if "/services/data/" in rest:
            rest_instance = rest.split("/services/data/")[0]

        return {
            "user_id": _salesforce_id(body.get("user_id"), "005"),
            "organization_id": _salesforce_id(body.get("organization_id"), "00D"),
            "username": body.get("preferred_username") or body.get("username"),
            "preferred_username": body.get("preferred_username"),
            "email": body.get("email"),
            "name": body.get("name"),
            "nickname": body.get("nickname"),
            "instance_url": rest_instance or instance_url,
            "userinfo": {k: v for k, v in body.items() if k != "urls"},
        }


class SalesforceClient:
    def __init__(self, instance_url: str, sid: str, api_version: str = "v62.0"):
        self.instance_url = instance_url.rstrip("/")
        self.sid = sid
        self.api_version = api_version if api_version.startswith("v") else f"v{api_version}"
        self._client = httpx.AsyncClient(timeout=60.0, follow_redirects=True)

    @property
    def headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.sid}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Cookie": f"sid={self.sid}",
        }

    def api(self, path: str) -> str:
        path = path if path.startswith("/") else f"/{path}"
        return f"{self.instance_url}/services/data/{self.api_version}{path}"

    async def request(self, method: str, url: str, **kwargs) -> Any:
        headers = dict(self.headers)
        headers.update(kwargs.pop("headers", {}) or {})
        r = await self._client.request(method, url, headers=headers, **kwargs)
        try:
            body = r.json()
        except Exception:
            body = r.text
        if _is_session_error(r.status_code, body):
            raise SessionExpired(
                "Salesforce session expired or invalid. Call salescloud_auth and "
                "complete associate SSO + FreeOTP in the Chrome window, then retry."
            )
        if r.status_code >= 400:
            raise RuntimeError(_format_sf_error(r.status_code, body))
        return body

    async def get(self, path: str, params: dict | None = None) -> Any:
        return await self.request("GET", self.api(path), params=params)

    async def query(self, soql: str) -> dict[str, Any]:
        records: list[dict[str, Any]] = []
        done = False
        path = f"/query?q={quote(soql, safe='')}"
        next_url: str | None = None
        while True:
            if next_url:
                body = await self.request("GET", f"{self.instance_url}{next_url}")
            else:
                body = await self.get(f"/query/?q={quote(soql, safe='')}")
            if not isinstance(body, dict):
                raise RuntimeError(f"Unexpected query response: {body!r}")
            records.extend(body.get("records") or [])
            done = bool(body.get("done", True))
            next_url = body.get("nextRecordsUrl")
            if done or not next_url:
                break
        return {
            "totalSize": body.get("totalSize", len(records)),
            "done": True,
            "records": _strip_attributes(records),
        }

    async def search(self, sosl: str) -> dict[str, Any]:
        body = await self.get(f"/search/?q={quote(sosl, safe='')}")
        if isinstance(body, dict) and "searchRecords" in body:
            body["searchRecords"] = _strip_attributes(body.get("searchRecords") or [])
            return body
        if isinstance(body, list):
            return {"searchRecords": _strip_attributes(body)}
        return {"searchRecords": body}

    async def get_sobject(self, object_name: str, record_id: str) -> dict[str, Any]:
        body = await self.get(f"/sobjects/{object_name}/{record_id}")
        if isinstance(body, dict):
            return _strip_attributes(body)
        return {"raw": body}

    async def describe(self, object_name: str) -> dict[str, Any]:
        body = await self.get(f"/sobjects/{object_name}/describe")
        if not isinstance(body, dict):
            return {"raw": body}
        fields = []
        for f in body.get("fields") or []:
            fields.append(
                {
                    "name": f.get("name"),
                    "label": f.get("label"),
                    "type": f.get("type"),
                    "custom": f.get("custom"),
                    "updateable": f.get("updateable"),
                    "nillable": f.get("nillable"),
                    "length": f.get("length"),
                    "referenceTo": f.get("referenceTo") or [],
                }
            )
        return {
            "name": body.get("name"),
            "label": body.get("label"),
            "keyPrefix": body.get("keyPrefix"),
            "queryable": body.get("queryable"),
            "fields": fields,
        }

    async def get_report(self, report_id: str, include_details: bool = True) -> dict[str, Any]:
        q = "?includeDetails=true" if include_details else ""
        return await self.get(f"/analytics/reports/{report_id}{q}")

    async def aclose(self) -> None:
        await self._client.aclose()


def infer_sobject(record_id: str) -> str | None:
    rid = (record_id or "").strip()
    if len(rid) in (15, 18):
        return ID_PREFIXES.get(rid[:3])
    return None


def extract_salesforce_id(value: str) -> str:
    """Accept a raw Id or a Lightning/Classic URL."""
    text = (value or "").strip()
    if not text:
        return text
    import re

    m = re.search(r"/lightning/r/[^/]+/([a-zA-Z0-9]{15,18})", text)
    if m:
        return m.group(1)
    m = re.search(r"/analytics/report/([a-zA-Z0-9]{15,18})", text, re.I)
    if m:
        return m.group(1)
    m = re.search(r"/Report/([a-zA-Z0-9]{15,18})", text)
    if m:
        return m.group(1)
    m = re.search(r"\b([a-zA-Z0-9]{15,18})\b", text)
    if m and m.group(1)[:3] in ID_PREFIXES:
        return m.group(1)
    return text


def flatten_record(record: Any) -> Any:
    if isinstance(record, list):
        return [flatten_record(x) for x in record]
    if not isinstance(record, dict):
        return record
    out: dict[str, Any] = {}
    for k, v in record.items():
        if k == "attributes":
            continue
        if isinstance(v, dict) and ("attributes" in v or any(isinstance(x, dict) for x in v.values())):
            nested = flatten_record(v)
            if isinstance(nested, dict):
                for nk, nv in nested.items():
                    out[f"{k}.{nk}"] = nv
            else:
                out[k] = nested
        else:
            out[k] = flatten_record(v) if isinstance(v, (dict, list)) else v
    return out


def _strip_attributes(obj: Any) -> Any:
    if isinstance(obj, list):
        return [_strip_attributes(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _strip_attributes(v) for k, v in obj.items() if k != "attributes"}
    return obj


def _format_sf_error(status: int, body: Any) -> str:
    if isinstance(body, list) and body and isinstance(body[0], dict):
        parts = []
        for item in body[:5]:
            code = item.get("errorCode") or item.get("statusCode") or ""
            msg = item.get("message") or json.dumps(item)
            parts.append(f"{code}: {msg}" if code else str(msg))
        return f"Salesforce error {status}: " + " | ".join(parts)
    if isinstance(body, dict):
        return f"Salesforce error {status}: {body.get('message') or body}"
    return f"Salesforce error {status}: {body}"
