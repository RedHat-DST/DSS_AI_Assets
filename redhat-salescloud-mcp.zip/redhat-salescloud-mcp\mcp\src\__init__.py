"""Red Hat Sales Cloud assistant — Salesforce REST via a persistent SSO browser session."""
