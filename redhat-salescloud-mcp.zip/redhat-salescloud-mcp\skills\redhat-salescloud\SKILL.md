---
name: redhat-salescloud
description: >-
  Query Red Hat Sales Cloud (Salesforce / redhatcrm) as a signed-in Red Hat
  associate via the salescloud-assistant MCP: accounts, contacts, leads,
  opportunities, SOQL, SOSL, reports. Use when the associate asks about pipeline,
  opportunities, accounts, Salesforce, Sales Cloud, or CRM records. Auth is
  associate SSO (auth.redhat.com) + FreeOTP; sessions expire often.
---

# Red Hat Sales Cloud MCP (associate session)

The signed-in user is a **Red Hat associate**. Use the **salescloud-assistant** MCP (`salescloud_*` tools). Same idea as Gmail/Drive/Calendar, except auth is associate SSO + FreeOTP in a persistent Chrome window — not OAuth, and not a Salesforce username/password.

“My pipeline / my accounts / my leads” means the **associate’s** records in redhatcrm.

## Auth (first request, and whenever a tool says the session expired)

1. Call `salescloud_auth` with `wait=true`.
2. Tell the associate a **Chrome window is open**. They sign in with their **Red Hat associate account** (auth.redhat.com, same as other internal apps) and enter **FreeOTP**.
3. Wait until the tool returns their Salesforce user (`@redhat.com`). Then retry the original request.
4. Never ask for a password, OTP, or kerberos password in chat.

They must already have Sales Cloud access. This MCP does not grant CRM access.

Chrome stays open on purpose. Later logouts are “same window, FreeOTP again”.

If auth says login required while Lightning is already visible: `salescloud_auth` with `force=true`.

## Tools

| Need | Tool |
|------|------|
| Login / re-login | `salescloud_auth` |
| Who am I? | `salescloud_whoami` |
| Find a company / person / deal | `salescloud_search` |
| My pipeline | `salescloud_list_opportunities` (`mine=true`, `open_only=true`) |
| One deal | `salescloud_get_opportunity` (Id or Lightning URL) |
| Account | `salescloud_get_account` / `salescloud_list_accounts` |
| Contact / lead | `salescloud_list_contacts`, `salescloud_get_contact`, `salescloud_list_leads` |
| Custom fields / SOQL | `salescloud_describe` then `salescloud_query` |
| Report | `salescloud_get_report` |

Prefer search / list / get tools before raw SOQL. Pass Lightning URLs; the MCP extracts the Id.

## Org

- REST: `https://redhatcrm.my.salesforce.com`
- Lightning: `https://redhatcrm.lightning.force.com`

Read-only. Do not update Salesforce records.
