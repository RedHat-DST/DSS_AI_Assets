"""SSO session for Red Hat Sales Cloud.

Unlike Gmail/Drive (OAuth refresh tokens), Sales Cloud sits behind Red Hat SSO
and FreeOTP. Sessions expire often. Auth therefore:

1. Opens (or reconnects to) a persistent Chrome window
2. Lets you complete SSO + FreeOTP in that window
3. Harvests the Salesforce `sid` cookie for REST API calls
4. Leaves Chrome running so the next login is faster
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Optional

from .chrome import (
    connect_over_cdp,
    disconnect_leave_chrome,
    instance_from_url,
    is_login_url,
    log,
    looks_logged_in,
    pick_best_page_sync,
    sid_from_cookies,
    spawn_chrome_cdp,
)
from .config import SalesCloudConfig, load_config
from .salesforce import SalesforceClient, SessionExpired, probe_identity

AUTH_INSTRUCTIONS = (
    "Red Hat associate login required for Sales Cloud.\n\n"
    "A Chrome window is open. Sign in with your Red Hat associate account "
    "(SSO at auth.redhat.com — same as other internal apps) and enter your "
    "FreeOTP code. Wait until redhatcrm Lightning loads, not the IdP page.\n\n"
    "This MCP uses your associate session. You must already have Sales Cloud "
    "access; it does not grant CRM access. Never paste your associate password "
    "or OTP into chat.\n\n"
    "Then call salescloud_auth again. Chrome stays open so later FreeOTP "
    "prompts are faster when Sales Cloud kicks you out."
)


class AuthRequired(RuntimeError):
    """Raised when the agent/user must complete SSO + FreeOTP."""

    def __init__(self, message: str = AUTH_INSTRUCTIONS):
        super().__init__(message)


class SalesCloudAuth:
    def __init__(self, config: Optional[SalesCloudConfig] = None):
        self.config = config or load_config()
        self._session: dict | None = None
        self._client: SalesforceClient | None = None

    def session_path(self):
        return self.config.session_file

    def load_session(self) -> dict | None:
        path = self.session_path()
        if not path.exists():
            self._session = None
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            self._session = None
            return None
        if not isinstance(data, dict) or not data.get("sid"):
            self._session = None
            return None
        self._session = data
        return data

    def save_session(self, session: dict) -> None:
        path = self.session_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(session, indent=2), encoding="utf-8")
        try:
            path.chmod(0o600)
        except Exception:
            pass
        self._session = session
        self._client = None

    def clear_client(self) -> None:
        self._client = None

    async def probe_saved_session(self) -> dict | None:
        session = self.load_session()
        if not session:
            return None
        try:
            identity = await probe_identity(
                instance_url=session.get("instance_url") or self.config.instance_url,
                sid=session["sid"],
                api_version=self.config.api_version,
            )
        except SessionExpired:
            return None
        except Exception as e:
            log(f"Session probe failed: {e}")
            return None
        session.update(identity)
        session["checked_at"] = datetime.now(timezone.utc).isoformat()
        self.save_session(session)
        return session

    async def harvest_from_chrome(self, *, navigate: bool, wait: bool) -> dict:
        """Open/reconnect Chrome, optionally wait for SSO, harvest sid."""
        try:
            from playwright.async_api import async_playwright
        except ImportError as e:
            raise RuntimeError(
                "playwright is not installed. From salescloud-assistant run:\n"
                "  python3 -m venv .venv && .venv/bin/pip install -r requirements.txt\n"
                "  .venv/bin/playwright install chromium"
            ) from e

        spawn_chrome_cdp(self.config.profile, self.config.cdp_port)
        browser = None
        async with async_playwright() as p:
            try:
                browser, context, page = await connect_over_cdp(p, self.config.cdp_port)
                if navigate:
                    log(f"Opening Sales Cloud -> {self.config.start_url}")
                    try:
                        await page.goto(
                            self.config.start_url,
                            wait_until="domcontentloaded",
                            timeout=120_000,
                        )
                    except Exception as e:
                        log(f"Initial goto warning: {e} (complete login in Chrome)")
                    await page.wait_for_timeout(1500)

                logged_in = await looks_logged_in(page)
                if not logged_in and wait:
                    logged_in = await self._wait_for_login(context, page)
                    page = pick_best_page_sync(list(context.pages)) or page

                if not logged_in:
                    raise AuthRequired()

                cookies = await context.cookies()
                sid, cookie_domain = sid_from_cookies(cookies)
                if not sid:
                    raise AuthRequired(
                        "Logged into Lightning but no Salesforce sid cookie was found. "
                        "Finish loading Sales Cloud, then call salescloud_auth again."
                    )

                page_url = ""
                try:
                    page_url = page.url or ""
                except Exception:
                    pass
                instance = instance_from_url(page_url, self.config.instance_url)
                if cookie_domain and cookie_domain.endswith(".my.salesforce.com"):
                    instance = f"https://{cookie_domain}"
                elif cookie_domain and cookie_domain.endswith(".lightning.force.com"):
                    instance = instance_from_url(f"https://{cookie_domain}", instance)

                identity = await probe_identity(
                    instance_url=instance,
                    sid=sid,
                    api_version=self.config.api_version,
                )
                session = {
                    "sid": sid,
                    "instance_url": identity.get("instance_url") or instance,
                    "lightning_url": self.config.lightning_url,
                    "page_url": page_url,
                    "cookie_domain": cookie_domain,
                    "captured_at": datetime.now(timezone.utc).isoformat(),
                    **identity,
                }
                self.save_session(session)
                log(f"Harvested Sales Cloud session for {session.get('username') or session.get('name') or 'user'}")
                return session
            finally:
                if browser is not None:
                    await disconnect_leave_chrome(browser)

    async def _wait_for_login(self, context, page) -> bool:
        timeout = self.config.login_timeout_seconds
        ready_path = self.config.profile / "user_ready"
        log("=" * 60)
        log("ACTION REQUIRED — RED HAT ASSOCIATE SSO + FreeOTP")
        log("1. In the Chrome window, sign in with your Red Hat associate account.")
        log("2. Enter your FreeOTP code (same token as other Red Hat apps).")
        log("3. Wait until redhatcrm Lightning is visible.")
        log(f"   Auto-detect timeout: {timeout}s")
        log(f"   Or create this file to continue: {ready_path}")
        log("=" * 60)

        deadline = asyncio.get_event_loop().time() + timeout
        while asyncio.get_event_loop().time() < deadline:
            page = pick_best_page_sync(list(context.pages)) or page
            try:
                if await looks_logged_in(page):
                    log(f"Login detected -> {page.url}")
                    return True
            except Exception:
                pass
            if ready_path.exists():
                try:
                    ready_path.unlink()
                except Exception:
                    pass
                log("Ready sentinel seen — harvesting session.")
                return True
            await asyncio.sleep(2)
        return False

    async def authenticate(self, *, force_login: bool = False, wait: bool = False) -> dict:
        """Return a valid session, opening Chrome / waiting for SSO as needed."""
        if not force_login:
            session = await self.probe_saved_session()
            if session:
                return session
            # Saved sid is dead — Chrome may already be re-logged in.
            try:
                return await self.harvest_from_chrome(navigate=True, wait=False)
            except AuthRequired:
                if not wait:
                    raise
            except Exception as e:
                log(f"Harvest without wait failed: {e}")
                if not wait:
                    raise AuthRequired(f"{AUTH_INSTRUCTIONS}\n\nDetails: {e}") from e

        return await self.harvest_from_chrome(navigate=True, wait=True)

    async def ensure_client(self) -> SalesforceClient:
        session = await self.authenticate(wait=False)
        if self._client is None:
            self._client = SalesforceClient(
                instance_url=session["instance_url"],
                sid=session["sid"],
                api_version=self.config.api_version,
            )
        return self._client

    def status_dict(self) -> dict:
        session = self.load_session() or {}
        return {
            "authenticated": bool(session.get("sid")),
            "username": session.get("username") or session.get("preferred_username"),
            "name": session.get("name"),
            "email": session.get("email"),
            "user_id": session.get("user_id"),
            "org_id": session.get("organization_id"),
            "instance_url": session.get("instance_url") or self.config.instance_url,
            "captured_at": session.get("captured_at"),
            "checked_at": session.get("checked_at"),
            "chrome_cdp_alive": _cdp_status(self.config.cdp_port),
            "cdp_port": self.config.cdp_port,
        }


def _cdp_status(port: int) -> bool:
    from .chrome import cdp_alive

    return cdp_alive(port)


_default_auth: Optional[SalesCloudAuth] = None


def get_auth() -> SalesCloudAuth:
    global _default_auth
    if _default_auth is None:
        _default_auth = SalesCloudAuth()
    return _default_auth
