"""Local configuration for Red Hat Sales Cloud."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_FILE = PROJECT_ROOT / "config.json"
DEFAULT_PROFILE = PROJECT_ROOT / "profiles" / "default"
DEFAULT_SESSION_FILE = PROJECT_ROOT / "session.json"

DEFAULTS = {
    "instance_url": "https://redhatcrm.my.salesforce.com",
    "lightning_url": "https://redhatcrm.lightning.force.com",
    "start_url": "https://redhatcrm.lightning.force.com/lightning/page/home",
    "cdp_port": 9223,
    "login_timeout_seconds": 600,
    "api_version": "v62.0",
}


@dataclass
class SalesCloudConfig:
    instance_url: str
    lightning_url: str
    start_url: str
    cdp_port: int
    login_timeout_seconds: int
    api_version: str
    profile: Path
    session_file: Path


def load_config() -> SalesCloudConfig:
    data = dict(DEFAULTS)
    if DEFAULT_CONFIG_FILE.exists():
        try:
            loaded = json.loads(DEFAULT_CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                data.update({k: v for k, v in loaded.items() if v is not None})
        except Exception:
            pass

    instance = os.environ.get("SALESCLOUD_INSTANCE_URL") or data["instance_url"]
    lightning = os.environ.get("SALESCLOUD_LIGHTNING_URL") or data["lightning_url"]
    start_url = os.environ.get("SALESCLOUD_START_URL") or data["start_url"]
    port = int(os.environ.get("SALESCLOUD_CDP_PORT") or data["cdp_port"])
    timeout = int(os.environ.get("SALESCLOUD_LOGIN_TIMEOUT") or data["login_timeout_seconds"])
    version = os.environ.get("SALESCLOUD_API_VERSION") or data["api_version"]
    profile = Path(os.environ.get("SALESCLOUD_PROFILE") or DEFAULT_PROFILE).expanduser().resolve()
    session_file = Path(os.environ.get("SALESCLOUD_SESSION_FILE") or DEFAULT_SESSION_FILE).expanduser().resolve()

    instance = instance.rstrip("/")
    lightning = lightning.rstrip("/")
    if not version.startswith("v"):
        version = f"v{version}"

    return SalesCloudConfig(
        instance_url=instance,
        lightning_url=lightning,
        start_url=start_url,
        cdp_port=port,
        login_timeout_seconds=timeout,
        api_version=version,
        profile=profile,
        session_file=session_file,
    )
