"""Persistent Chrome via CDP — same idea as the Red Hat web scraper.

Chrome is launched in its own process group and left running. Later MCP
calls reconnect. The Red Hat associate completes SSO (auth.redhat.com) +
FreeOTP in that window whenever Sales Cloud logs them out.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

LOGIN_URL_HINTS = (
    "login.",
    "/login",
    "/signin",
    "/sign-in",
    "/sso",
    "idp.",
    "sso.",
    "okta.com",
    "microsoftonline.com",
    "accounts.google.com",
    "login.salesforce.com",
    "test.salesforce.com",
    "auth.redhat.com",
    "/saml/samlerror",
)

AUTH_FORM_SELECTORS = (
    "input[type='password']",
    "input[name='password']",
    "input[autocomplete='current-password']",
    "#password",
)

LIGHTNING_SELECTORS = (
    "one-appnav",
    ".slds-global-header",
    "[data-aura-class='navexAppNavBar']",
    "div.slds-global-header",
    "one-app-nav-bar",
)


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def cdp_endpoint(port: int) -> str:
    return f"http://127.0.0.1:{port}"


def cdp_alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(cdp_endpoint(port) + "/json/version", timeout=1.5) as resp:
            return resp.status == 200
    except Exception:
        return False


def chrome_executable() -> Path:
    chrome_app = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
    if chrome_app.exists():
        return chrome_app
    for name in ("google-chrome", "chrome", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            return Path(found)
    raise FileNotFoundError("Google Chrome not found. Install Chrome, then retry salescloud_auth.")


def spawn_chrome_cdp(profile: Path, port: int) -> int | None:
    """Start Chrome with remote debugging. Return pid if spawned, else None if already up."""
    if cdp_alive(port):
        log(f"Reusing existing Chrome CDP on port {port}")
        return None

    profile.mkdir(parents=True, exist_ok=True)
    exe = chrome_executable()
    args = [
        str(exe),
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-blink-features=AutomationControlled",
        "--disable-session-crashed-bubble",
        "--hide-crash-restore-bubble",
        "about:blank",
    ]
    log(f"Starting Chrome for CDP (port={port}) profile={profile}")
    proc = subprocess.Popen(
        args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    deadline = time.time() + 30
    while time.time() < deadline:
        if cdp_alive(port):
            log(f"Chrome CDP ready (pid={proc.pid})")
            return proc.pid
        if proc.poll() is not None:
            raise RuntimeError(f"Chrome exited early with code {proc.returncode}")
        time.sleep(0.4)
    raise RuntimeError(f"Timed out waiting for Chrome CDP on port {port}")


def is_login_url(url: str) -> bool:
    low = (url or "").lower()
    if not low:
        return True
    if "ec=302" in low or "visualforce/session" in low or "starturl=" in low:
        return True
    if "samlerror" in low:
        return True
    if "/saml/" in low and "error" in low:
        return True
    if ".lightning.force.com" in low and "login.salesforce.com" not in low:
        return False
    if "/lightning/" in low and "login." not in low:
        return False
    return any(h in low for h in LOGIN_URL_HINTS)


async def page_has_auth_form(page) -> bool:
    for sel in AUTH_FORM_SELECTORS:
        try:
            loc = page.locator(sel).first
            if await loc.count() and await loc.is_visible(timeout=400):
                return True
        except Exception:
            continue
    return False


async def looks_logged_in(page) -> bool:
    try:
        url = page.url or ""
    except Exception:
        return False
    if is_login_url(url):
        return False
    if await page_has_auth_form(page):
        return False
    low = url.lower()
    if ".lightning.force.com" in low or "/lightning/" in low:
        for sel in LIGHTNING_SELECTORS:
            try:
                if await page.locator(sel).first.count() > 0:
                    return True
            except Exception:
                continue
        return "ec=302" not in low and "login." not in low
    if "salesforce.com" in low and "/services/" not in low:
        return not is_login_url(url)
    return False


def pick_best_page_sync(pages: list[Any]):
    if not pages:
        return None
    ranked: list[tuple[int, Any]] = []
    for p in pages:
        try:
            url = p.url or ""
        except Exception:
            url = ""
        score = 0
        if ".lightning.force.com" in url and "ec=302" not in url:
            score += 50
        if "/lightning/" in url:
            score += 40
        if "redhatcrm" in url:
            score += 10
        if is_login_url(url):
            score -= 100
        ranked.append((score, p))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return ranked[0][1]


async def connect_over_cdp(playwright, port: int):
    endpoint = cdp_endpoint(port)
    log(f"Connecting Playwright over CDP -> {endpoint}")
    browser = await playwright.chromium.connect_over_cdp(endpoint)
    if browser.contexts:
        context = browser.contexts[0]
    else:
        context = await browser.new_context()
    page = pick_best_page_sync(list(context.pages))
    if page is None:
        page = await context.new_page()
    else:
        try:
            await page.bring_to_front()
        except Exception:
            pass
    return browser, context, page


async def disconnect_leave_chrome(browser) -> None:
    """Do not call browser.close() — that can tear down the SSO window."""
    log("Leaving Chrome open for the next Sales Cloud call.")


def instance_from_url(url: str, fallback: str) -> str:
    try:
        host = urlparse(url).netloc.lower()
    except Exception:
        return fallback
    if not host:
        return fallback
    if host.endswith(".lightning.force.com"):
        my = host.replace(".lightning.force.com", ".my.salesforce.com")
        return f"https://{my}"
    if host.endswith(".my.salesforce.com"):
        return f"https://{host}"
    if host.endswith(".salesforce.com") and host not in ("login.salesforce.com", "test.salesforce.com"):
        return f"https://{host}"
    return fallback


def sid_from_cookies(cookies: list[dict[str, Any]]) -> tuple[str | None, str | None]:
    """Return (sid, cookie_domain) preferring a my.salesforce.com cookie."""
    sid_cookies = [c for c in cookies if c.get("name") == "sid" and c.get("value")]
    if not sid_cookies:
        return None, None
    preferred = []
    others = []
    for c in sid_cookies:
        domain = (c.get("domain") or "").lstrip(".")
        if domain.endswith(".my.salesforce.com") or domain.endswith(".lightning.force.com"):
            preferred.append(c)
        else:
            others.append(c)
    chosen = (preferred or others)[0]
    return str(chosen["value"]), (chosen.get("domain") or "").lstrip(".")
