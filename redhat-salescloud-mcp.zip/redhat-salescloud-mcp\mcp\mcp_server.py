#!/usr/bin/env python3
"""
Red Hat Sales Cloud MCP Server.

Exposes Salesforce Sales Cloud (redhatcrm) to Cursor via the Model Context
Protocol, matching the Gmail / Drive / Calendar assistants.

Authentication is not Google-style OAuth. The signed-in user is a Red Hat
associate. Sales Cloud sits behind associate SSO (auth.redhat.com) and
FreeOTP, and sessions expire often. Tools harvest that associate's Salesforce
session from a persistent Chrome window. When kicked out, call
salescloud_auth and complete associate SSO + FreeOTP in that window.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from src.auth import AUTH_INSTRUCTIONS, AuthRequired, get_auth
from src.ops import (
    describe_object,
    get_account,
    get_opportunity,
    get_record,
    get_report,
    list_accounts,
    list_contacts,
    list_leads,
    list_opportunities,
    run_query,
    run_search,
    to_text,
    whoami,
)
from src.salesforce import SessionExpired

server = Server("salescloud-assistant")


def _ok(payload: Any) -> list[TextContent]:
    return [TextContent(type="text", text=to_text(payload) if not isinstance(payload, str) else payload)]


def _err(message: str) -> list[TextContent]:
    return [TextContent(type="text", text=message)]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="salescloud_auth",
            description=(
                "Open or reconnect the persistent Chrome window so the Red Hat associate "
                "can sign into Sales Cloud (redhatcrm). Use before the first request and "
                "whenever Salesforce returns a session error. The associate completes "
                "Red Hat SSO (auth.redhat.com) and FreeOTP in Chrome — never collect a "
                "password or OTP in chat. Chrome stays open so later logins are faster. "
                "Set wait=true to block until Lightning loads."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "wait": {
                        "type": "boolean",
                        "description": "Wait until Sales Cloud is visible after SSO/FreeOTP (default: true)",
                        "default": True,
                    },
                    "force": {
                        "type": "boolean",
                        "description": "Ignore the saved session and re-harvest from Chrome",
                        "default": False,
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="salescloud_whoami",
            description="Show the signed-in Red Hat associate (Salesforce user) and whether the Chrome SSO session is alive.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="salescloud_search",
            description="SOSL search across Accounts, Contacts, Opportunities, and Leads in Red Hat Sales Cloud.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search text (account name, email, opportunity name, etc.)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max records per object (default: 25, max: 50)",
                        "default": 25,
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="salescloud_query",
            description="Run a Salesforce SOQL query. Use salescloud_describe first if you need field names.",
            inputSchema={
                "type": "object",
                "properties": {
                    "soql": {
                        "type": "string",
                        "description": "SOQL, e.g. SELECT Id, Name FROM Account WHERE Name LIKE '%Acme%' LIMIT 20",
                    }
                },
                "required": ["soql"],
            },
        ),
        Tool(
            name="salescloud_get_record",
            description="Get a Salesforce record by Id or Lightning URL. Object type is inferred from the Id prefix when omitted.",
            inputSchema={
                "type": "object",
                "properties": {
                    "record_id": {
                        "type": "string",
                        "description": "Salesforce Id or Lightning URL",
                    },
                    "object_name": {
                        "type": "string",
                        "description": "Optional sObject name: Account, Opportunity, Contact, Lead, …",
                    },
                },
                "required": ["record_id"],
            },
        ),
        Tool(
            name="salescloud_list_opportunities",
            description="List opportunities (pipeline). Defaults to the signed-in associate's open opportunities.",
            inputSchema={
                "type": "object",
                "properties": {
                    "mine": {
                        "type": "boolean",
                        "description": "Only opportunities owned by the signed-in associate (default: true)",
                        "default": True,
                    },
                    "open_only": {
                        "type": "boolean",
                        "description": "Exclude closed opportunities (default: true)",
                        "default": True,
                    },
                    "stage": {"type": "string", "description": "Exact StageName filter"},
                    "account_name": {"type": "string", "description": "Account name contains"},
                    "name_contains": {"type": "string", "description": "Opportunity name contains"},
                    "close_date_from": {"type": "string", "description": "CloseDate >= YYYY-MM-DD"},
                    "close_date_to": {"type": "string", "description": "CloseDate <= YYYY-MM-DD"},
                    "limit": {"type": "integer", "description": "Max rows (default: 50)", "default": 50},
                },
                "required": [],
            },
        ),
        Tool(
            name="salescloud_get_opportunity",
            description="Get an opportunity plus related contact roles, products, and recent tasks.",
            inputSchema={
                "type": "object",
                "properties": {
                    "record_id": {"type": "string", "description": "Opportunity Id or Lightning URL"},
                    "include_related": {
                        "type": "boolean",
                        "description": "Include contact roles, line items, and tasks (default: true)",
                        "default": True,
                    },
                },
                "required": ["record_id"],
            },
        ),
        Tool(
            name="salescloud_list_accounts",
            description="List accounts, optionally filtered by name or owned by the current user.",
            inputSchema={
                "type": "object",
                "properties": {
                    "mine": {
                        "type": "boolean",
                        "description": "Only accounts owned by the current user (default: false)",
                        "default": False,
                    },
                    "name_contains": {"type": "string", "description": "Account name contains"},
                    "limit": {"type": "integer", "description": "Max rows (default: 50)", "default": 50},
                },
                "required": [],
            },
        ),
        Tool(
            name="salescloud_get_account",
            description="Get an account plus related contacts and opportunities.",
            inputSchema={
                "type": "object",
                "properties": {
                    "record_id": {"type": "string", "description": "Account Id or Lightning URL"},
                    "include_related": {
                        "type": "boolean",
                        "description": "Include contacts and opportunities (default: true)",
                        "default": True,
                    },
                },
                "required": ["record_id"],
            },
        ),
        Tool(
            name="salescloud_list_contacts",
            description="List contacts, optionally by account, email, or name.",
            inputSchema={
                "type": "object",
                "properties": {
                    "account_id": {"type": "string", "description": "Filter by Account Id"},
                    "email": {"type": "string", "description": "Email contains"},
                    "name_contains": {"type": "string", "description": "Contact name contains"},
                    "limit": {"type": "integer", "description": "Max rows (default: 50)", "default": 50},
                },
                "required": [],
            },
        ),
        Tool(
            name="salescloud_get_contact",
            description="Get a contact by Id or Lightning URL.",
            inputSchema={
                "type": "object",
                "properties": {
                    "record_id": {"type": "string", "description": "Contact Id or Lightning URL"},
                },
                "required": ["record_id"],
            },
        ),
        Tool(
            name="salescloud_list_leads",
            description="List leads. Defaults to the signed-in associate's leads.",
            inputSchema={
                "type": "object",
                "properties": {
                    "mine": {
                        "type": "boolean",
                        "description": "Only leads owned by the current user (default: true)",
                        "default": True,
                    },
                    "status": {"type": "string", "description": "Exact Status filter"},
                    "name_contains": {"type": "string", "description": "Name or company contains"},
                    "limit": {"type": "integer", "description": "Max rows (default: 50)", "default": 50},
                },
                "required": [],
            },
        ),
        Tool(
            name="salescloud_get_report",
            description="Run a Salesforce report by Id or Lightning/Analytics URL and return detail rows when available.",
            inputSchema={
                "type": "object",
                "properties": {
                    "report_id": {"type": "string", "description": "Report Id or URL"},
                },
                "required": ["report_id"],
            },
        ),
        Tool(
            name="salescloud_describe",
            description="Describe a Salesforce object (fields, types) so you can write accurate SOQL.",
            inputSchema={
                "type": "object",
                "properties": {
                    "object_name": {
                        "type": "string",
                        "description": "sObject API name, e.g. Opportunity, Account, Contact",
                    }
                },
                "required": ["object_name"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    args = arguments or {}
    try:
        if name == "salescloud_auth":
            return await handle_auth(args)
        if name == "salescloud_whoami":
            return await handle_whoami()
        if name == "salescloud_search":
            return _ok(await run_search(args["query"], limit=args.get("limit", 25)))
        if name == "salescloud_query":
            return _ok(await run_query(args["soql"]))
        if name == "salescloud_get_record":
            return _ok(await get_record(args["record_id"], args.get("object_name")))
        if name == "salescloud_list_opportunities":
            return _ok(
                await list_opportunities(
                    mine=args.get("mine", True),
                    open_only=args.get("open_only", True),
                    stage=args.get("stage"),
                    account_name=args.get("account_name"),
                    name_contains=args.get("name_contains"),
                    close_date_from=args.get("close_date_from"),
                    close_date_to=args.get("close_date_to"),
                    limit=args.get("limit", 50),
                )
            )
        if name == "salescloud_get_opportunity":
            return _ok(
                await get_opportunity(
                    args["record_id"],
                    include_related=args.get("include_related", True),
                )
            )
        if name == "salescloud_list_accounts":
            return _ok(
                await list_accounts(
                    mine=args.get("mine", False),
                    name_contains=args.get("name_contains"),
                    limit=args.get("limit", 50),
                )
            )
        if name == "salescloud_get_account":
            return _ok(
                await get_account(
                    args["record_id"],
                    include_related=args.get("include_related", True),
                )
            )
        if name == "salescloud_list_contacts":
            return _ok(
                await list_contacts(
                    account_id=args.get("account_id"),
                    email=args.get("email"),
                    name_contains=args.get("name_contains"),
                    limit=args.get("limit", 50),
                )
            )
        if name == "salescloud_get_contact":
            return _ok(await get_record(args["record_id"], "Contact"))
        if name == "salescloud_list_leads":
            return _ok(
                await list_leads(
                    mine=args.get("mine", True),
                    status=args.get("status"),
                    name_contains=args.get("name_contains"),
                    limit=args.get("limit", 50),
                )
            )
        if name == "salescloud_get_report":
            return _ok(await get_report(args["report_id"]))
        if name == "salescloud_describe":
            desc = await describe_object(args["object_name"])
            fields = desc.get("fields") or []
            # Keep the payload usable in chat
            if len(fields) > 80:
                desc = dict(desc)
                desc["fields"] = fields[:80]
                desc["fields_truncated"] = len(fields) - 80
                desc["hint"] = "First 80 fields shown. Ask for a specific field name if needed."
            return _ok(desc)
        return _err(f"Unknown tool: {name}")
    except (AuthRequired, SessionExpired) as e:
        return _err(str(e) or AUTH_INSTRUCTIONS)
    except Exception as e:
        return _err(f"Error: {e}")


async def handle_auth(args: dict) -> list[TextContent]:
    auth = get_auth()
    wait = bool(args.get("wait", True))
    force = bool(args.get("force", False))
    try:
        session = await auth.authenticate(force_login=force, wait=wait)
    except AuthRequired as e:
        return _err(str(e) or AUTH_INSTRUCTIONS)
    return _ok(
        {
            "ok": True,
            "message": "Sales Cloud session is ready.",
            "name": session.get("name"),
            "username": session.get("username") or session.get("preferred_username"),
            "email": session.get("email"),
            "user_id": session.get("user_id"),
            "instance_url": session.get("instance_url"),
            "captured_at": session.get("captured_at"),
        }
    )


async def handle_whoami() -> list[TextContent]:
    auth = get_auth()
    status = auth.status_dict()
    try:
        identity = await whoami()
        status.update(identity)
        status["authenticated"] = True
    except (AuthRequired, SessionExpired) as e:
        status["authenticated"] = False
        status["error"] = str(e)
        status["next_step"] = (
            "Call salescloud_auth. The associate signs in with Red Hat SSO + FreeOTP in Chrome."
        )
    return _ok(status)


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
