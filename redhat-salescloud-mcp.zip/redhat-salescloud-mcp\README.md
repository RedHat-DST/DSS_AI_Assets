# Red Hat Sales Cloud MCP — associate package

Cursor MCP for **Red Hat associates** to query Sales Cloud (Salesforce / `redhatcrm`) as themselves. Same shape as the Gmail / Drive / Calendar assistants. Auth is associate SSO (auth.redhat.com) + FreeOTP in a persistent Chrome window.

## What to send associates

1. This zip: `redhat-salescloud-mcp.zip`
2. The prompt in **INSTALL_PROMPT.md** (they paste it into Cursor Agent and attach the zip)

They must already have Sales Cloud access. This package does not grant CRM access.

## Contents

```
redhat-salescloud-mcp/
├── README.md
├── SETUP.md
├── INSTALL_PROMPT.md      ← prompt they paste into Cursor
├── install.sh             ← optional non-agent install
├── mcp/                   ← MCP server (copy to ~/mcps/salescloud-assistant)
│   ├── mcp_server.py
│   ├── requirements.txt
│   ├── config.example.json
│   └── src/
└── skills/
    └── redhat-salescloud/  ← copy to ~/.cursor/skills/
```

This zip does **not** include `session.json`, Chrome profiles, or a virtualenv.

## Requirements

- Red Hat associate with Sales Cloud (redhatcrm) access
- Cursor with Agent mode
- Google Chrome
- Python 3.12+
- FreeOTP (same token as other Red Hat apps)
