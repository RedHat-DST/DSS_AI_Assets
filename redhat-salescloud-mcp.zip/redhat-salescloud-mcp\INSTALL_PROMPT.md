# Cursor prompt — install Red Hat Sales Cloud MCP (associates)

Send this zip to a **Red Hat associate**. They attach `redhat-salescloud-mcp.zip` in **Cursor Agent** and paste the prompt below. Login is their associate SSO + FreeOTP — not a Salesforce username.

---

## Prompt to paste

```
I am a Red Hat associate. Install the Red Hat Sales Cloud MCP from the attached redhat-salescloud-mcp.zip (or extracted folder) so Cursor can query redhatcrm as me.

Do this, in order:

1. Unpack the zip if needed. The package contains mcp/ (the server) and skills/redhat-salescloud/.

2. Copy the MCP server to ~/mcps/salescloud-assistant (create ~/mcps if missing). Overwrite code files, but never copy session.json, profiles/, or .venv from the zip.

3. Copy skills/redhat-salescloud to ~/.cursor/skills/redhat-salescloud.

4. Create a Python 3.12 venv in ~/mcps/salescloud-assistant/.venv (prefer python3.12 or /opt/homebrew/bin/python3.12; do not use macOS python3 3.9). pip install -r requirements.txt and run .venv/bin/playwright install chromium.

5. Merge this server into ~/.cursor/mcp.json without removing existing servers (gmail, gdrive, calendar, etc.). Use absolute paths:

   "salescloud-assistant": {
     "command": "<HOME>/mcps/salescloud-assistant/.venv/bin/python",
     "args": ["<HOME>/mcps/salescloud-assistant/mcp_server.py"]
   }

6. Do not open Chrome or start SSO yourself. Tell me:
   - to reload MCP in Cursor Settings → MCP
   - that first login is: I ask you to call salescloud_auth, then I sign in with my Red Hat associate account (auth.redhat.com) and FreeOTP in the Chrome window — the same SSO I use for other Red Hat apps
   - never to ask for my associate password or OTP in chat
   - that this uses my existing Sales Cloud access; it does not grant CRM access

If ~/mcps/salescloud-assistant already exists, update the code and keep my existing associate session.json / Chrome profile.

When finished, print the mcp.json snippet you wrote and confirm the skill path.
```

---

## After they paste it

1. Reload **Cursor Settings → MCP** until `salescloud-assistant` is green.
2. In a new chat: `Log me into Sales Cloud as myself` (agent calls `salescloud_auth`).
3. In Chrome: Red Hat associate SSO + FreeOTP. Leave that window running.
4. Try: `Show my open opportunities`.
