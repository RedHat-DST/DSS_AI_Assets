#!/usr/bin/env bash
# Optional non-agent installer. Prefer INSTALL_PROMPT.md in Cursor Agent.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
DEST="${HOME}/mcps/salescloud-assistant"
SKILL_DEST="${HOME}/.cursor/skills/redhat-salescloud"
MCP_JSON="${HOME}/.cursor/mcp.json"

PY=""
for candidate in python3.12 /opt/homebrew/bin/python3.12 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    ver="$("$candidate" -c 'import sys; print("%s.%s" % (sys.version_info.major, sys.version_info.minor))')"
    case "$ver" in
      3.11*|3.12*|3.13*) PY="$candidate"; break ;;
    esac
  fi
done

if [ -z "$PY" ]; then
  echo "Need Python 3.11+ (3.12 recommended). macOS /usr/bin/python3 is too old." >&2
  exit 1
fi

echo "Python: $PY"
mkdir -p "$(dirname "$DEST")"
mkdir -p "${HOME}/.cursor/skills"

echo "Installing MCP -> $DEST"
mkdir -p "$DEST"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --exclude '.venv' --exclude 'session.json' --exclude 'profiles' --exclude '__pycache__' "$ROOT/mcp/" "$DEST/"
else
  cp -R "$ROOT/mcp/." "$DEST/"
fi

echo "Installing skill -> $SKILL_DEST"
mkdir -p "$SKILL_DEST"
cp -R "$ROOT/skills/redhat-salescloud/." "$SKILL_DEST/"

cd "$DEST"
if [ ! -d .venv ]; then
  "$PY" -m venv .venv
fi
.venv/bin/pip install -U pip
.venv/bin/pip install -r requirements.txt
.venv/bin/playwright install chromium

export SALESCLOUD_MCP_JSON="$MCP_JSON"
export SALESCLOUD_PYTHON="$DEST/.venv/bin/python"
export SALESCLOUD_SERVER="$DEST/mcp_server.py"

"$PY" - <<'PY'
import json
import os
from pathlib import Path

mcp_path = Path(os.environ["SALESCLOUD_MCP_JSON"])
mcp_path.parent.mkdir(parents=True, exist_ok=True)
data = {"mcpServers": {}}
if mcp_path.exists():
    try:
        data = json.loads(mcp_path.read_text(encoding="utf-8"))
    except Exception:
        data = {"mcpServers": {}}
data.setdefault("mcpServers", {})
data["mcpServers"]["salescloud-assistant"] = {
    "command": os.environ["SALESCLOUD_PYTHON"],
    "args": [os.environ["SALESCLOUD_SERVER"]],
}
mcp_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
print("Updated", mcp_path)
PY

echo
echo "Done."
echo "1. Reload MCP in Cursor Settings → MCP"
echo "2. In chat: ask the agent to call salescloud_auth"
echo "3. Sign in with your Red Hat associate account + FreeOTP in Chrome."
echo "   Do not paste your password or OTP into chat."
