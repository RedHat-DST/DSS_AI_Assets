# Setup — Red Hat Sales Cloud MCP (associates)

For **Red Hat associates** with existing Sales Cloud (redhatcrm) access. Cursor uses your associate browser session. There is no Salesforce username/password and no Google-style `credentials.json`. You sign in with **associate SSO** (auth.redhat.com) and **FreeOTP** in Chrome.

**Easiest path:** download `redhat-salescloud-mcp.zip`, attach it in a Cursor Agent chat, and paste the prompt in `INSTALL_PROMPT.md`.

## Requirements

- You are a Red Hat associate with Sales Cloud access already (this MCP does not grant CRM access)
- Cursor (Agent mode)
- Google Chrome
- Python 3.12+ (`python3.12` on PATH, or Homebrew `/opt/homebrew/bin/python3.12`)
- FreeOTP (same token as other Red Hat apps)

Never paste your associate password or OTP into chat.

## 1. Install

Default location: `~/mcps/salescloud-assistant`

```bash
cd ~/mcps/salescloud-assistant
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/playwright install chromium
```

This MCP uses a **dedicated** Chrome profile for associate SSO, not your everyday Chrome.

## 2. Optional config

```bash
cp config.example.json config.json
```

Defaults already point at Red Hat Sales Cloud:

| Key | Default |
|-----|---------|
| `instance_url` | `https://redhatcrm.my.salesforce.com` |
| `lightning_url` | `https://redhatcrm.lightning.force.com` |
| `start_url` | Lightning home |
| `cdp_port` | `9223` |
| `login_timeout_seconds` | `600` |

## 3. Register in Cursor

Merge this into `~/.cursor/mcp.json` (use your real home path):

```json
"salescloud-assistant": {
  "command": "/<HOME>/mcps/salescloud-assistant/.venv/bin/python",
  "args": ["/<HOME>/mcps/salescloud-assistant/mcp_server.py"]
}
```

Copy the skill:

```bash
cp -R skills/redhat-salescloud ~/.cursor/skills/
```

Reload MCP in **Cursor Settings → MCP**. You should see tools named `salescloud_*`.

## 4. First login (associate SSO)

```bash
~/mcps/salescloud-assistant/.venv/bin/python -m src.cli auth
```

Or in Cursor: ask the agent to call `salescloud_auth`.

1. Chrome opens (profile under `profiles/default`).
2. Sign in with your **Red Hat associate** account.
3. Enter your **FreeOTP** code.
4. Wait until redhatcrm Lightning is visible.

Chrome **stays open**. Leave it running so the next FreeOTP prompt is that same window.

## 5. When Sales Cloud kicks you out

This will happen often.

1. Ask the agent to call `salescloud_auth`, or run `python -m src.cli auth`.
2. In Chrome, finish associate SSO + FreeOTP again.
3. Retry the original request.

## Troubleshooting

| Symptom | What to do |
|---------|------------|
| `Chrome not found` | Install Google Chrome |
| Python / `mcp` install fails | Use Python 3.12+, not macOS 3.9 |
| Salesforce login page instead of Red Hat SSO | Use associate SSO; do not create a Salesforce-only login |
| No CRM access after SSO | You need Sales Cloud entitlement as an associate; this MCP cannot add it |
| Tool says login required but Chrome is on Lightning | Call `salescloud_auth` with `force=true` |
| `INVALID_SESSION_ID` | Session expired — associate SSO + FreeOTP, then `salescloud_auth` |
