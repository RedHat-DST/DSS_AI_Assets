"""
Red Hat Sales Cloud CLI.

Usage:
    python -m src.cli auth            # Open Chrome, complete SSO + FreeOTP
    python -m src.cli whoami          # Show current Salesforce user
    python -m src.cli search "acme"   # SOSL search
    python -m src.cli opps            # My open opportunities
    python -m src.cli query "SELECT Id, Name FROM Account LIMIT 5"
    python -m src.cli auth_status     # Session + Chrome CDP status
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Optional

import click

from .auth import AuthRequired, get_auth
from .ops import (
    get_account,
    get_opportunity,
    get_record,
    list_accounts,
    list_contacts,
    list_leads,
    list_opportunities,
    run_query,
    run_search,
    whoami,
)
from .salesforce import SessionExpired


def _run(coro):
    return asyncio.run(coro)


def _print(payload) -> None:
    click.echo(json.dumps(payload, indent=2, default=str))


def _die_auth(err: Exception) -> None:
    click.echo(click.style(str(err), fg="yellow"))
    sys.exit(2)


@click.group()
def cli():
    """Red Hat Sales Cloud assistant (Salesforce REST via SSO Chrome session)."""


@cli.command("auth")
@click.option("--wait/--no-wait", default=True, help="Wait until Lightning is visible after SSO/FreeOTP")
@click.option("--force", is_flag=True, help="Ignore saved session and re-harvest from Chrome")
def auth_cmd(wait: bool, force: bool):
    """Open Chrome and harvest a Salesforce session after SSO + FreeOTP."""
    auth = get_auth()
    try:
        session = _run(auth.authenticate(force_login=force, wait=wait))
    except AuthRequired as e:
        _die_auth(e)
    click.echo(click.style("Authenticated", fg="green", bold=True))
    _print(
        {
            "name": session.get("name"),
            "username": session.get("username") or session.get("preferred_username"),
            "email": session.get("email"),
            "instance_url": session.get("instance_url"),
        }
    )


@cli.command("auth_status")
def auth_status():
    """Show saved session and whether Chrome CDP is alive."""
    auth = get_auth()
    status = auth.status_dict()
    try:
        identity = _run(whoami())
        status.update(identity)
        status["authenticated"] = True
    except (AuthRequired, SessionExpired) as e:
        status["authenticated"] = False
        status["error"] = str(e)
    _print(status)


@cli.command("whoami")
def whoami_cmd():
    """Show the current Salesforce user."""
    try:
        _print(_run(whoami()))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)


@cli.command("search")
@click.argument("query")
@click.option("-n", "--num", default=25, help="Max records per object")
def search_cmd(query: str, num: int):
    """SOSL search across accounts, contacts, opportunities, and leads."""
    try:
        _print(_run(run_search(query, limit=num)))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


@cli.command("query")
@click.argument("soql")
def query_cmd(soql: str):
    """Run a SOQL query."""
    try:
        _print(_run(run_query(soql)))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


@cli.command("opps")
@click.option("--all-users", is_flag=True, help="Do not filter to current owner")
@click.option("--include-closed", is_flag=True, help="Include closed opportunities")
@click.option("--stage", default=None, help="Exact stage name")
@click.option("--account", "account_name", default=None, help="Account name contains")
@click.option("-n", "--num", default=50, help="Max rows")
def opps_cmd(all_users: bool, include_closed: bool, stage: Optional[str], account_name: Optional[str], num: int):
    """List opportunities (default: my open pipeline)."""
    try:
        _print(
            _run(
                list_opportunities(
                    mine=not all_users,
                    open_only=not include_closed,
                    stage=stage,
                    account_name=account_name,
                    limit=num,
                )
            )
        )
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


@cli.command("get")
@click.argument("record_id")
@click.option("-o", "--object", "object_name", default=None, help="sObject name if Id prefix is unknown")
def get_cmd(record_id: str, object_name: Optional[str]):
    """Get a record by Id or Lightning URL."""
    try:
        if object_name == "Opportunity" or (not object_name and record_id.startswith("006")):
            _print(_run(get_opportunity(record_id)))
        elif object_name == "Account" or (not object_name and record_id.startswith("001")):
            _print(_run(get_account(record_id)))
        else:
            _print(_run(get_record(record_id, object_name)))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


@cli.command("accounts")
@click.option("--mine", is_flag=True, help="Only accounts owned by me")
@click.option("--name", "name_contains", default=None, help="Name contains")
@click.option("-n", "--num", default=50, help="Max rows")
def accounts_cmd(mine: bool, name_contains: Optional[str], num: int):
    """List accounts."""
    try:
        _print(_run(list_accounts(mine=mine, name_contains=name_contains, limit=num)))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


@cli.command("contacts")
@click.option("--account", "account_id", default=None, help="Account Id")
@click.option("--email", default=None, help="Email contains")
@click.option("--name", "name_contains", default=None, help="Name contains")
@click.option("-n", "--num", default=50, help="Max rows")
def contacts_cmd(account_id: Optional[str], email: Optional[str], name_contains: Optional[str], num: int):
    """List contacts."""
    try:
        _print(_run(list_contacts(account_id=account_id, email=email, name_contains=name_contains, limit=num)))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


@cli.command("leads")
@click.option("--all-users", is_flag=True, help="Do not filter to current owner")
@click.option("--status", default=None, help="Exact status")
@click.option("-n", "--num", default=50, help="Max rows")
def leads_cmd(all_users: bool, status: Optional[str], num: int):
    """List leads (default: mine)."""
    try:
        _print(_run(list_leads(mine=not all_users, status=status, limit=num)))
    except (AuthRequired, SessionExpired) as e:
        _die_auth(e)
    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        sys.exit(1)


if __name__ == "__main__":
    cli()
