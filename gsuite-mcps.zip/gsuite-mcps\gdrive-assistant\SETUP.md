# Google Cloud Setup Guide

This guide walks you through setting up Google Cloud OAuth credentials for the Google Drive Assistant.

## Prerequisites

- A Google account (your Red Hat Google Workspace account)
- Access to [Google Cloud Console](https://console.cloud.google.com/)
- Existing `credentials.json` from the email-checker project (recommended) OR new credentials

## Option A: Share Credentials with Email-Checker (Recommended)

If you already have email-checker set up with OAuth credentials:

### Step 1: Enable Additional APIs

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Select your existing project (the one used for email-checker)
3. Go to **APIs & Services** > **Library**
4. Enable each of these APIs:
   - **Google Drive API** - Search and enable
   - **Google Docs API** - Search and enable
   - **Google Sheets API** - Search and enable
   - **Google Slides API** - Search and enable

### Step 2: Update OAuth Consent Scopes

1. Go to **APIs & Services** > **OAuth consent screen**
2. Click **Edit App**
3. On the **Scopes** page, click **Add or Remove Scopes**
4. Add these scopes:
   - `https://www.googleapis.com/auth/drive` - Full Drive access
   - `https://www.googleapis.com/auth/documents` - Docs read/write
   - `https://www.googleapis.com/auth/spreadsheets` - Sheets read/write
   - `https://www.googleapis.com/auth/presentations` - Slides read/write
5. Click **Update**, then **Save and Continue**

### Step 3: Copy Credentials

Copy or symlink your `credentials.json`:

```bash
# Option 1: Symlink (recommended - shares updates)
ln -s /home/mmcgrath/RedHat/email-checker/credentials.json /home/mmcgrath/RedHat/gdrive-assistant/credentials.json

# Option 2: Copy
cp /home/mmcgrath/RedHat/email-checker/credentials.json /home/mmcgrath/RedHat/gdrive-assistant/credentials.json
```

### Step 4: First-Time Authentication

The new scopes require re-authorization. Run:

```bash
cd /home/mmcgrath/RedHat/gdrive-assistant
python -m src.cli auth_status
```

This will open a browser to authorize the new Drive/Docs/Sheets/Slides scopes.

---

## Option B: Create New Google Cloud Project

If you want a separate project:

### Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click the project dropdown at the top
3. Click **New Project**
4. Name: "Google Drive Assistant"
5. Click **Create**

### Step 2: Enable APIs

1. Select your new project
2. Go to **APIs & Services** > **Library**
3. Enable each of these APIs:
   - Google Drive API
   - Google Docs API
   - Google Sheets API
   - Google Slides API

### Step 3: Configure OAuth Consent Screen

1. Go to **APIs & Services** > **OAuth consent screen**
2. Select **Internal** (Workspace) or **External** (personal)
3. Fill in:
   - **App name**: Google Drive Assistant
   - **User support email**: Your email
   - **Developer contact email**: Your email
4. Click **Save and Continue**
5. On **Scopes**, click **Add or Remove Scopes**
6. Add:
   - `https://www.googleapis.com/auth/drive`
   - `https://www.googleapis.com/auth/documents`
   - `https://www.googleapis.com/auth/spreadsheets`
   - `https://www.googleapis.com/auth/presentations`
7. Click **Update**, then **Save and Continue**
8. If External, add yourself as a test user
9. Click **Back to Dashboard**

### Step 4: Create OAuth Credentials

1. Go to **APIs & Services** > **Credentials**
2. Click **+ Create Credentials** > **OAuth client ID**
3. **Application type**: Desktop app
4. **Name**: Google Drive Assistant Desktop
5. Click **Create**
6. Click **Download JSON**
7. Rename and move:
   ```bash
   mv ~/Downloads/client_secret_*.json /home/mmcgrath/RedHat/gdrive-assistant/credentials.json
   ```

### Step 5: Install Dependencies

```bash
cd /home/mmcgrath/RedHat/gdrive-assistant
pip install -r requirements.txt
```

### Step 6: First-Time Authentication

```bash
python -m src.cli auth_status
```

This will open a browser to authorize access.

---

## MCP Server Configuration

Add the MCP server to your Cursor settings:

### For Cursor Settings (settings.json or MCP config)

```json
{
  "mcpServers": {
    "gdrive-assistant": {
      "command": "python",
      "args": ["/home/mmcgrath/RedHat/gdrive-assistant/mcp_server.py"],
      "env": {}
    }
  }
}
```

Or for `mcp.json`:

```json
{
  "servers": {
    "gdrive-assistant": {
      "command": "python",
      "args": ["/home/mmcgrath/RedHat/gdrive-assistant/mcp_server.py"]
    }
  }
}
```

---

## Troubleshooting

### "Access blocked: This app's request is invalid"
- Make sure you've added yourself as a test user (for External apps)
- Verify all required scopes are added to OAuth consent screen

### "Permission denied" errors
- Ensure all four APIs are enabled
- Delete `gdrive_token.json` and re-authenticate

### Token refresh issues
- Delete `gdrive_token.json`
- Run `python -m src.cli auth_status` to re-authenticate

### Port already in use during auth
- The auth flow tries ports 8085-8090
- Close any applications using these ports
- Or wait and retry

---

## Security Notes

- **Never commit `credentials.json` or `gdrive_token.json` to git**
- These files contain sensitive OAuth credentials
- The `.gitignore` file excludes them automatically
- Token files should have 0o600 permissions (set automatically)

---

## File Locations After Setup

```
gdrive-assistant/
├── credentials.json      # OAuth client credentials
├── gdrive_token.json     # Auto-generated after first auth
└── ...
```

Both files are gitignored for security.

