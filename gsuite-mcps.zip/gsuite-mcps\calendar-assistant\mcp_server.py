#!/usr/bin/env python3
"""
Google Calendar Assistant MCP Server.

Exposes Google Calendar functionality to Claude in Cursor via the Model Context Protocol.

Tools provided:
- calendar_list_calendars: List all accessible calendars
- calendar_today: Get today's events
- calendar_upcoming: Get upcoming events for N days
- calendar_search: Search events by text query
- calendar_get_event: Get details for a specific event
- calendar_now: Get current or next event
- calendar_create_event: Create a new event with full metadata
- calendar_update_event: Update an existing event
- calendar_delete_event: Delete an event
"""

import sys
from pathlib import Path
from typing import Any
from datetime import datetime, timedelta
import pytz
from dateutil import parser as date_parser

# Add project to path for imports
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from src.auth import get_auth
from src.calendar_ops import (
    list_calendars, get_todays_events, get_upcoming_events,
    search_events, get_event, get_current_or_next_event,
    create_event, update_event, delete_event
)

# Cache for calendar timezone lookup
_calendar_tz_cache = {}


def get_default_timezone(calendar_id: str = 'primary') -> pytz.timezone:
    """
    Get the default timezone to use for date parsing.
    
    Priority:
    1. Calendar's timezone (from Google Calendar settings)
    2. System local timezone
    3. UTC (fallback)
    
    Args:
        calendar_id: Calendar ID to get timezone from
        
    Returns:
        pytz timezone object
    """
    # Try calendar timezone first (cached)
    if calendar_id not in _calendar_tz_cache:
        try:
            calendars = list_calendars()
            for cal in calendars:
                if cal.get('id') == calendar_id:
                    tz_str = cal.get('timezone', '')
                    if tz_str:
                        _calendar_tz_cache[calendar_id] = pytz.timezone(tz_str)
                        return _calendar_tz_cache[calendar_id]
        except Exception:
            pass
    elif calendar_id in _calendar_tz_cache:
        return _calendar_tz_cache[calendar_id]
    
    # Try system local timezone
    try:
        import time
        if time.daylight:
            offset_seconds = time.altzone
        else:
            offset_seconds = time.timezone
        # Convert to hours (negative because time.timezone is seconds west of UTC)
        offset_hours = -offset_seconds / 3600
        # For common US timezones, map to proper pytz names
        tz_map = {
            -5: 'America/New_York',    # EST/EDT
            -6: 'America/Chicago',      # CST/CDT
            -7: 'America/Denver',       # MST/MDT
            -8: 'America/Los_Angeles',  # PST/PDT
        }
        if offset_hours in tz_map:
            return pytz.timezone(tz_map[offset_hours])
        # Otherwise use UTC offset
        return pytz.timezone(f'Etc/GMT{int(offset_hours):+d}')
    except Exception:
        pass
    
    # Fallback to UTC
    return pytz.UTC


# Initialize MCP server
server = Server("calendar-assistant")


def format_datetime(dt: datetime, all_day: bool = False) -> str:
    """Format datetime for output."""
    if not dt:
        return "Unknown"
    
    if all_day:
        return dt.strftime("%a, %b %d, %Y")
    
    # Check if today
    now = datetime.now(dt.tzinfo if dt.tzinfo else pytz.UTC)
    if dt.date() == now.date():
        return f"Today at {dt.strftime('%I:%M %p')}"
    elif dt.date() == (now + timedelta(days=1)).date():
        return f"Tomorrow at {dt.strftime('%I:%M %p')}"
    else:
        return dt.strftime("%a, %b %d, %Y at %I:%M %p")


def format_time_range(start: datetime, end: datetime, all_day: bool = False) -> str:
    """Format a time range."""
    if not start:
        return "Unknown time"
    
    if all_day:
        if not end or (end.date() == start.date()) or (end.date() == start.date() + timedelta(days=1)):
            return format_datetime(start, all_day=True)
        else:
            return f"{start.strftime('%a, %b %d')} - {(end - timedelta(days=1)).strftime('%a, %b %d')}"
    
    if not end:
        return format_datetime(start)
    
    # Same day
    if start.date() == end.date():
        return f"{format_datetime(start)} - {end.strftime('%I:%M %p')}"
    else:
        return f"{format_datetime(start)} - {format_datetime(end)}"


def format_event(event: dict, include_details: bool = False) -> str:
    """Format an event for text output."""
    lines = []
    
    summary = event.get('summary', 'No Title')
    start = event.get('start_datetime')
    end = event.get('end_datetime')
    all_day = event.get('is_all_day', False)
    
    lines.append(f"📅 {summary}")
    lines.append(f"   {format_time_range(start, end, all_day)}")
    
    if event.get('location'):
        lines.append(f"   📍 {event['location']}")
    
    if event.get('conference_link'):
        lines.append(f"   🔗 {event['conference_link']}")
    
    # Always show event ID for follow-up operations
    if event.get('id'):
        lines.append(f"   ID: {event['id']}")
    
    if include_details:
        if event.get('description'):
            lines.append(f"\n   Description:")
            for line in event['description'].split('\n')[:10]:  # Limit lines
                lines.append(f"   {line}")
        
        attendees = event.get('attendees', [])
        if attendees:
            lines.append(f"\n   Attendees ({len(attendees)}):")
            for att in attendees[:15]:  # Limit to 15
                status_icon = {
                    'accepted': '✅',
                    'declined': '❌',
                    'tentative': '❓',
                    'needsAction': '⏳'
                }.get(att.get('responseStatus', 'needsAction'), '⏳')
                name = att.get('displayName') or att.get('email', 'Unknown')
                lines.append(f"     {status_icon} {name}")
            if len(attendees) > 15:
                lines.append(f"     ... and {len(attendees) - 15} more")
        
        attachments = event.get('attachments', [])
        if attachments:
            lines.append(f"\n   Attachments ({len(attachments)}):")
            for att in attachments:
                title = att.get('title', 'Untitled')
                file_url = att.get('fileUrl', '')
                mime_type = att.get('mimeType', '')
                # Determine file type icon
                icon = '📎'
                if 'pdf' in mime_type.lower():
                    icon = '📄'
                elif any(t in mime_type.lower() for t in ['doc', 'word']):
                    icon = '📝'
                elif any(t in mime_type.lower() for t in ['sheet', 'excel', 'csv']):
                    icon = '📊'
                elif any(t in mime_type.lower() for t in ['slide', 'presentation']):
                    icon = '📽️'
                elif any(t in mime_type.lower() for t in ['image', 'png', 'jpg', 'jpeg', 'gif']):
                    icon = '🖼️'
                lines.append(f"     {icon} {title}")
                lines.append(f"        {file_url}")
        
        if event.get('html_link'):
            lines.append(f"\n   View: {event['html_link']}")
    
    return "\n".join(lines)


def ensure_authenticated():
    """Ensure Calendar is authenticated, raise if not."""
    auth = get_auth()
    if not auth.authenticate():
        raise RuntimeError(
            "Calendar authentication required. Run 'python -m src.cli auth-status' "
            "from the calendar-assistant directory to authenticate."
        )
    return auth


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available Calendar tools."""
    return [
        Tool(
            name="calendar_list_calendars",
            description="List all calendars accessible to the user. Shows calendar names, IDs, access levels, and which is primary.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="calendar_today",
            description="Get all events for today from the specified calendar.",
            inputSchema={
                "type": "object",
                "properties": {
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="calendar_upcoming",
            description="Get upcoming events for the next N days. Returns events sorted by start time.",
            inputSchema={
                "type": "object",
                "properties": {
                    "days": {
                        "type": "integer",
                        "description": "Number of days to look ahead (default: 7)",
                        "default": 7
                    },
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of events to return (default: 50)",
                        "default": 50
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="calendar_search",
            description="Search for events by text query. Searches event titles, descriptions, and locations. Optionally filter by date range.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query text"
                    },
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    },
                    "time_min": {
                        "type": "string",
                        "description": "Start date/time for search in ISO 8601 format (e.g., '2026-01-01' or '2026-01-01T00:00:00')"
                    },
                    "time_max": {
                        "type": "string",
                        "description": "End date/time for search in ISO 8601 format (e.g., '2026-01-31' or '2026-01-31T23:59:59')"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 50)",
                        "default": 50
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="calendar_get_event",
            description="Get detailed information for a specific event by its ID. Includes full description, all attendees, and meeting links.",
            inputSchema={
                "type": "object",
                "properties": {
                    "event_id": {
                        "type": "string",
                        "description": "Event ID"
                    },
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    }
                },
                "required": ["event_id"]
            }
        ),
        Tool(
            name="calendar_now",
            description="Get the current event (if one is happening now) or the next upcoming event in the next 24 hours.",
            inputSchema={
                "type": "object",
                "properties": {
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="calendar_create_event",
            description="Create a new calendar event with comprehensive metadata. Supports all event fields including attendees, video conferencing (Google Meet, Zoom), attachments, reminders, recurrence, and more.",
            inputSchema={
                "type": "object",
                "properties": {
                    "summary": {
                        "type": "string",
                        "description": "Event title/summary (required)"
                    },
                    "start_time": {
                        "type": "string",
                        "description": "Event start time in ISO 8601 format (e.g., '2024-03-15T14:00:00' or '2024-03-15T14:00:00-07:00')"
                    },
                    "end_time": {
                        "type": "string",
                        "description": "Event end time in ISO 8601 format"
                    },
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    },
                    "description": {
                        "type": "string",
                        "description": "Event description/notes (supports markdown and HTML)"
                    },
                    "location": {
                        "type": "string",
                        "description": "Event location (address or place name)"
                    },
                    "attendees": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of attendee email addresses"
                    },
                    "conference_solution": {
                        "type": "string",
                        "description": "Video conference type: 'hangoutsMeet' or 'meet' for Google Meet, 'zoom' for Zoom placeholder, or a full URL for custom video conference link"
                    },
                    "attachments": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "fileUrl": {"type": "string", "description": "URL to the file"},
                                "title": {"type": "string", "description": "Attachment title"},
                                "mimeType": {"type": "string", "description": "MIME type (e.g., 'application/pdf')"}
                            }
                        },
                        "description": "List of file attachments (must be Google Drive URLs or publicly accessible)"
                    },
                    "reminders": {
                        "type": "object",
                        "properties": {
                            "useDefault": {"type": "boolean"},
                            "overrides": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "method": {"type": "string", "description": "'email' or 'popup'"},
                                        "minutes": {"type": "integer", "description": "Minutes before event"}
                                    }
                                }
                            }
                        },
                        "description": "Reminder settings. Use {'useDefault': true} for calendar defaults, or {'overrides': [{'method': 'popup', 'minutes': 30}]} for custom reminders"
                    },
                    "recurrence": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "RRULE strings for recurring events (e.g., ['RRULE:FREQ=DAILY;COUNT=5'] for 5 days, ['RRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR'] for weekly on M/W/F)"
                    },
                    "color_id": {
                        "type": "string",
                        "description": "Event color ID (1-11): 1=Lavender, 2=Sage, 3=Grape, 4=Flamingo, 5=Banana, 6=Tangerine, 7=Peacock, 8=Graphite, 9=Blueberry, 10=Basil, 11=Tomato"
                    },
                    "visibility": {
                        "type": "string",
                        "enum": ["default", "public", "private", "confidential"],
                        "description": "Event visibility setting"
                    },
                    "transparency": {
                        "type": "string",
                        "enum": ["opaque", "transparent"],
                        "description": "Whether event blocks time ('opaque') or shows as free ('transparent')"
                    },
                    "timezone": {
                        "type": "string",
                        "description": "Timezone for the event (e.g., 'America/Los_Angeles', 'UTC'). Default: UTC"
                    }
                },
                "required": ["summary", "start_time", "end_time"]
            }
        ),
        Tool(
            name="calendar_update_event",
            description="Update an existing calendar event. Only provided fields will be updated, others remain unchanged.",
            inputSchema={
                "type": "object",
                "properties": {
                    "event_id": {
                        "type": "string",
                        "description": "Event ID to update (required)"
                    },
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    },
                    "summary": {
                        "type": "string",
                        "description": "New event title"
                    },
                    "start_time": {
                        "type": "string",
                        "description": "New start time in ISO 8601 format"
                    },
                    "end_time": {
                        "type": "string",
                        "description": "New end time in ISO 8601 format"
                    },
                    "description": {
                        "type": "string",
                        "description": "New event description"
                    },
                    "location": {
                        "type": "string",
                        "description": "New event location"
                    },
                    "attendees": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "New list of attendee email addresses (replaces existing)"
                    }
                },
                "required": ["event_id"]
            }
        ),
        Tool(
            name="calendar_delete_event",
            description="Delete a calendar event permanently. This action cannot be undone.",
            inputSchema={
                "type": "object",
                "properties": {
                    "event_id": {
                        "type": "string",
                        "description": "Event ID to delete (required)"
                    },
                    "calendar_id": {
                        "type": "string",
                        "description": "Calendar ID (default: 'primary')",
                        "default": "primary"
                    }
                },
                "required": ["event_id"]
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""
    
    try:
        if name == "calendar_list_calendars":
            return await handle_list_calendars(arguments)
        elif name == "calendar_today":
            return await handle_today(arguments)
        elif name == "calendar_upcoming":
            return await handle_upcoming(arguments)
        elif name == "calendar_search":
            return await handle_search(arguments)
        elif name == "calendar_get_event":
            return await handle_get_event(arguments)
        elif name == "calendar_now":
            return await handle_now(arguments)
        elif name == "calendar_create_event":
            return await handle_create_event(arguments)
        elif name == "calendar_update_event":
            return await handle_update_event(arguments)
        elif name == "calendar_delete_event":
            return await handle_delete_event(arguments)
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_list_calendars(arguments: dict) -> list[TextContent]:
    """Handle calendar_list_calendars tool call."""
    ensure_authenticated()
    
    calendars = list_calendars()
    
    if not calendars:
        return [TextContent(type="text", text="No calendars found.")]
    
    lines = [f"📅 Your Calendars ({len(calendars)}):\n"]
    
    for cal in calendars:
        primary = "⭐ " if cal.get('primary') else ""
        summary = cal.get('summary', 'Unknown')
        cal_id = cal.get('id', '')
        access = cal.get('accessRole', 'unknown')
        
        lines.append(f"{primary}{summary}")
        lines.append(f"   ID: {cal_id}")
        lines.append(f"   Access: {access}")
        if cal.get('description'):
            lines.append(f"   {cal['description']}")
        lines.append("")
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_today(arguments: dict) -> list[TextContent]:
    """Handle calendar_today tool call."""
    ensure_authenticated()
    
    calendar_id = arguments.get('calendar_id', 'primary')
    events = get_todays_events(calendar_id=calendar_id)
    
    if not events:
        return [TextContent(type="text", text="📭 No events today.")]
    
    lines = [f"📅 Today's Schedule ({len(events)} events):\n"]
    
    for event in events:
        lines.append(format_event(event))
        lines.append("")
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_upcoming(arguments: dict) -> list[TextContent]:
    """Handle calendar_upcoming tool call."""
    ensure_authenticated()
    
    days = arguments.get('days', 7)
    calendar_id = arguments.get('calendar_id', 'primary')
    max_results = arguments.get('max_results', 50)
    
    events = get_upcoming_events(days=days, calendar_id=calendar_id, max_results=max_results)
    
    if not events:
        return [TextContent(type="text", text=f"📭 No events in the next {days} days.")]
    
    lines = [f"📅 Upcoming Events (next {days} days, {len(events)} total):\n"]
    
    for event in events:
        lines.append(format_event(event))
        lines.append("")
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_search(arguments: dict) -> list[TextContent]:
    """Handle calendar_search tool call."""
    ensure_authenticated()
    
    query = arguments.get('query', '')
    calendar_id = arguments.get('calendar_id', 'primary')
    max_results = arguments.get('max_results', 50)
    
    if not query:
        return [TextContent(type="text", text="Please provide a search query.")]
    
    # Parse optional datetime parameters
    time_min = None
    time_max = None
    
    if arguments.get('time_min'):
        try:
            time_min = date_parser.parse(arguments['time_min'])
            # If naive datetime (no timezone), use calendar's default timezone
            if time_min.tzinfo is None:
                default_tz = get_default_timezone(calendar_id)
                time_min = default_tz.localize(time_min)
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Invalid time_min format: {e}\nExpected ISO 8601 format like '2026-01-01' or '2026-01-01T00:00:00'")]
    
    if arguments.get('time_max'):
        try:
            time_max = date_parser.parse(arguments['time_max'])
            # If naive datetime (no timezone), use calendar's default timezone
            if time_max.tzinfo is None:
                default_tz = get_default_timezone(calendar_id)
                time_max = default_tz.localize(time_max)
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Invalid time_max format: {e}\nExpected ISO 8601 format like '2026-01-31' or '2026-01-31T23:59:59'")]
    
    events = search_events(
        query, 
        calendar_id=calendar_id, 
        time_min=time_min,
        time_max=time_max,
        max_results=max_results
    )
    
    if not events:
        date_range = ""
        if time_min or time_max:
            if time_min and time_max:
                date_range = f" (between {time_min.strftime('%Y-%m-%d')} and {time_max.strftime('%Y-%m-%d')})"
            elif time_min:
                date_range = f" (after {time_min.strftime('%Y-%m-%d')})"
            else:
                date_range = f" (before {time_max.strftime('%Y-%m-%d')})"
        return [TextContent(type="text", text=f"📭 No events found for: {query}{date_range}")]
    
    search_desc = f"🔍 Search results for: {query}"
    if time_min or time_max:
        if time_min and time_max:
            search_desc += f"\n📅 Date range: {time_min.strftime('%Y-%m-%d')} to {time_max.strftime('%Y-%m-%d')}"
        elif time_min:
            search_desc += f"\n📅 After: {time_min.strftime('%Y-%m-%d')}"
        else:
            search_desc += f"\n📅 Before: {time_max.strftime('%Y-%m-%d')}"
    
    lines = [search_desc + "\n", f"Found {len(events)} events:\n"]
    
    for event in events:
        lines.append(format_event(event))
        lines.append("")
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_get_event(arguments: dict) -> list[TextContent]:
    """Handle calendar_get_event tool call."""
    ensure_authenticated()
    
    event_id = arguments.get('event_id', '')
    calendar_id = arguments.get('calendar_id', 'primary')
    
    if not event_id:
        return [TextContent(type="text", text="Please provide an event_id.")]
    
    event = get_event(event_id, calendar_id=calendar_id)
    
    if not event:
        return [TextContent(type="text", text=f"❌ Event not found: {event_id}")]
    
    output = format_event(event, include_details=True)
    return [TextContent(type="text", text=output)]


async def handle_now(arguments: dict) -> list[TextContent]:
    """Handle calendar_now tool call."""
    ensure_authenticated()
    
    calendar_id = arguments.get('calendar_id', 'primary')
    event = get_current_or_next_event(calendar_id=calendar_id)
    
    if not event:
        return [TextContent(type="text", text="📭 No current or upcoming events in the next 24 hours.")]
    
    lines = []
    if event.get('is_current'):
        lines.append("🔴 HAPPENING NOW:\n")
    else:
        lines.append("⏭️  NEXT UP:\n")
    
    lines.append(format_event(event, include_details=True))
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_create_event(arguments: dict) -> list[TextContent]:
    """Handle calendar_create_event tool call."""
    ensure_authenticated()
    
    # Required fields
    summary = arguments.get('summary')
    start_time_str = arguments.get('start_time')
    end_time_str = arguments.get('end_time')
    
    if not summary or not start_time_str or not end_time_str:
        return [TextContent(type="text", text="❌ Missing required fields: summary, start_time, and end_time are required.")]
    
    try:
        # Parse datetime strings
        start_time = date_parser.parse(start_time_str)
        end_time = date_parser.parse(end_time_str)
    except Exception as e:
        return [TextContent(type="text", text=f"❌ Invalid datetime format: {e}\nExpected ISO 8601 format like '2024-03-15T14:00:00'")]
    
    # Optional fields
    calendar_id = arguments.get('calendar_id', 'primary')
    description = arguments.get('description')
    location = arguments.get('location')
    attendees = arguments.get('attendees')
    conference_solution = arguments.get('conference_solution')
    attachments = arguments.get('attachments')
    reminders = arguments.get('reminders')
    recurrence = arguments.get('recurrence')
    color_id = arguments.get('color_id')
    visibility = arguments.get('visibility')
    transparency = arguments.get('transparency')
    timezone = arguments.get('timezone')
    
    # Create the event
    event = create_event(
        summary=summary,
        start_time=start_time,
        end_time=end_time,
        calendar_id=calendar_id,
        description=description,
        location=location,
        attendees=attendees,
        conference_solution=conference_solution,
        attachments=attachments,
        reminders=reminders,
        recurrence=recurrence,
        color_id=color_id,
        visibility=visibility,
        transparency=transparency,
        timezone=timezone
    )
    
    if not event:
        return [TextContent(type="text", text="❌ Failed to create event. Please check the error messages above.")]
    
    lines = ["✅ Event created successfully!\n"]
    lines.append(format_event(event, include_details=True))
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_update_event(arguments: dict) -> list[TextContent]:
    """Handle calendar_update_event tool call."""
    ensure_authenticated()
    
    event_id = arguments.get('event_id')
    if not event_id:
        return [TextContent(type="text", text="❌ Missing required field: event_id")]
    
    calendar_id = arguments.get('calendar_id', 'primary')
    
    # Parse optional datetime fields
    start_time = None
    end_time = None
    
    if arguments.get('start_time'):
        try:
            start_time = date_parser.parse(arguments['start_time'])
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Invalid start_time format: {e}")]
    
    if arguments.get('end_time'):
        try:
            end_time = date_parser.parse(arguments['end_time'])
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Invalid end_time format: {e}")]
    
    # Update the event
    event = update_event(
        event_id=event_id,
        calendar_id=calendar_id,
        summary=arguments.get('summary'),
        start_time=start_time,
        end_time=end_time,
        description=arguments.get('description'),
        location=arguments.get('location'),
        attendees=arguments.get('attendees')
    )
    
    if not event:
        return [TextContent(type="text", text=f"❌ Failed to update event: {event_id}")]
    
    lines = ["✅ Event updated successfully!\n"]
    lines.append(format_event(event, include_details=True))
    
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_delete_event(arguments: dict) -> list[TextContent]:
    """Handle calendar_delete_event tool call."""
    ensure_authenticated()
    
    event_id = arguments.get('event_id')
    if not event_id:
        return [TextContent(type="text", text="❌ Missing required field: event_id")]
    
    calendar_id = arguments.get('calendar_id', 'primary')
    
    # Get event details before deletion (for confirmation message)
    event = get_event(event_id, calendar_id=calendar_id)
    
    # Delete the event
    success = delete_event(event_id, calendar_id=calendar_id)
    
    if not success:
        return [TextContent(type="text", text=f"❌ Failed to delete event: {event_id}")]
    
    lines = ["✅ Event deleted successfully!"]
    if event:
        lines.append(f"\nDeleted event: {event.get('summary', 'No Title')}")
        lines.append(f"   {format_time_range(event.get('start_datetime'), event.get('end_datetime'), event.get('is_all_day', False))}")
    
    return [TextContent(type="text", text="\n".join(lines))]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
