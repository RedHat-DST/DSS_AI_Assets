"""
Format Converters Module.

Converts between different document formats:
- Markdown to Google Docs API requests
- Google Docs content to Markdown
- HTML to Markdown
"""

import re
from typing import List, Dict, Any, Tuple, Optional

import mistune


def _utf16_len(text: str) -> int:
    """
    Calculate the length of a string in UTF-16 code units.

    Google Docs API uses UTF-16 code units for indices, not Python character count.
    Emojis and some Unicode characters are multiple UTF-16 units.

    Args:
        text: String to measure

    Returns:
        Length in UTF-16 code units
    """
    return len(text.encode('utf-16-le')) // 2


class DocsRequestBuilder:
    """Builds Google Docs API requests from parsed content."""
    
    def __init__(self):
        self.requests = []
        self.current_index = 1  # Docs start at index 1
    
    def insert_text(self, text: str, style: Optional[Dict] = None, clear_formatting: bool = False) -> int:
        """Insert plain text and optionally style it.
        
        Args:
            text: Text to insert
            style: Optional style dict to apply
            clear_formatting: If True, explicitly clears bold/italic/underline
                            to prevent style inheritance from adjacent text
        """
        if not text:
            return self.current_index

        start_index = self.current_index
        # Use UTF-16 length for proper index calculation (Google Docs uses UTF-16)
        end_index = start_index + _utf16_len(text)
        
        # Insert the text
        self.requests.append({
            'insertText': {
                'location': {'index': start_index},
                'text': text
            }
        })
        
        # Apply styling if provided
        if style and text.strip():
            self.requests.append({
                'updateTextStyle': {
                    'range': {
                        'startIndex': start_index,
                        'endIndex': end_index
                    },
                    'textStyle': style,
                    'fields': ','.join(style.keys())
                }
            })
        elif clear_formatting and text.strip():
            # Explicitly clear formatting to prevent inheritance
            # Reset bold, italic, underline, and font family (to remove code formatting)
            self.requests.append({
                'updateTextStyle': {
                    'range': {
                        'startIndex': start_index,
                        'endIndex': end_index
                    },
                    'textStyle': {
                        'bold': False,
                        'italic': False,
                        'underline': False,
                        'weightedFontFamily': {
                            'fontFamily': 'Arial',
                            'weight': 400
                        },
                        'backgroundColor': {}  # Clear background color too
                    },
                    'fields': 'bold,italic,underline,weightedFontFamily,backgroundColor'
                }
            })
        
        self.current_index = end_index
        return end_index
    
    def insert_heading(self, text: str, level: int) -> int:
        """Insert a heading (H1-H6)."""
        start_index = self.current_index
        
        # Insert text with newline
        self.insert_text(text + '\n')
        
        # Map heading levels to Google Docs named styles
        heading_map = {
            1: 'HEADING_1',
            2: 'HEADING_2',
            3: 'HEADING_3',
            4: 'HEADING_4',
            5: 'HEADING_5',
            6: 'HEADING_6',
        }
        
        style_name = heading_map.get(level, 'HEADING_6')
        
        self.requests.append({
            'updateParagraphStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'paragraphStyle': {
                    'namedStyleType': style_name
                },
                'fields': 'namedStyleType'
            }
        })
        
        return self.current_index
    
    def insert_paragraph(self, text: str) -> int:
        """Insert a regular paragraph."""
        return self.insert_text(text + '\n')
    
    def insert_bold(self, text: str) -> int:
        """Insert bold text."""
        return self.insert_text(text, {'bold': True})
    
    def insert_italic(self, text: str) -> int:
        """Insert italic text."""
        return self.insert_text(text, {'italic': True})
    
    def insert_code(self, text: str) -> int:
        """Insert inline code with monospace font."""
        return self.insert_text(text, {
            'weightedFontFamily': {
                'fontFamily': 'Roboto Mono',
                'weight': 400
            },
            'backgroundColor': {
                'color': {'rgbColor': {'red': 0.95, 'green': 0.95, 'blue': 0.95}}
            }
        })
    
    def insert_code_block(self, code: str, language: str = '') -> int:
        """Insert a code block."""
        start_index = self.current_index
        
        # Insert code with newlines preserved
        text = code + '\n'
        self.insert_text(text)
        
        # Apply monospace styling
        self.requests.append({
            'updateTextStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'textStyle': {
                    'weightedFontFamily': {
                        'fontFamily': 'Roboto Mono',
                        'weight': 400
                    },
                    'fontSize': {'magnitude': 10, 'unit': 'PT'}
                },
                'fields': 'weightedFontFamily,fontSize'
            }
        })
        
        # Add indentation for code block appearance
        self.requests.append({
            'updateParagraphStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'paragraphStyle': {
                    'indentFirstLine': {'magnitude': 18, 'unit': 'PT'},
                    'indentStart': {'magnitude': 18, 'unit': 'PT'},
                    'shading': {
                        'backgroundColor': {
                            'color': {'rgbColor': {'red': 0.95, 'green': 0.95, 'blue': 0.95}}
                        }
                    }
                },
                'fields': 'indentFirstLine,indentStart,shading'
            }
        })
        
        return self.current_index
    
    def insert_link(self, text: str, url: str) -> int:
        """Insert a hyperlink using Google Docs default link styling."""
        start_index = self.current_index
        # Use UTF-16 length for proper index calculation
        end_index = start_index + _utf16_len(text)

        self.insert_text(text)
        
        # Only set the link URL - let Google Docs apply its default link styling
        self.requests.append({
            'updateTextStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': end_index
                },
                'textStyle': {
                    'link': {'url': url}
                },
                'fields': 'link'
            }
        })
        
        return self.current_index
    
    def insert_list_item(self, text: str, level: int = 0, ordered: bool = False) -> int:
        """Insert a list item."""
        start_index = self.current_index
        
        # Insert text with newline
        self.insert_text(text + '\n')
        
        # Create bullet/number list
        self.requests.append({
            'createParagraphBullets': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'bulletPreset': 'NUMBERED_DECIMAL_ALPHA_ROMAN' if ordered else 'BULLET_DISC_CIRCLE_SQUARE'
            }
        })
        
        # Adjust nesting level if needed
        if level > 0:
            self.requests.append({
                'updateParagraphStyle': {
                    'range': {
                        'startIndex': start_index,
                        'endIndex': self.current_index
                    },
                    'paragraphStyle': {
                        'indentStart': {'magnitude': 36 * (level + 1), 'unit': 'PT'},
                        'indentFirstLine': {'magnitude': 18 * (level + 1), 'unit': 'PT'}
                    },
                    'fields': 'indentStart,indentFirstLine'
                }
            })
        
        return self.current_index
    
    def insert_blockquote(self, text: str) -> int:
        """Insert a blockquote."""
        start_index = self.current_index
        
        self.insert_text(text + '\n')
        
        # Style as blockquote (indented with border)
        self.requests.append({
            'updateParagraphStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'paragraphStyle': {
                    'indentStart': {'magnitude': 36, 'unit': 'PT'},
                    'borderLeft': {
                        'color': {'color': {'rgbColor': {'red': 0.8, 'green': 0.8, 'blue': 0.8}}},
                        'width': {'magnitude': 3, 'unit': 'PT'},
                        'padding': {'magnitude': 12, 'unit': 'PT'},
                        'dashStyle': 'SOLID'
                    }
                },
                'fields': 'indentStart,borderLeft'
            }
        })
        
        # Make text italic
        self.requests.append({
            'updateTextStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'textStyle': {
                    'italic': True,
                    'foregroundColor': {
                        'color': {'rgbColor': {'red': 0.4, 'green': 0.4, 'blue': 0.4}}
                    }
                },
                'fields': 'italic,foregroundColor'
            }
        })
        
        return self.current_index
    
    def insert_horizontal_rule(self) -> int:
        """Insert a horizontal rule."""
        start_index = self.current_index
        
        # Insert a paragraph with bottom border
        self.insert_text('\n')
        
        self.requests.append({
            'updateParagraphStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.current_index
                },
                'paragraphStyle': {
                    'borderBottom': {
                        'color': {'color': {'rgbColor': {'red': 0.7, 'green': 0.7, 'blue': 0.7}}},
                        'width': {'magnitude': 1, 'unit': 'PT'},
                        'dashStyle': 'SOLID'
                    }
                },
                'fields': 'borderBottom'
            }
        })
        
        return self.current_index
    
    def insert_table(self, rows: List[List[str]]) -> int:
        """Insert a table."""
        if not rows:
            return self.current_index
            
        num_rows = len(rows)
        num_cols = max(len(row) for row in rows) if rows else 0
        
        if num_cols == 0:
            return self.current_index
        
        start_index = self.current_index
        
        # Insert table
        self.requests.append({
            'insertTable': {
                'rows': num_rows,
                'columns': num_cols,
                'location': {'index': start_index}
            }
        })
        
        # Tables take up space - we need to calculate the new index
        # Each cell adds at least 2 characters (for cell boundaries)
        # This is an approximation - actual index depends on content
        table_chars = 2  # Table start
        for row in rows:
            for cell in row:
                table_chars += len(cell) + 2  # Cell content + boundaries
            table_chars += 1  # Row boundary
        
        self.current_index = start_index + table_chars
        
        # Note: Populating table cells requires more complex logic
        # For now, we insert an empty table - content can be added via
        # separate text insertions at specific indices
        
        return self.current_index
    
    def get_requests(self) -> List[Dict[str, Any]]:
        """Get all accumulated requests."""
        return self.requests


class MarkdownRenderer(mistune.HTMLRenderer):
    """Custom renderer that builds Google Docs API requests."""
    
    def __init__(self, builder: DocsRequestBuilder):
        super().__init__()
        self.builder = builder
        self.list_level = 0
        self.in_list = False
        self.ordered_list = False
    
    def text(self, text: str) -> str:
        """Plain text."""
        return text
    
    def paragraph(self, text: str) -> str:
        """Paragraph with inline formatting."""
        self._insert_formatted_text(text)
        self.builder.insert_text('\n')  # End paragraph
        return ''
    
    def _insert_formatted_text(self, text: str) -> None:
        """
        Parse inline markers and insert text with proper styling.
        
        Handles nested markers like __BOLD____ITALIC__text__/ITALIC____/BOLD__
        by tracking active styles and applying them cumulatively.
        """
        # Pattern to find all markers and capture content between them
        # Markers: __BOLD__, __/BOLD__, __ITALIC__, __/ITALIC__, __CODE__, __/CODE__
        # Links: __LINK__text__URL__url__/LINK__
        
        # First, handle links specially since they have a different structure
        # Replace links with a simpler marker format that includes the URL
        link_pattern = r'__LINK__(.+?)__URL__(.+?)__/LINK__'
        
        # Track positions and replacements for links
        link_matches = list(re.finditer(link_pattern, text))
        
        # Process text segment by segment
        pos = 0
        active_styles = {'bold': False, 'italic': False, 'code': False}
        
        while pos < len(text):
            # Check if we're at a link
            link_match = None
            for lm in link_matches:
                if lm.start() == pos:
                    link_match = lm
                    break
            
            if link_match:
                # Insert the link with current active styles
                link_text = link_match.group(1)
                link_url = link_match.group(2)
                self.builder.insert_link(link_text, link_url)
                pos = link_match.end()
                continue
            
            # Check for style markers
            marker_match = re.match(r'__(BOLD|ITALIC|CODE|/BOLD|/ITALIC|/CODE)__', text[pos:])
            if marker_match:
                marker = marker_match.group(1)
                if marker == 'BOLD':
                    active_styles['bold'] = True
                elif marker == '/BOLD':
                    active_styles['bold'] = False
                elif marker == 'ITALIC':
                    active_styles['italic'] = True
                elif marker == '/ITALIC':
                    active_styles['italic'] = False
                elif marker == 'CODE':
                    active_styles['code'] = True
                elif marker == '/CODE':
                    active_styles['code'] = False
                pos += marker_match.end()
                continue
            
            # Find the next marker or link
            next_marker_pos = len(text)
            
            # Check for next style marker
            next_style = re.search(r'__(BOLD|ITALIC|CODE|/BOLD|/ITALIC|/CODE)__', text[pos:])
            if next_style:
                next_marker_pos = min(next_marker_pos, pos + next_style.start())
            
            # Check for next link
            for lm in link_matches:
                if lm.start() > pos:
                    next_marker_pos = min(next_marker_pos, lm.start())
                    break
            
            # Extract plain text segment
            segment = text[pos:next_marker_pos]
            
            if segment:
                # Build style dict based on active styles
                if active_styles['code']:
                    # Code style takes precedence
                    self.builder.insert_code(segment)
                elif active_styles['bold'] and active_styles['italic']:
                    # Both bold and italic
                    self.builder.insert_text(segment, {'bold': True, 'italic': True})
                elif active_styles['bold']:
                    self.builder.insert_bold(segment)
                elif active_styles['italic']:
                    self.builder.insert_italic(segment)
                else:
                    # Plain text - clear formatting to prevent inheritance from adjacent styled text
                    self.builder.insert_text(segment, clear_formatting=True)
            
            pos = next_marker_pos
    
    def heading(self, text: str, level: int, **attrs) -> str:
        """Heading H1-H6 with inline formatting support."""
        start_index = self.builder.current_index
        
        # Insert formatted text
        self._insert_formatted_text(text)
        self.builder.insert_text('\n')
        
        # Map heading levels to Google Docs named styles
        heading_map = {
            1: 'HEADING_1',
            2: 'HEADING_2',
            3: 'HEADING_3',
            4: 'HEADING_4',
            5: 'HEADING_5',
            6: 'HEADING_6',
        }
        
        style_name = heading_map.get(level, 'HEADING_6')
        
        self.builder.requests.append({
            'updateParagraphStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.builder.current_index
                },
                'paragraphStyle': {
                    'namedStyleType': style_name
                },
                'fields': 'namedStyleType'
            }
        })
        
        return ''
    
    def strong(self, text: str) -> str:
        """Bold text - return marker for inline processing."""
        return f'__BOLD__{text}__/BOLD__'
    
    def emphasis(self, text: str) -> str:
        """Italic text - return marker for inline processing."""
        return f'__ITALIC__{text}__/ITALIC__'
    
    def codespan(self, text: str) -> str:
        """Inline code - return marker for inline processing."""
        return f'__CODE__{text}__/CODE__'
    
    def link(self, text: str, url: str, title: Optional[str] = None) -> str:
        """Hyperlink - return marker for inline processing."""
        return f'__LINK__{text}__URL__{url}__/LINK__'
    
    def block_code(self, code: str, info: Optional[str] = None) -> str:
        """Code block."""
        language = info or ''
        self.builder.insert_code_block(code.rstrip('\n'), language)
        return ''
    
    def block_quote(self, text: str) -> str:
        """Block quote with inline formatting support."""
        start_index = self.builder.current_index
        
        # Insert formatted text
        text = text.strip()
        self._insert_formatted_text(text)
        self.builder.insert_text('\n')
        
        # Style as blockquote (indented with border)
        self.builder.requests.append({
            'updateParagraphStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.builder.current_index
                },
                'paragraphStyle': {
                    'indentStart': {'magnitude': 36, 'unit': 'PT'},
                    'borderLeft': {
                        'color': {'color': {'rgbColor': {'red': 0.8, 'green': 0.8, 'blue': 0.8}}},
                        'width': {'magnitude': 3, 'unit': 'PT'},
                        'padding': {'magnitude': 12, 'unit': 'PT'},
                        'dashStyle': 'SOLID'
                    }
                },
                'fields': 'indentStart,borderLeft'
            }
        })
        
        # Make text italic and gray
        self.builder.requests.append({
            'updateTextStyle': {
                'range': {
                    'startIndex': start_index,
                    'endIndex': self.builder.current_index
                },
                'textStyle': {
                    'italic': True,
                    'foregroundColor': {
                        'color': {'rgbColor': {'red': 0.4, 'green': 0.4, 'blue': 0.4}}
                    }
                },
                'fields': 'italic,foregroundColor'
            }
        })
        
        return ''
    
    def list(self, body: str, ordered: bool, **attrs) -> str:
        """List container - processes collected list items."""
        # Parse the placeholder markers from list items and insert with correct bullet type
        # Format: __LIST_ITEM__text__/LIST_ITEM__
        pattern = r'__LIST_ITEM__(.+?)__/LIST_ITEM__'
        items = re.findall(pattern, body, re.DOTALL)
        
        for item_text in items:
            start_index = self.builder.current_index
            
            # Insert the formatted text
            self._insert_formatted_text(item_text.strip())
            self.builder.insert_text('\n')
            
            # Apply bullet/numbering to the paragraph
            self.builder.requests.append({
                'createParagraphBullets': {
                    'range': {
                        'startIndex': start_index,
                        'endIndex': self.builder.current_index
                    },
                    'bulletPreset': 'NUMBERED_DECIMAL_ALPHA_ROMAN' if ordered else 'BULLET_DISC_CIRCLE_SQUARE'
                }
            })
            
            # Adjust nesting level if needed
            if self.list_level > 0:
                self.builder.requests.append({
                    'updateParagraphStyle': {
                        'range': {
                            'startIndex': start_index,
                            'endIndex': self.builder.current_index
                        },
                        'paragraphStyle': {
                            'indentStart': {'magnitude': 36 * (self.list_level + 1), 'unit': 'PT'},
                            'indentFirstLine': {'magnitude': 18 * (self.list_level + 1), 'unit': 'PT'}
                        },
                        'fields': 'indentStart,indentFirstLine'
                    }
                })
        
        return ''
    
    def list_item(self, text: str, **attrs) -> str:
        """List item - returns placeholder for list() to process."""
        # Return a placeholder that list() will parse
        # This defers insertion until we know if the list is ordered or not
        return f'__LIST_ITEM__{text}__/LIST_ITEM__'
    
    def thematic_break(self) -> str:
        """Horizontal rule."""
        self.builder.insert_horizontal_rule()
        return ''
    
    def linebreak(self) -> str:
        """Line break."""
        return '\n'


def markdown_to_docs_requests(markdown_text: str) -> List[Dict[str, Any]]:
    """
    Convert markdown text to Google Docs API requests.
    
    Args:
        markdown_text: Markdown formatted text
        
    Returns:
        List of Google Docs API request objects
    """
    builder = DocsRequestBuilder()
    renderer = MarkdownRenderer(builder)
    md = mistune.create_markdown(renderer=renderer)
    
    # Parse and render markdown
    md(markdown_text)
    
    return builder.get_requests()


def docs_to_markdown(doc_content: Dict[str, Any]) -> str:
    """
    Convert Google Docs content to Markdown.
    
    Handles both old document structure (body.content) and new tab structure (tabs[].documentTab.body.content).
    
    Args:
        doc_content: Google Docs document content (from docs.get())
        
    Returns:
        Markdown formatted string
    """
    markdown_lines = []
    
    # Check if document uses new tab structure
    tabs = doc_content.get('tabs', [])
    
    if tabs:
        # New structure: iterate through tabs
        for tab in tabs:
            if 'documentTab' in tab:
                document_tab = tab['documentTab']
                body = document_tab.get('body', {})
                content = body.get('content', [])
                
                # Get lists from tab level (new structure) - merge with doc level for compatibility
                tab_lists = document_tab.get('lists', {})
                doc_lists = doc_content.get('lists', {})
                merged_lists = {**doc_lists, **tab_lists}
                
                # Create a context dict with the merged lists
                context = {**doc_content, 'lists': merged_lists}
                
                for element in content:
                    if 'paragraph' in element:
                        para = element['paragraph']
                        para_md = _paragraph_to_markdown(para, context)
                        if para_md:
                            markdown_lines.append(para_md)
                    elif 'table' in element:
                        table_md = _table_to_markdown(element['table'], context)
                        if table_md:
                            markdown_lines.append(table_md)
    else:
        # Old structure: content is directly in body
        body = doc_content.get('body', {})
        content = body.get('content', [])
        
        for element in content:
            if 'paragraph' in element:
                para = element['paragraph']
                para_md = _paragraph_to_markdown(para, doc_content)
                if para_md:
                    markdown_lines.append(para_md)
            elif 'table' in element:
                table_md = _table_to_markdown(element['table'], doc_content)
                if table_md:
                    markdown_lines.append(table_md)
    
    return '\n'.join(markdown_lines)


def _paragraph_to_markdown(para: Dict[str, Any], doc_content: Dict[str, Any]) -> str:
    """Convert a paragraph element to markdown."""
    elements = para.get('elements', [])
    style = para.get('paragraphStyle', {})
    bullet = para.get('bullet')
    
    text_parts = []
    
    for elem in elements:
        if 'textRun' in elem:
            text_run = elem['textRun']
            content = text_run.get('content', '')
            text_style = text_run.get('textStyle', {})
            
            # Apply text formatting
            formatted = content.rstrip('\n')
            
            if text_style.get('bold'):
                formatted = f'**{formatted}**'
            if text_style.get('italic'):
                formatted = f'*{formatted}*'
            if text_style.get('link'):
                url = text_style['link'].get('url', '')
                formatted = f'[{formatted}]({url})'
            
            # Check for code (monospace font)
            font_family = text_style.get('weightedFontFamily', {}).get('fontFamily', '')
            if 'mono' in font_family.lower() or 'courier' in font_family.lower():
                formatted = f'`{formatted}`'
            
            text_parts.append(formatted)
    
    text = ''.join(text_parts)
    
    if not text.strip():
        return ''
    
    # Check for heading styles
    named_style = style.get('namedStyleType', '')
    if named_style.startswith('HEADING_'):
        level = int(named_style[-1])
        return '#' * level + ' ' + text
    
    # Check for bullet/list
    if bullet:
        list_id = bullet.get('listId')
        nesting_level = bullet.get('nestingLevel', 0)
        indent = '  ' * nesting_level
        
        # Determine if ordered or unordered
        lists = doc_content.get('lists', {})
        list_props = lists.get(list_id, {}).get('listProperties', {})
        nesting = list_props.get('nestingLevels', [])
        
        is_ordered = False
        if nesting and len(nesting) > nesting_level:
            level_props = nesting[nesting_level]
            glyph_type = level_props.get('glyphType', '')
            glyph_symbol = level_props.get('glyphSymbol', '')
            
            # Determine list type:
            # - Bullet lists have glyphSymbol set (●, ○, ■, etc.)
            # - Numbered lists have glyphType set (DECIMAL, ALPHA, ROMAN, etc.) but no glyphSymbol
            if glyph_symbol:
                # Explicit bullet symbol = bullet list
                is_ordered = False
            elif glyph_type:
                # Has glyph type (DECIMAL, ALPHA, ROMAN, etc.) = numbered list
                is_ordered = glyph_type in [
                    'DECIMAL', 'ALPHA', 'ROMAN', 
                    'ZERO_DECIMAL', 'UPPER_ALPHA', 'UPPER_ROMAN',
                    'NUMBER'
                ] or 'DECIMAL' in glyph_type or 'ALPHA' in glyph_type or 'ROMAN' in glyph_type
        
        if is_ordered:
            return f'{indent}1. {text}'
        
        return f'{indent}- {text}'
    
    # Check for blockquote (indented with border)
    if style.get('borderLeft'):
        return f'> {text}'
    
    return text


def _table_to_markdown(table: Dict[str, Any], doc_content: Dict[str, Any]) -> str:
    """Convert a table element to markdown."""
    rows = table.get('tableRows', [])
    if not rows:
        return ''
    
    md_rows = []
    
    for row in rows:
        cells = row.get('tableCells', [])
        cell_texts = []
        
        for cell in cells:
            cell_content = cell.get('content', [])
            cell_text = ''
            
            for elem in cell_content:
                if 'paragraph' in elem:
                    para_text = _paragraph_to_markdown(elem['paragraph'], doc_content)
                    cell_text += para_text
            
            cell_texts.append(cell_text.strip())
        
        md_rows.append('| ' + ' | '.join(cell_texts) + ' |')
    
    # Add header separator after first row
    if len(md_rows) > 0:
        num_cols = md_rows[0].count('|') - 1
        separator = '| ' + ' | '.join(['---'] * num_cols) + ' |'
        md_rows.insert(1, separator)
    
    return '\n'.join(md_rows)


def html_to_markdown(html: str) -> str:
    """
    Convert HTML to Markdown.
    
    Args:
        html: HTML string
        
    Returns:
        Markdown formatted string
    """
    # Basic HTML to Markdown conversion
    text = html
    
    # Headers
    for i in range(6, 0, -1):
        text = re.sub(f'<h{i}[^>]*>(.+?)</h{i}>', '#' * i + r' \1\n', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Bold
    text = re.sub(r'<(strong|b)>(.+?)</\1>', r'**\2**', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Italic
    text = re.sub(r'<(em|i)>(.+?)</\1>', r'*\2*', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Code
    text = re.sub(r'<code>(.+?)</code>', r'`\1`', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Links
    text = re.sub(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.+?)</a>', r'[\2](\1)', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Paragraphs
    text = re.sub(r'<p[^>]*>(.+?)</p>', r'\1\n\n', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Line breaks
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
    
    # Lists
    text = re.sub(r'<li[^>]*>(.+?)</li>', r'- \1\n', text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r'</?[uo]l[^>]*>', '', text, flags=re.IGNORECASE)
    
    # Blockquotes
    text = re.sub(r'<blockquote[^>]*>(.+?)</blockquote>', r'> \1\n', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Remove remaining tags
    text = re.sub(r'<[^>]+>', '', text)
    
    # Decode HTML entities
    text = text.replace('&amp;', '&')
    text = text.replace('&lt;', '<')
    text = text.replace('&gt;', '>')
    text = text.replace('&nbsp;', ' ')
    text = text.replace('&quot;', '"')
    
    # Clean up whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    return text.strip()


def plain_text_to_requests(text: str) -> List[Dict[str, Any]]:
    """
    Convert plain text to basic Google Docs insert request.
    
    Args:
        text: Plain text content
        
    Returns:
        List containing a single insertText request
    """
    return [{
        'insertText': {
            'location': {'index': 1},
            'text': text
        }
    }]

