"""
Google Drive Assistant - MCP server and CLI for Google Drive, Docs, Sheets, and Slides.
"""

__version__ = "0.1.0"

