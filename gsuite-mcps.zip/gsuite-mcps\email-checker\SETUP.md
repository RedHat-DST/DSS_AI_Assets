# Google Cloud Setup Guide

This guide walks you through setting up Google Cloud OAuth credentials for the Gmail Email Assistant.

## Prerequisites

- A Google account (your Red Hat Google Workspace account)
- Access to [Google Cloud Console](https://console.cloud.google.com/)

## Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click the project dropdown at the top of the page
3. Click **New Project**
4. Enter a project name (e.g., "Gmail Email Assistant")
5. Click **Create**
6. Wait for the project to be created, then select it from the dropdown

## Step 2: Enable the Gmail API

1. In the left sidebar, go to **APIs & Services** > **Library**
2. Search for "Gmail API"
3. Click on **Gmail API**
4. Click **Enable**

## Step 3: Configure OAuth Consent Screen

1. In the left sidebar, go to **APIs & Services** > **OAuth consent screen**
2. Select **Internal** (for Google Workspace users) or **External** (for personal accounts)
3. Click **Create**
4. Fill in the required fields:
   - **App name**: Gmail Email Assistant
   - **User support email**: Your email address
   - **Developer contact email**: Your email address
5. Click **Save and Continue**
6. On the **Data Access** page, click **Add or Remove Scopes**
7. Find and select these scopes:
   - `https://www.googleapis.com/auth/gmail.readonly` - Read emails
   - `https://www.googleapis.com/auth/gmail.compose` - Create drafts
   - `https://www.googleapis.com/auth/gmail.modify` - Add/remove labels, mark read/unread
   - `https://www.googleapis.com/auth/gmail.labels` - Create, update, delete labels
8. Click **Update**, then **Save and Continue**
9. On the **Test users** page (if External):
   - Click **Add Users**
   - Add your email address
   - Click **Save and Continue**
10. Click **Back to Dashboard**

## Step 4: Create OAuth 2.0 Credentials

1. In the left sidebar, go to **APIs & Services** > **Credentials**
2. Click **+ Create Credentials** at the top
3. Select **OAuth client ID**
4. For **Application type**, select **Desktop app**
5. Enter a name (e.g., "Gmail Assistant Desktop")
6. Click **Create**
7. A dialog will appear with your credentials
8. Click **Download JSON**
9. Rename the downloaded file to `credentials.json`
10. Move it to this project directory:
    ```bash
    mv ~/Downloads/client_secret_*.json /home/mmcgrath/RedHat/email-checker/credentials.json
    ```

## Step 5: Install Dependencies

```bash
cd /home/mmcgrath/RedHat/email-checker
pip install -r requirements.txt
```

## Step 6: First-Time Authentication

Run the CLI to trigger the OAuth flow:

```bash
python -m src.cli inbox
```

This will:
1. Open your browser to Google's authorization page
2. Ask you to sign in and grant permissions
3. Redirect back to the local callback server
4. Save your token to `gdrive_token.json`

After this, you won't need to re-authenticate unless you revoke access or the token expires.

## Troubleshooting

### "Access blocked: This app's request is invalid"
- Make sure you've added yourself as a test user (Step 3.9)
- Verify the redirect URI matches `http://localhost:8081/`

### "Permission denied" errors
- Ensure you selected all required scopes in Step 3.7 (readonly, compose, modify, labels)
- Try deleting `gdrive_token.json` and re-authenticating

### Token refresh issues
- Delete `gdrive_token.json` and run the CLI again
- The token will be automatically refreshed when needed

## Security Notes

- **Never commit `credentials.json` or `gdrive_token.json` to git**
- These files contain sensitive OAuth credentials
- The `.gitignore` file is configured to exclude them

## File Locations

After setup, you should have:

```
email-checker/
├── credentials.json      # Your OAuth client credentials (from Step 4)
├── gdrive_token.json     # Auto-generated after first auth (Step 6)
└── ...
```

