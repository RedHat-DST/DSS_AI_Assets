"""
OAuth 2.0 Authentication for Gmail API.

Handles the complete OAuth lifecycle:
- Initial authorization flow (desktop with browser)
- Token persistence and automatic refresh
- Service building for Gmail API
"""

import os
import http.server
import socketserver
import webbrowser
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse, parse_qs

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build


# Gmail scopes: read, compose (for drafts), and modify (for labels)
SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/gmail.compose',
    'https://www.googleapis.com/auth/gmail.modify'
]

# Default paths relative to project root
PROJECT_ROOT = Path(__file__).parent.parent
DEFAULT_CREDENTIALS_FILE = PROJECT_ROOT / "credentials.json"
DEFAULT_TOKEN_FILE = PROJECT_ROOT / "gdrive_token.json"


class GmailAuth:
    """Handles Google OAuth 2.0 authentication for Gmail API."""

    def __init__(
        self,
        credentials_file: Optional[Path] = None,
        token_file: Optional[Path] = None
    ):
        """
        Initialize authentication handler.

        Args:
            credentials_file: Path to OAuth client credentials (from Google Cloud Console)
            token_file: Path to store/load user authorization tokens
        """
        self.credentials_file = Path(credentials_file) if credentials_file else DEFAULT_CREDENTIALS_FILE
        self.token_file = Path(token_file) if token_file else DEFAULT_TOKEN_FILE
        self.credentials: Optional[Credentials] = None
        self._gmail_service = None

    def authenticate(self) -> bool:
        """
        Authenticate with Google Gmail API.

        Flow:
        1. Check for existing token file
        2. Load and validate credentials
        3. Refresh if expired (with refresh_token)
        4. Start OAuth flow if no valid credentials

        Returns:
            True if authentication successful, False otherwise
        """
        try:
            # Check credentials.json exists
            if not self.credentials_file.exists():
                print(f"❌ credentials.json not found at: {self.credentials_file}")
                print("   Please follow SETUP.md to configure Google Cloud credentials.")
                return False

            # Load existing token
            if self.token_file.exists():
                try:
                    self.credentials = Credentials.from_authorized_user_file(
                        str(self.token_file), SCOPES
                    )
                except Exception as e:
                    print(f"⚠️  Failed to load existing token: {e}")
                    self.credentials = None

            # Refresh if expired
            if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                try:
                    print("🔄 Refreshing expired token...")
                    self.credentials.refresh(Request())
                    self._save_token()
                    print("✅ Token refreshed successfully")
                except Exception as e:
                    print(f"⚠️  Token refresh failed: {e}")
                    self.credentials = None

            # Start OAuth flow if needed
            if not self.credentials or not self.credentials.valid:
                print("🔐 Starting OAuth authorization flow...")
                if not self._start_oauth_flow():
                    return False

            # Save token for future use
            self._save_token()
            return True

        except Exception as e:
            print(f"❌ Authentication failed: {e}")
            return False

    def _start_oauth_flow(self) -> bool:
        """Start OAuth 2.0 authorization flow with browser."""
        # Prevent automatic browser opening issues
        os.environ['BROWSER'] = ''

        flow = InstalledAppFlow.from_client_secrets_file(
            str(self.credentials_file), SCOPES
        )

        # Try multiple ports in case some are in use
        port = self._find_available_port([8085, 8086, 8087, 8088, 8089, 8090])
        if not port:
            print("❌ Could not find an available port for OAuth callback")
            return False

        callback_result = {'done': False, 'code': None, 'error': None}

        class CallbackHandler(http.server.BaseHTTPRequestHandler):
            """Handle OAuth callback."""

            def log_message(self, format, *args):
                pass  # Suppress request logs

            def do_GET(self):
                parsed = urlparse(self.path)
                query_params = parse_qs(parsed.query)

                if 'code' in query_params:
                    callback_result['code'] = query_params['code'][0]
                    callback_result['done'] = True
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(b'''
                        <html>
                        <head><title>Gmail Assistant</title></head>
                        <body style="font-family: sans-serif; text-align: center; padding: 50px;">
                            <h1 style="color: #28a745;">Authentication Successful!</h1>
                            <p>You can close this window and return to the terminal.</p>
                        </body>
                        </html>
                    ''')
                elif 'error' in query_params:
                    callback_result['error'] = query_params['error'][0]
                    callback_result['done'] = True
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(b'''
                        <html>
                        <head><title>Gmail Assistant</title></head>
                        <body style="font-family: sans-serif; text-align: center; padding: 50px;">
                            <h1 style="color: #dc3545;">Authentication Failed</h1>
                            <p>Please try again.</p>
                        </body>
                        </html>
                    ''')

        # Set redirect URI
        flow.redirect_uri = f'http://localhost:{port}/'
        auth_url, state = flow.authorization_url(
            prompt='select_account',
            access_type='offline'  # Request refresh token
        )

        print(f"\n{'='*60}")
        print("GOOGLE AUTHORIZATION REQUIRED")
        print(f"{'='*60}")
        print(f"\nOpening browser to authorize Gmail access...")
        print(f"If the browser doesn't open, visit:\n\n{auth_url}\n")

        # Open browser
        webbrowser.open(auth_url)

        # Start callback server
        try:
            with socketserver.TCPServer(("", port), CallbackHandler) as httpd:
                httpd.timeout = 1  # 1 second timeout for handle_request
                timeout = 180  # 3 minutes total
                start_time = time.time()

                while not callback_result['done']:
                    httpd.handle_request()
                    if time.time() - start_time > timeout:
                        print("❌ Authorization timed out after 3 minutes")
                        return False
        except OSError as e:
            if "Address already in use" in str(e):
                print(f"❌ Port {port} is already in use. Please close other applications using it.")
            else:
                print(f"❌ Server error: {e}")
            return False

        # Check for errors
        if callback_result['error']:
            print(f"❌ Authorization denied: {callback_result['error']}")
            return False

        # Exchange code for token
        if callback_result['code']:
            try:
                flow.fetch_token(code=callback_result['code'])
                self.credentials = flow.credentials
                print("✅ Authorization successful!")
                return True
            except Exception as e:
                print(f"❌ Failed to exchange code for token: {e}")
                return False

        return False

    def _find_available_port(self, ports: list) -> Optional[int]:
        """Find an available port from the list."""
        import socket
        for port in ports:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('', port))
                    return port
            except OSError:
                continue
        return None

    def _save_token(self):
        """Save credentials to token file with secure permissions."""
        if not self.credentials:
            return

        try:
            with open(self.token_file, 'w') as token:
                token.write(self.credentials.to_json())
            self.token_file.chmod(0o600)  # Owner read/write only
        except Exception as e:
            print(f"⚠️  Failed to save token: {e}")

    def get_gmail_service(self):
        """
        Get authenticated Gmail API service.

        Returns:
            Gmail API service object

        Raises:
            RuntimeError: If not authenticated
        """
        if not self.credentials or not self.credentials.valid:
            if not self.authenticate():
                raise RuntimeError("Failed to authenticate with Gmail")

        if not self._gmail_service:
            self._gmail_service = build('gmail', 'v1', credentials=self.credentials)

        return self._gmail_service

    def is_authenticated(self) -> bool:
        """Check if currently authenticated with valid credentials."""
        return self.credentials is not None and self.credentials.valid

    def get_user_email(self) -> Optional[str]:
        """Get the authenticated user's email address."""
        try:
            service = self.get_gmail_service()
            profile = service.users().getProfile(userId='me').execute()
            return profile.get('emailAddress')
        except Exception:
            return None


# Singleton instance for convenience
_default_auth: Optional[GmailAuth] = None


def get_auth() -> GmailAuth:
    """Get the default GmailAuth instance."""
    global _default_auth
    if _default_auth is None:
        _default_auth = GmailAuth()
    return _default_auth


def get_gmail_service():
    """Convenience function to get authenticated Gmail service."""
    return get_auth().get_gmail_service()

