"""Gmail Email Assistant - Core modules."""

