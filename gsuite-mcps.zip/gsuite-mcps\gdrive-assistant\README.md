# Google Drive Assistant

A comprehensive Google Drive, Docs, Sheets, and Slides assistant providing both CLI tools and MCP server integration for Cursor.

## Features

- **Google Drive**: List, search, upload, download, share files and folders
- **Google Docs**: Create documents from markdown, read/export content
  - **Tabs Support** - List, read, export, create, update, and delete tabs in multi-tab documents
- **Google Sheets**: Create spreadsheets, read/write cells, import/export CSV
- **Google Slides**: Create presentations, add slides, export to PDF
- **MCP Integration**: Full Model Context Protocol support for Cursor
- **Markdown Conversion**: Advanced markdown to Google Docs formatting

## Quick Start

### 1. Setup

Follow [SETUP.md](SETUP.md) to configure Google Cloud credentials.

**TL;DR for existing email-checker users:**
```bash
# Enable Drive/Docs/Sheets/Slides APIs in your Google Cloud project
# Then:
ln -s ../email-checker/credentials.json credentials.json
pip install -r requirements.txt
python -m src.cli auth_status
```

### 2. CLI Usage

```bash
# List files
python -m src.cli list

# Search
python -m src.cli search "quarterly report"

# Create Google Doc from markdown
python -m src.cli docs create "Meeting Notes" --from-md notes.md

# Upload file
python -m src.cli upload document.pdf

# Download file
python -m src.cli download <file_id> ./local_copy.pdf
```

### 3. MCP Server

Add to your Cursor MCP configuration:

```json
{
  "mcpServers": {
    "gdrive-assistant": {
      "command": "python",
      "args": ["/path/to/gdrive-assistant/mcp_server.py"]
    }
  }
}
```

Then use tools like `gdrive_search`, `gdocs_create`, `gsheets_read` directly in Cursor.

## MCP Tools

### Drive Tools
| Tool | Description |
|------|-------------|
| `gdrive_list` | List files in folder |
| `gdrive_search` | Search by name/content |
| `gdrive_download` | Download file |
| `gdrive_upload` | Upload file |
| `gdrive_create_folder` | Create folder |
| `gdrive_share` | Share with user |

### Docs Tools
| Tool | Description |
|------|-------------|
| `gdocs_create` | Create doc with markdown |
| `gdocs_create_from_file` | Create from local .md file |
| `gdocs_read` | Read doc content |
| `gdocs_export` | Export to pdf/docx/md |
| `gdocs_list_tabs` | List all tabs in doc |
| `gdocs_read_tab` | Read specific tab content |
| `gdocs_read_tab_markdown` | Read tab as markdown |
| `gdocs_export_tab` | Export specific tab |
| `gdocs_create_tab` | Create a new tab |
| `gdocs_update_tab` | Update tab title or icon |
| `gdocs_delete_tab` | Delete a tab (and child tabs) |

### Sheets Tools
| Tool | Description |
|------|-------------|
| `gsheets_create` | Create spreadsheet |
| `gsheets_read` | Read cell range |
| `gsheets_write` | Write to cells |
| `gsheets_export_csv` | Export as CSV |

### Slides Tools
| Tool | Description |
|------|-------------|
| `gslides_create` | Create presentation |
| `gslides_add_slide` | Add new slide |
| `gslides_export_pdf` | Export to PDF |

## CLI Commands

```bash
# Drive
python -m src.cli list [folder_id]
python -m src.cli search "query"
python -m src.cli download <id> [path]
python -m src.cli upload <path> [folder]
python -m src.cli mkdir <name> [parent]
python -m src.cli share <id> <email>
python -m src.cli info <id>

# Docs
python -m src.cli docs create "Title" [--from-md file.md]
python -m src.cli docs read <id> [--markdown] [--tab <tab_id>] [--tab-index <index>]
python -m src.cli docs export <id> <path> [-f format] [--tab <tab_id>]
python -m src.cli docs tabs <id>  # List tabs
python -m src.cli docs tab create <id> "Title" [--index N] [--parent-tab <id>] [--icon EMOJI]
python -m src.cli docs tab update <id> <tab_id> [--title "New"] [--icon EMOJI]
python -m src.cli docs tab delete <id> <tab_id> [-y]

# Sheets
python -m src.cli sheets create "Title"
python -m src.cli sheets read <id> "A1:D10"
python -m src.cli sheets info <id>
python -m src.cli sheets export <id> "Sheet1" output.csv

# Slides
python -m src.cli slides create "Title"
python -m src.cli slides info <id>
python -m src.cli slides export <id> output.pdf

# Auth
python -m src.cli auth_status
```

## Project Structure

```
gdrive-assistant/
├── mcp_server.py         # MCP server for Cursor
├── src/
│   ├── auth.py           # OAuth 2.0 authentication
│   ├── drive_ops.py      # Drive file operations
│   ├── docs_ops.py       # Docs operations
│   ├── sheets_ops.py     # Sheets operations
│   ├── slides_ops.py     # Slides operations
│   ├── converters.py     # Markdown <-> Docs conversion
│   └── cli.py            # CLI interface
├── .cursorrules          # Cursor AI rules
├── SETUP.md              # Setup instructions
└── requirements.txt      # Python dependencies
```

## Markdown Conversion

The assistant converts markdown to properly formatted Google Docs:

- **Headers**: `# H1` to `###### H6` → Google Docs heading styles
- **Bold/Italic**: `**bold**`, `*italic*` → Text formatting
- **Code**: `` `inline` `` and code blocks → Monospace with background
- **Lists**: Bullet and numbered lists with nesting
- **Links**: `[text](url)` → Hyperlinks
- **Blockquotes**: `> quote` → Indented with left border
- **Tables**: Markdown tables → Google Docs tables

## Requirements

- Python 3.10+
- Google Cloud project with APIs enabled:
  - Google Drive API
  - Google Docs API
  - Google Sheets API
  - Google Slides API

## Testing

- **Tab create/edit/delete**: Run `python test_docs_tabs.py` to validate tab creation, update, append, and delete. The test creates a document in a configurable Drive folder, runs all tab operations, and optionally deletes the test document. Non-interactive runs skip the delete prompt.

## Security

- OAuth credentials (`credentials.json`) and tokens (`gdrive_token.json`) are gitignored
- Token files have 0o600 permissions
- Tokens auto-refresh before expiry

## License

Private/Internal use.

