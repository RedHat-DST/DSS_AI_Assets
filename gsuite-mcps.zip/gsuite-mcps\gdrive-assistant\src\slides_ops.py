"""
Google Slides Operations Module.

Provides high-level functions for Google Slides interactions:
- Create presentations
- Get presentation info
- Add and modify slides
- Export to PDF
"""

import io
from pathlib import Path
from typing import Optional, Dict, Any, List

from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload

from .auth import get_slides_service, get_drive_service


# Predefined layout types
LAYOUT_TYPES = {
    'blank': 'BLANK',
    'title': 'TITLE',
    'title_body': 'TITLE_AND_BODY',
    'title_two_columns': 'TITLE_AND_TWO_COLUMNS',
    'title_only': 'TITLE_ONLY',
    'section_header': 'SECTION_HEADER',
    'section_title': 'SECTION_TITLE_AND_DESCRIPTION',
    'one_column': 'ONE_COLUMN_TEXT',
    'main_point': 'MAIN_POINT',
    'big_number': 'BIG_NUMBER',
}


def create_presentation(
    title: str,
    folder_id: Optional[str] = None,
    slides_service=None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a new Google Slides presentation.

    Args:
        title: Presentation title
        folder_id: Optional folder ID to create presentation in
        slides_service: Optional Slides service instance
        drive_service: Optional Drive service instance

    Returns:
        Dictionary with presentation info or None on failure
    """
    if slides_service is None:
        slides_service = get_slides_service()
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Create presentation
        presentation = slides_service.presentations().create(
            body={'title': title}
        ).execute()

        presentation_id = presentation.get('presentationId')
        print(f"✅ Created presentation: {title} (ID: {presentation_id})")

        # Move to folder if specified
        if folder_id:
            file = drive_service.files().get(
                fileId=presentation_id,
                fields='parents'
            ).execute()
            
            previous_parents = ",".join(file.get('parents', []))
            
            drive_service.files().update(
                fileId=presentation_id,
                addParents=folder_id,
                removeParents=previous_parents,
                fields='id, parents'
            ).execute()
            print(f"✅ Moved to folder: {folder_id}")

        # Get slide info
        slides_info = []
        for slide in presentation.get('slides', []):
            slides_info.append({
                'slide_id': slide.get('objectId'),
                'layout': slide.get('slideProperties', {}).get('layoutObjectId')
            })

        return {
            'id': presentation_id,
            'title': title,
            'url': f"https://docs.google.com/presentation/d/{presentation_id}/edit",
            'slides': slides_info
        }

    except HttpError as e:
        print(f"❌ Failed to create presentation: {e}")
        return None


def get_presentation(
    presentation_id: str,
    slides_service=None
) -> Optional[Dict[str, Any]]:
    """
    Get information about a presentation.

    Args:
        presentation_id: Presentation ID
        slides_service: Optional Slides service instance

    Returns:
        Dictionary with presentation info or None on failure
    """
    if slides_service is None:
        slides_service = get_slides_service()

    try:
        presentation = slides_service.presentations().get(
            presentationId=presentation_id
        ).execute()

        # Extract slide info
        slides_info = []
        for i, slide in enumerate(presentation.get('slides', [])):
            slide_info = {
                'index': i,
                'slide_id': slide.get('objectId'),
                'elements': []
            }

            # Extract text content from elements
            for element in slide.get('pageElements', []):
                elem_info = {
                    'object_id': element.get('objectId'),
                    'type': _get_element_type(element),
                }

                # Extract text if present
                if 'shape' in element:
                    shape = element['shape']
                    if 'text' in shape:
                        text_content = _extract_text_from_shape(shape['text'])
                        elem_info['text'] = text_content

                slide_info['elements'].append(elem_info)

            slides_info.append(slide_info)

        return {
            'id': presentation_id,
            'title': presentation.get('title', 'Untitled'),
            'url': f"https://docs.google.com/presentation/d/{presentation_id}/edit",
            'page_size': presentation.get('pageSize'),
            'slide_count': len(presentation.get('slides', [])),
            'slides': slides_info
        }

    except HttpError as e:
        print(f"❌ Failed to get presentation: {e}")
        return None


def add_slide(
    presentation_id: str,
    layout: str = 'blank',
    index: Optional[int] = None,
    slides_service=None
) -> Optional[Dict[str, Any]]:
    """
    Add a new slide to a presentation.

    Args:
        presentation_id: Presentation ID
        layout: Layout type ('blank', 'title', 'title_body', etc.)
        index: Optional position for the slide (0-based)
        slides_service: Optional Slides service instance

    Returns:
        Dictionary with new slide info or None on failure
    """
    if slides_service is None:
        slides_service = get_slides_service()

    try:
        # Get layout ID
        presentation = slides_service.presentations().get(
            presentationId=presentation_id,
            fields='layouts'
        ).execute()

        layout_type = LAYOUT_TYPES.get(layout, layout)
        layout_id = None

        for layout_obj in presentation.get('layouts', []):
            props = layout_obj.get('layoutProperties', {})
            if props.get('name', '').upper() == layout_type or props.get('displayName', '').upper() == layout_type:
                layout_id = layout_obj.get('objectId')
                break

        # Build request
        request = {'createSlide': {}}
        
        if layout_id:
            request['createSlide']['slideLayoutReference'] = {
                'layoutId': layout_id
            }
        
        if index is not None:
            request['createSlide']['insertionIndex'] = index

        result = slides_service.presentations().batchUpdate(
            presentationId=presentation_id,
            body={'requests': [request]}
        ).execute()

        replies = result.get('replies', [])
        if replies:
            slide_id = replies[0].get('createSlide', {}).get('objectId')
            print(f"✅ Created slide: {slide_id}")
            return {
                'slide_id': slide_id,
                'layout': layout,
                'index': index
            }

        return None

    except HttpError as e:
        print(f"❌ Failed to add slide: {e}")
        return None


def delete_slide(
    presentation_id: str,
    slide_id: str,
    slides_service=None
) -> bool:
    """
    Delete a slide from a presentation.

    Args:
        presentation_id: Presentation ID
        slide_id: ID of the slide to delete
        slides_service: Optional Slides service instance

    Returns:
        True if successful, False otherwise
    """
    if slides_service is None:
        slides_service = get_slides_service()

    try:
        request = {
            'deleteObject': {
                'objectId': slide_id
            }
        }

        slides_service.presentations().batchUpdate(
            presentationId=presentation_id,
            body={'requests': [request]}
        ).execute()

        print(f"✅ Deleted slide: {slide_id}")
        return True

    except HttpError as e:
        print(f"❌ Failed to delete slide: {e}")
        return False


def add_text_box(
    presentation_id: str,
    slide_id: str,
    text: str,
    x: float = 100,
    y: float = 100,
    width: float = 300,
    height: float = 100,
    slides_service=None
) -> Optional[str]:
    """
    Add a text box to a slide.

    Args:
        presentation_id: Presentation ID
        slide_id: ID of the slide to add text box to
        text: Text content
        x: X position in points
        y: Y position in points
        width: Width in points
        height: Height in points
        slides_service: Optional Slides service instance

    Returns:
        Object ID of the created text box or None on failure
    """
    if slides_service is None:
        slides_service = get_slides_service()

    try:
        # Create text box
        import uuid
        element_id = f'textbox_{uuid.uuid4().hex[:8]}'

        requests = [
            {
                'createShape': {
                    'objectId': element_id,
                    'shapeType': 'TEXT_BOX',
                    'elementProperties': {
                        'pageObjectId': slide_id,
                        'size': {
                            'width': {'magnitude': width, 'unit': 'PT'},
                            'height': {'magnitude': height, 'unit': 'PT'}
                        },
                        'transform': {
                            'scaleX': 1,
                            'scaleY': 1,
                            'translateX': x,
                            'translateY': y,
                            'unit': 'PT'
                        }
                    }
                }
            },
            {
                'insertText': {
                    'objectId': element_id,
                    'text': text,
                    'insertionIndex': 0
                }
            }
        ]

        slides_service.presentations().batchUpdate(
            presentationId=presentation_id,
            body={'requests': requests}
        ).execute()

        print(f"✅ Created text box: {element_id}")
        return element_id

    except HttpError as e:
        print(f"❌ Failed to add text box: {e}")
        return None


def update_slide_text(
    presentation_id: str,
    object_id: str,
    text: str,
    slides_service=None
) -> bool:
    """
    Update text in a shape/text box.

    Args:
        presentation_id: Presentation ID
        object_id: Object ID of the shape/text box
        text: New text content
        slides_service: Optional Slides service instance

    Returns:
        True if successful, False otherwise
    """
    if slides_service is None:
        slides_service = get_slides_service()

    try:
        requests = [
            {
                'deleteText': {
                    'objectId': object_id,
                    'textRange': {'type': 'ALL'}
                }
            },
            {
                'insertText': {
                    'objectId': object_id,
                    'text': text,
                    'insertionIndex': 0
                }
            }
        ]

        slides_service.presentations().batchUpdate(
            presentationId=presentation_id,
            body={'requests': requests}
        ).execute()

        print(f"✅ Updated text in: {object_id}")
        return True

    except HttpError as e:
        print(f"❌ Failed to update text: {e}")
        return False


def export_pdf(
    presentation_id: str,
    local_path: str,
    drive_service=None
) -> Optional[str]:
    """
    Export a presentation to PDF.

    Args:
        presentation_id: Presentation ID
        local_path: Local path to save PDF file
        drive_service: Optional Drive service instance

    Returns:
        Path to exported file or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        request = drive_service.files().export_media(
            fileId=presentation_id,
            mimeType='application/pdf'
        )

        local_path = Path(local_path)
        if not local_path.suffix:
            local_path = local_path.with_suffix('.pdf')
        local_path.parent.mkdir(parents=True, exist_ok=True)

        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        
        done = False
        while not done:
            status, done = downloader.next_chunk()

        with open(local_path, 'wb') as f:
            f.write(fh.getvalue())

        print(f"✅ Exported to: {local_path}")
        return str(local_path)

    except HttpError as e:
        print(f"❌ Export failed: {e}")
        return None


def export_pptx(
    presentation_id: str,
    local_path: str,
    drive_service=None
) -> Optional[str]:
    """
    Export a presentation to PowerPoint format.

    Args:
        presentation_id: Presentation ID
        local_path: Local path to save PPTX file
        drive_service: Optional Drive service instance

    Returns:
        Path to exported file or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        request = drive_service.files().export_media(
            fileId=presentation_id,
            mimeType='application/vnd.openxmlformats-officedocument.presentationml.presentation'
        )

        local_path = Path(local_path)
        if not local_path.suffix:
            local_path = local_path.with_suffix('.pptx')
        local_path.parent.mkdir(parents=True, exist_ok=True)

        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        
        done = False
        while not done:
            status, done = downloader.next_chunk()

        with open(local_path, 'wb') as f:
            f.write(fh.getvalue())

        print(f"✅ Exported to: {local_path}")
        return str(local_path)

    except HttpError as e:
        print(f"❌ Export failed: {e}")
        return None


def _get_element_type(element: Dict[str, Any]) -> str:
    """Determine the type of a page element."""
    if 'shape' in element:
        return element['shape'].get('shapeType', 'SHAPE')
    elif 'table' in element:
        return 'TABLE'
    elif 'image' in element:
        return 'IMAGE'
    elif 'video' in element:
        return 'VIDEO'
    elif 'line' in element:
        return 'LINE'
    elif 'elementGroup' in element:
        return 'GROUP'
    else:
        return 'UNKNOWN'


def _extract_text_from_shape(text_content: Dict[str, Any]) -> str:
    """Extract plain text from a shape's text content."""
    text_parts = []
    
    for element in text_content.get('textElements', []):
        if 'textRun' in element:
            content = element['textRun'].get('content', '')
            text_parts.append(content)
    
    return ''.join(text_parts).strip()

