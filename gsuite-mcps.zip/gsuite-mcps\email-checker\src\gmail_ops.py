"""
Gmail Operations Module.

Provides high-level functions for Gmail interactions:
- Search emails with Gmail query syntax
- Read email content
- Get inbox summary and statistics
- Create draft emails
"""

import base64
import html
import re
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import parsedate_to_datetime
from typing import Optional, List, Dict, Any

import markdown2

from .auth import get_gmail_service


# Gmail blockquote CSS style
GMAIL_QUOTE_STYLE = "margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex"


def search_emails(
    query: str = "",
    max_results: int = 25,
    gmail_service=None
) -> List[Dict[str, Any]]:
    """
    Search Gmail messages using Gmail query syntax.

    Args:
        query: Gmail search query (supports all Gmail operators)
        max_results: Maximum number of results to return
        gmail_service: Optional Gmail service (uses default if not provided)

    Returns:
        List of email dictionaries with metadata

    Gmail Query Examples:
        "from:user@example.com"
        "subject:report after:2024/01/01"
        "has:attachment"
        "in:inbox is:unread"
        "label:important"
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()

    try:
        # Get message IDs matching query
        results = gmail_service.users().messages().list(
            userId='me',
            q=query,
            maxResults=max_results
        ).execute()

        message_ids = results.get('messages', [])

        if not message_ids:
            return []

        # Fetch details for each message
        emails = []
        for msg in message_ids:
            email_data = _get_email_metadata(gmail_service, msg['id'])
            if email_data:
                emails.append(email_data)

        return emails

    except Exception as e:
        print(f"❌ Gmail search failed: {e}")
        return []


def get_inbox(max_results: int = 25, gmail_service=None) -> List[Dict[str, Any]]:
    """
    Get inbox messages.

    Args:
        max_results: Maximum results
        gmail_service: Optional Gmail service

    Returns:
        List of inbox email dictionaries
    """
    return search_emails("in:inbox", max_results, gmail_service)


def get_unread(max_results: int = 25, gmail_service=None) -> List[Dict[str, Any]]:
    """
    Get unread inbox messages.

    Args:
        max_results: Maximum results
        gmail_service: Optional Gmail service

    Returns:
        List of unread email dictionaries
    """
    return search_emails("in:inbox is:unread", max_results, gmail_service)


def read_email(message_id: str, gmail_service=None) -> Optional[Dict[str, Any]]:
    """
    Read full email content by message ID.

    Args:
        message_id: Gmail message ID
        gmail_service: Optional Gmail service

    Returns:
        Dictionary with email headers and body content
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()

    try:
        message = gmail_service.users().messages().get(
            userId='me',
            id=message_id,
            format='full'
        ).execute()

        # Extract headers
        headers = message.get('payload', {}).get('headers', [])
        result = {
            'id': message_id,
            'thread_id': message.get('threadId', ''),
            'subject': 'No Subject',
            'from': 'Unknown',
            'from_email': '',
            'to': '',
            'cc': '',
            'date': 'Unknown',
            'date_obj': None,
            'body': '',
            'snippet': message.get('snippet', ''),
            'labels': message.get('labelIds', []),
            'is_unread': 'UNREAD' in message.get('labelIds', []),
            'jira_tickets': [],
            'url': f"https://mail.google.com/mail/u/0/#inbox/{message_id}"
        }

        for header in headers:
            name = header.get('name', '').lower()
            value = header.get('value', '')
            if name == 'subject':
                result['subject'] = value
            elif name == 'from':
                result['from'] = value
                # Extract email address
                email_match = re.search(r'<([^>]+)>', value)
                if email_match:
                    result['from_email'] = email_match.group(1).lower()
                elif '@' in value:
                    result['from_email'] = value.strip().lower()
            elif name == 'to':
                result['to'] = value
            elif name == 'cc':
                result['cc'] = value
            elif name == 'date':
                result['date'] = value
                try:
                    result['date_obj'] = parsedate_to_datetime(value)
                except Exception:
                    pass

        # Extract body
        result['body'] = _extract_body(message['payload'])

        # Extract Jira tickets
        full_text = f"{result['subject']} {result['body']}"
        result['jira_tickets'] = _extract_jira_tickets(full_text)

        return result

    except Exception as e:
        print(f"❌ Failed to read email {message_id}: {e}")
        return None


def get_inbox_summary(gmail_service=None) -> Dict[str, Any]:
    """
    Get a summary of inbox statistics.

    Args:
        gmail_service: Optional Gmail service

    Returns:
        Dictionary with inbox statistics
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()

    try:
        # Get profile info
        profile = gmail_service.users().getProfile(userId='me').execute()

        # Count unread
        unread_results = gmail_service.users().messages().list(
            userId='me',
            q='in:inbox is:unread',
            maxResults=1
        ).execute()
        unread_estimate = unread_results.get('resultSizeEstimate', 0)

        # Count today's emails
        today = datetime.now().strftime('%Y/%m/%d')
        today_results = gmail_service.users().messages().list(
            userId='me',
            q=f'in:inbox after:{today}',
            maxResults=1
        ).execute()
        today_estimate = today_results.get('resultSizeEstimate', 0)

        return {
            'email': profile.get('emailAddress', 'Unknown'),
            'total_messages': profile.get('messagesTotal', 0),
            'total_threads': profile.get('threadsTotal', 0),
            'unread_count': unread_estimate,
            'today_count': today_estimate
        }

    except Exception as e:
        print(f"❌ Failed to get inbox summary: {e}")
        return {}


def _get_email_metadata(gmail_service, message_id: str) -> Optional[Dict[str, Any]]:
    """Get email metadata without full body content."""
    try:
        message = gmail_service.users().messages().get(
            userId='me',
            id=message_id,
            format='metadata',
            metadataHeaders=['From', 'Subject', 'Date', 'To', 'Cc']
        ).execute()

        headers = message.get('payload', {}).get('headers', [])
        result = {
            'id': message_id,
            'thread_id': message.get('threadId', ''),
            'subject': 'No Subject',
            'from': 'Unknown',
            'from_email': '',
            'to': '',
            'cc': '',
            'date': 'Unknown',
            'date_obj': None,
            'snippet': message.get('snippet', ''),
            'labels': message.get('labelIds', []),
            'is_unread': 'UNREAD' in message.get('labelIds', []),
            'jira_tickets': [],
            'url': f"https://mail.google.com/mail/u/0/#inbox/{message_id}"
        }

        for header in headers:
            name = header.get('name', '').lower()
            value = header.get('value', '')
            if name == 'subject':
                result['subject'] = value
            elif name == 'from':
                result['from'] = value
                email_match = re.search(r'<([^>]+)>', value)
                if email_match:
                    result['from_email'] = email_match.group(1).lower()
                elif '@' in value:
                    result['from_email'] = value.strip().lower()
            elif name == 'to':
                result['to'] = value
            elif name == 'cc':
                result['cc'] = value
            elif name == 'date':
                result['date'] = value
                try:
                    result['date_obj'] = parsedate_to_datetime(value)
                except Exception:
                    pass

        # Extract Jira tickets from subject and snippet
        full_text = f"{result['subject']} {result['snippet']}"
        result['jira_tickets'] = _extract_jira_tickets(full_text)

        return result

    except Exception as e:
        print(f"⚠️  Failed to get metadata for {message_id}: {e}")
        return None


def _extract_body(payload: Dict[str, Any]) -> str:
    """
    Recursively extract email body from payload.

    Prioritizes text/plain, falls back to text/html.
    """
    body_parts = {'plain': '', 'html': ''}

    def extract_recursive(part: Dict[str, Any]):
        if 'parts' in part:
            for subpart in part['parts']:
                extract_recursive(subpart)
        elif 'body' in part and 'data' in part['body']:
            mime_type = part.get('mimeType', '')
            try:
                data = part['body']['data']
                text = base64.urlsafe_b64decode(data).decode('utf-8', errors='replace')

                if 'text/plain' in mime_type:
                    body_parts['plain'] += text
                elif 'text/html' in mime_type:
                    body_parts['html'] += text
            except Exception:
                pass

    extract_recursive(payload)

    # Prefer plain text, fall back to HTML
    if body_parts['plain']:
        return body_parts['plain']
    elif body_parts['html']:
        # Basic HTML to text conversion
        text = body_parts['html']
        text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
        text = re.sub(r'<p[^>]*>', '\n\n', text, flags=re.IGNORECASE)
        text = re.sub(r'</p>', '', text, flags=re.IGNORECASE)
        text = re.sub(r'<[^>]+>', '', text)  # Remove remaining tags
        text = re.sub(r'&nbsp;', ' ', text)
        text = re.sub(r'&amp;', '&', text)
        text = re.sub(r'&lt;', '<', text)
        text = re.sub(r'&gt;', '>', text)
        text = re.sub(r'\n{3,}', '\n\n', text)  # Collapse multiple newlines
        return text.strip()

    return ""


def _extract_jira_tickets(text: str) -> List[str]:
    """
    Extract Jira ticket references from text.

    Pattern: PROJECT-NUMBER (e.g., RHEL-123, CORE-456)
    """
    pattern = r'\b([A-Z]{2,10}-\d+)\b'
    matches = re.findall(pattern, text)
    return list(set(matches))


def _email_to_mailto_link(email: str) -> str:
    """Convert an email address to a mailto link."""
    escaped = html.escape(email)
    return f'<a href="mailto:{escaped}">{escaped}</a>'


def _format_attribution_html(line: str) -> str:
    """
    Format an attribution line with proper Gmail styling.
    
    Converts "On Mon, Dec 1, 2025 at 4:49 PM Josh Boyer <jwboyer@redhat.com> wrote:"
    to Gmail's format with mailto links.
    """
    # Find email in angle brackets
    email_match = re.search(r'<([^>]+@[^>]+)>', line)
    if email_match:
        email = email_match.group(1)
        # Replace <email> with &lt;<a href="mailto:email">email</a>&gt;
        before = line[:email_match.start()]
        after = line[email_match.end():]
        formatted = f'{html.escape(before)}&lt;{_email_to_mailto_link(email)}&gt;{html.escape(after)}'
        return f'<div dir="ltr" class="gmail_attr">{formatted}<br></div>'
    else:
        return f'<div dir="ltr" class="gmail_attr">{html.escape(line)}<br></div>'


def _plain_text_to_html(text: str) -> str:
    """
    Convert plain text email body to HTML with proper Gmail blockquote styling.
    
    Handles nested quotes (>, >>, >>>) and converts them to nested <blockquote> elements.
    Uses Gmail's HTML structure with gmail_quote_container and gmail_attr classes.
    
    Working Gmail structure (tested):
    - Top-level: <div class="gmail_quote gmail_quote_container"> wraps attribution + blockquote
    - <br> between attribution and blockquote
    - Content uses plain <div> elements directly in blockquote (no wrapper)
    - Nested attributions use <div dir="ltr" class="gmail_attr"> directly (no gmail_quote wrapper)
    - Blank lines after attribution in plain text are NOT rendered (attribution already adds <br>)
    """
    lines = text.split('\n')
    html_parts = []
    current_quote_level = 0
    in_quote_container = False
    skip_next_blank = False  # Skip blank line after attribution
    
    for i, line in enumerate(lines):
        # Count quote level
        stripped = line
        quote_level = 0
        while stripped.startswith('>'):
            quote_level += 1
            stripped = stripped[1:]
            if stripped.startswith(' '):
                stripped = stripped[1:]
        
        # Check if this is an attribution line (ends with "wrote:")
        is_attribution = stripped.strip().endswith('wrote:') and 'On ' in stripped
        
        # Skip blank lines right after attribution (we already added <br>)
        if skip_next_blank and stripped.strip() == '':
            skip_next_blank = False
            continue
        skip_next_blank = False
        
        # Close blockquotes if quote level decreased
        while current_quote_level > quote_level:
            html_parts.append('</blockquote>')
            current_quote_level -= 1
            # Close outer quote container when exiting all quotes
            if current_quote_level == 0 and in_quote_container:
                html_parts.append('</div>')
                in_quote_container = False
        
        # Handle top-level attribution line - start quote container
        if is_attribution and quote_level == 0 and not in_quote_container:
            html_parts.append('<div class="gmail_quote gmail_quote_container">')
            html_parts.append(_format_attribution_html(stripped))
            html_parts.append('<br>')
            in_quote_container = True
            skip_next_blank = True
            continue
        
        # Handle nested attribution lines inside quotes (no wrapper, just the attribution)
        # Don't add <br> before - the blank line in plain text already provides it
        if is_attribution and quote_level > 0:
            html_parts.append(_format_attribution_html(stripped))
            html_parts.append('<br>')
            skip_next_blank = True
            continue
        
        # Open blockquotes if quote level increased
        while current_quote_level < quote_level:
            html_parts.append(f'<blockquote class="gmail_quote" style="{GMAIL_QUOTE_STYLE}">')
            current_quote_level += 1
        
        # Convert line content to HTML
        content = html.escape(stripped)
        
        if content.strip() == '':
            html_parts.append('<br>')
        else:
            # Use plain <div> for content
            html_parts.append(f'<div>{content}</div>')
    
    # Close any remaining blockquotes
    while current_quote_level > 0:
        html_parts.append('</blockquote>')
        current_quote_level -= 1
    
    # Close outer quote container if still open
    if in_quote_container:
        html_parts.append('</div>')
    
    return '\n'.join(html_parts)


def _markdown_to_html(text: str) -> str:
    """
    Convert Markdown text to HTML using markdown2.
    
    Uses Gmail-compatible HTML output with extras for common formatting needs.
    """
    # Convert markdown to HTML with useful extras
    html_content = markdown2.markdown(
        text,
        extras=[
            'fenced-code-blocks',  # ```code blocks```
            'tables',              # | tables |
            'strike',              # ~~strikethrough~~
            'cuddled-lists',       # Lists without blank line before
            'header-ids',          # Add IDs to headers
        ]
    )
    return html_content


def _detect_content_type(body: str) -> str:
    """
    Auto-detect the content type of an email body.
    
    Returns:
        "html" - if body appears to be HTML (starts with tags)
        "markdown" - if body contains markdown patterns
        "plain" - otherwise
    """
    stripped = body.strip()
    
    # Check for HTML: starts with common HTML tags
    html_patterns = [
        r'^<(!DOCTYPE|html|head|body|div|p|span|h[1-6]|ul|ol|table|br)',
        r'^<[a-z]+[^>]*>',  # Starts with any HTML tag
    ]
    for pattern in html_patterns:
        if re.match(pattern, stripped, re.IGNORECASE):
            return "html"
    
    # Check for Markdown patterns
    markdown_patterns = [
        r'^#{1,6}\s',           # Headers: # Header
        r'\*\*[^*]+\*\*',       # Bold: **text**
        r'\*[^*]+\*',           # Italic: *text*
        r'^\s*[-*+]\s',         # Unordered lists: - item
        r'^\s*\d+\.\s',         # Ordered lists: 1. item
        r'\[.+\]\(.+\)',        # Links: [text](url)
        r'^```',                # Fenced code blocks
        r'`[^`]+`',             # Inline code
    ]
    for pattern in markdown_patterns:
        if re.search(pattern, stripped, re.MULTILINE):
            return "markdown"
    
    return "plain"


def _get_message_references(message_id: str, gmail_service) -> str:
    """
    Get the References header chain for a reply.
    
    Fetches the original message's References header and appends the message ID.
    """
    try:
        msg = gmail_service.users().messages().get(
            userId='me',
            id=message_id,
            format='metadata',
            metadataHeaders=['References', 'Message-ID']
        ).execute()
        
        headers = {h['name']: h['value'] for h in msg.get('payload', {}).get('headers', [])}
        
        # Build references chain
        existing_refs = headers.get('References', '')
        original_msg_id = headers.get('Message-ID', '')
        
        if existing_refs and original_msg_id:
            return f"{existing_refs} {original_msg_id}"
        elif original_msg_id:
            return original_msg_id
        elif existing_refs:
            return existing_refs
        else:
            return f"<{message_id}>"
            
    except Exception:
        return f"<{message_id}>"


def _get_in_reply_to(message_id: str, gmail_service) -> str:
    """Get the Message-ID of the original message for In-Reply-To header."""
    try:
        msg = gmail_service.users().messages().get(
            userId='me',
            id=message_id,
            format='metadata',
            metadataHeaders=['Message-ID']
        ).execute()
        
        headers = {h['name']: h['value'] for h in msg.get('payload', {}).get('headers', [])}
        return headers.get('Message-ID', f"<{message_id}>")
        
    except Exception:
        return f"<{message_id}>"


def create_draft(
    to: str,
    subject: str,
    body: str,
    cc: str = "",
    bcc: str = "",
    reply_to_message_id: str = "",
    thread_id: str = "",
    content_type: str = "markdown",
    gmail_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a draft email in Gmail with proper multipart MIME format.

    Creates both plain text and HTML versions of the email. The HTML version
    is generated based on the content_type parameter.

    Args:
        to: Recipient email address(es), comma-separated for multiple
        subject: Email subject line
        body: Email body content
        cc: CC recipients, comma-separated (optional)
        bcc: BCC recipients, comma-separated (optional)
        reply_to_message_id: Message ID to reply to (optional)
        thread_id: Thread ID to add the draft to (optional)
        content_type: Body format - "auto", "plain", "markdown", or "html"
        gmail_service: Optional Gmail service

    Returns:
        Dictionary with draft info including draft ID, or None on failure
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()

    try:
        # Create multipart/alternative message with both plain and HTML
        message = MIMEMultipart('alternative')
        message['to'] = to
        message['subject'] = subject
        
        if cc:
            message['cc'] = cc
        if bcc:
            message['bcc'] = bcc
        
        # Add threading headers for replies
        if reply_to_message_id:
            in_reply_to = _get_in_reply_to(reply_to_message_id, gmail_service)
            references = _get_message_references(reply_to_message_id, gmail_service)
            message['In-Reply-To'] = in_reply_to
            message['References'] = references

        # Create plain text part with quoted-printable encoding (like Gmail uses)
        import quopri
        from email.mime.nonmultipart import MIMENonMultipart
        
        # Encode body as quoted-printable
        qp_body = quopri.encodestring(body.encode('utf-8')).decode('ascii')
        text_part = MIMENonMultipart('text', 'plain', charset='utf-8')
        text_part['Content-Transfer-Encoding'] = 'quoted-printable'
        text_part.set_payload(qp_body)
        
        # Determine content type if auto-detecting
        effective_type = content_type
        if content_type == "auto":
            effective_type = _detect_content_type(body)
        
        # Create HTML part based on content type
        if effective_type == "html":
            # Use body directly as HTML (user provided HTML)
            html_body = body
        elif effective_type == "markdown":
            # Convert markdown to HTML
            html_body = _markdown_to_html(body)
        else:
            # Plain text: escape HTML and convert > quotes to blockquotes
            html_body = _plain_text_to_html(body)
        
        html_content = f'<div dir="ltr">{html_body}</div>'
        qp_html = quopri.encodestring(html_content.encode('utf-8')).decode('ascii')
        html_part = MIMENonMultipart('text', 'html', charset='utf-8')
        html_part['Content-Transfer-Encoding'] = 'quoted-printable'
        html_part.set_payload(qp_html)
        
        # Attach parts (plain first, then HTML - email clients prefer last)
        message.attach(text_part)
        message.attach(html_part)

        # Encode the message
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')

        # Build the draft body
        draft_body = {
            'message': {
                'raw': raw_message
            }
        }
        
        # Add thread ID if this is a reply
        if thread_id:
            draft_body['message']['threadId'] = thread_id

        # Create the draft
        draft = gmail_service.users().drafts().create(
            userId='me',
            body=draft_body
        ).execute()

        return {
            'draft_id': draft.get('id', ''),
            'message_id': draft.get('message', {}).get('id', ''),
            'thread_id': draft.get('message', {}).get('threadId', ''),
            'url': f"https://mail.google.com/mail/u/0/#drafts?compose={draft.get('id', '')}"
        }

    except Exception as e:
        print(f"❌ Failed to create draft: {e}")
        return None


# =============================================================================
# Label Management Functions
# =============================================================================

# GTD Label definitions with Gmail-compatible colors
# Gmail only allows specific colors from their palette
# Valid background colors (from Gmail API): #000000, #076239, #0b804b, #149e60, 
# #16a765, #1a764d, #285bac, #2a9c68, #3c78d8, #41236d, #434343, #42d692,
# #44b984, #4a86e8, #653e9b, #666666, #68dfa9, #6d9eeb, #822111, #83334c,
# #89d3b2, #8e63ce, #994a64, #98d7e4, #a0eac9, #a46a21, #a479e2, #aa8831,
# #ac2b16, #b3efd3, #b65775, #b694e8, #b9e4d0, #c2c2c2, #cc3a21, #cccccc,
# #cf8933, #cfe2f3, #e07798, #e4d7f5, #f2b2a8, #f3f3f3, #fad165, #fb4c2f,
# #fbc8d9, #fcda83, #fcdee8, #fce8b3, #fef1d1, #ffad46, #ffffff

# Parent label (created first to enable nesting)
GTD_PARENT_LABEL = 'GTD'

# Child labels (nested under GTD)
GTD_LABELS = {
    'GTD/Urgent': {'bg': '#ac2b16', 'text': '#ffffff'},      # Dark Red - wins over other labels
    'GTD/Action': {'bg': '#cf8933', 'text': '#ffffff'},      # Orange/Brown  
    'GTD/Reply Needed': {'bg': '#fad165', 'text': '#000000'},# Yellow/Gold
    'GTD/Waiting For': {'bg': '#149e60', 'text': '#ffffff'}, # Green
    'GTD/Review': {'bg': '#653e9b', 'text': '#ffffff'},      # Purple
    'GTD/Ignore': {'bg': '#666666', 'text': '#ffffff'},      # Gray
    'GTD/Needs Review': {'bg': '#cc3a21', 'text': '#ffffff'},# Red
}

# =============================================================================
# Meeting Notes Auto-Archive Configuration
# =============================================================================

# Google Meet notes sender (Gemini-generated meeting summaries)
MEETING_NOTES_SENDER = "gemini-notes@google.com"

# Label to apply when archiving meeting notes
MEETING_ARCHIVE_LABEL = "@Reference/Meetings"


def is_meeting_notes_email(email: dict) -> bool:
    """
    Check if an email is a Google Meet notes/transcription.
    
    These emails are auto-generated by Gemini after Google Meet calls
    and contain meeting summaries and action items.
    
    Args:
        email: Email dictionary with 'from_email' field
        
    Returns:
        True if email is from Google Meet notes sender
    """
    from_email = email.get('from_email', '').lower()
    return from_email == MEETING_NOTES_SENDER


def get_labels(gmail_service=None) -> List[Dict[str, Any]]:
    """
    Get all labels for the authenticated user.
    
    Args:
        gmail_service: Optional Gmail service
        
    Returns:
        List of label dictionaries with id, name, type
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        results = gmail_service.users().labels().list(userId='me').execute()
        labels = results.get('labels', [])
        return [
            {
                'id': label['id'],
                'name': label['name'],
                'type': label.get('type', 'user')
            }
            for label in labels
        ]
    except Exception as e:
        print(f"❌ Failed to get labels: {e}")
        return []


def get_label_by_name(name: str, gmail_service=None) -> Optional[Dict[str, Any]]:
    """
    Get a label by its name.
    
    Args:
        name: Label name to find
        gmail_service: Optional Gmail service
        
    Returns:
        Label dictionary or None if not found
    """
    labels = get_labels(gmail_service)
    for label in labels:
        if label['name'] == name:
            return label
    return None


def create_label(
    name: str,
    bg_color: str = '#999999',
    text_color: str = '#ffffff',
    gmail_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a new label.
    
    Args:
        name: Label name (use / for nested labels, e.g., "GTD/Action")
        bg_color: Background color hex code
        text_color: Text color hex code
        gmail_service: Optional Gmail service
        
    Returns:
        Created label dictionary or None on failure
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        label_body = {
            'name': name,
            'labelListVisibility': 'labelShow',
            'messageListVisibility': 'show',
            'color': {
                'backgroundColor': bg_color,
                'textColor': text_color
            }
        }
        
        result = gmail_service.users().labels().create(
            userId='me',
            body=label_body
        ).execute()
        
        return {
            'id': result['id'],
            'name': result['name'],
            'type': result.get('type', 'user')
        }
    except Exception as e:
        print(f"❌ Failed to create label '{name}': {e}")
        return None


def delete_label(label_id: str, gmail_service=None) -> bool:
    """
    Delete a label by ID.
    
    Args:
        label_id: Gmail label ID
        gmail_service: Optional Gmail service
        
    Returns:
        True if successful, False otherwise
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        gmail_service.users().labels().delete(
            userId='me',
            id=label_id
        ).execute()
        return True
    except Exception as e:
        print(f"❌ Failed to delete label {label_id}: {e}")
        return False


def ensure_gtd_labels(gmail_service=None) -> Dict[str, str]:
    """
    Ensure all GTD labels exist, creating them if needed.
    
    Creates parent "GTD" label first, then nested child labels.
    
    Args:
        gmail_service: Optional Gmail service
        
    Returns:
        Dictionary mapping label names to label IDs
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    # Get existing labels
    existing = {label['name']: label['id'] for label in get_labels(gmail_service)}
    label_ids = {}
    
    # First, ensure parent "GTD" label exists
    if GTD_PARENT_LABEL in existing:
        label_ids[GTD_PARENT_LABEL] = existing[GTD_PARENT_LABEL]
    else:
        result = create_label(
            name=GTD_PARENT_LABEL,
            bg_color='#434343',  # Dark gray for parent
            text_color='#ffffff',
            gmail_service=gmail_service
        )
        if result:
            label_ids[GTD_PARENT_LABEL] = result['id']
            print(f"✅ Created parent label: {GTD_PARENT_LABEL}")
            # Refresh existing labels list
            existing = {label['name']: label['id'] for label in get_labels(gmail_service)}
        else:
            print(f"⚠️ Could not create parent label: {GTD_PARENT_LABEL}")
    
    # Now create child labels (they will nest under GTD)
    for label_name, colors in GTD_LABELS.items():
        if label_name in existing:
            label_ids[label_name] = existing[label_name]
        else:
            result = create_label(
                name=label_name,
                bg_color=colors['bg'],
                text_color=colors['text'],
                gmail_service=gmail_service
            )
            if result:
                label_ids[label_name] = result['id']
                print(f"✅ Created label: {label_name}")
            else:
                print(f"⚠️ Could not create label: {label_name}")
    
    return label_ids


def apply_labels(
    message_id: str,
    label_names: List[str],
    gmail_service=None
) -> bool:
    """
    Apply labels to a message.
    
    Args:
        message_id: Gmail message ID
        label_names: List of label names to apply
        gmail_service: Optional Gmail service
        
    Returns:
        True if successful, False otherwise
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        # Get label IDs
        existing = {label['name']: label['id'] for label in get_labels(gmail_service)}
        label_ids = []
        
        for name in label_names:
            if name in existing:
                label_ids.append(existing[name])
            else:
                print(f"⚠️ Label not found: {name}")
        
        if not label_ids:
            return False
        
        # Apply labels
        gmail_service.users().messages().modify(
            userId='me',
            id=message_id,
            body={'addLabelIds': label_ids}
        ).execute()
        
        return True
    except Exception as e:
        print(f"❌ Failed to apply labels: {e}")
        return False


def remove_labels(
    message_id: str,
    label_names: List[str],
    gmail_service=None
) -> bool:
    """
    Remove labels from a message.
    
    Args:
        message_id: Gmail message ID
        label_names: List of label names to remove
        gmail_service: Optional Gmail service
        
    Returns:
        True if successful, False otherwise
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        # Get label IDs
        existing = {label['name']: label['id'] for label in get_labels(gmail_service)}
        label_ids = [existing[name] for name in label_names if name in existing]
        
        if not label_ids:
            return False
        
        # Remove labels
        gmail_service.users().messages().modify(
            userId='me',
            id=message_id,
            body={'removeLabelIds': label_ids}
        ).execute()
        
        return True
    except Exception as e:
        print(f"❌ Failed to remove labels: {e}")
        return False


def archive_to_folder(
    message_id: str,
    label_name: str,
    gmail_service=None
) -> bool:
    """
    Apply a label and archive a message (remove from inbox).
    
    Args:
        message_id: Gmail message ID
        label_name: Label name to apply (e.g., "@Reference/Meetings")
        gmail_service: Optional Gmail service
        
    Returns:
        True if successful, False otherwise
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        # Get label ID for the target label
        existing = {label['name']: label['id'] for label in get_labels(gmail_service)}
        
        if label_name not in existing:
            print(f"⚠️ Label not found: {label_name}")
            return False
        
        label_id = existing[label_name]
        
        # Apply label and remove INBOX in one API call
        gmail_service.users().messages().modify(
            userId='me',
            id=message_id,
            body={
                'addLabelIds': [label_id],
                'removeLabelIds': ['INBOX']
            }
        ).execute()
        
        return True
    except Exception as e:
        print(f"❌ Failed to archive to folder: {e}")
        return False


def get_emails_without_gtd_labels(
    max_results: int = 25,
    gmail_service=None
) -> List[Dict[str, Any]]:
    """
    Get inbox emails that don't have any GTD labels.
    
    Args:
        max_results: Maximum number of results
        gmail_service: Optional Gmail service
        
    Returns:
        List of email dictionaries without GTD labels
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    # Build query to exclude GTD labels
    gtd_label_names = list(GTD_LABELS.keys())
    exclude_queries = [f'-label:{name.replace("/", "-")}' for name in gtd_label_names]
    
    # Note: Gmail API uses - instead of / in label queries
    # Try simpler approach: get inbox and filter
    emails = search_emails("in:inbox", max_results * 2, gmail_service)
    
    # Filter out emails that have GTD labels
    result = []
    for email in emails:
        has_gtd = False
        for label in email.get('labels', []):
            # Check if any label starts with "Label_" (user labels) 
            # and matches our GTD labels
            for gtd_name in gtd_label_names:
                label_info = get_label_by_name(gtd_name, gmail_service)
                if label_info and label == label_info['id']:
                    has_gtd = True
                    break
            if has_gtd:
                break
        
        if not has_gtd:
            result.append(email)
            if len(result) >= max_results:
                break
    
    return result


def get_draft_raw(
    draft_id: str,
    gmail_service=None
) -> Optional[str]:
    """
    Get the raw RFC 2822 formatted content of a draft.
    
    Args:
        draft_id: The Gmail draft ID
        gmail_service: Optional Gmail service instance
        
    Returns:
        Raw email content as string, or None on failure
    """
    if gmail_service is None:
        gmail_service = get_gmail_service()
    
    try:
        # Get draft with raw format
        draft = gmail_service.users().drafts().get(
            userId='me',
            id=draft_id,
            format='raw'
        ).execute()
        
        # Decode the raw message
        raw_data = draft.get('message', {}).get('raw', '')
        if raw_data:
            return base64.urlsafe_b64decode(raw_data).decode('utf-8')
        return None
        
    except Exception as e:
        print(f"❌ Failed to get draft: {e}")
        return None

