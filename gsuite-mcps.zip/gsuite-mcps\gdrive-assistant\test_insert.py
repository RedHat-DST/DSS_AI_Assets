#!/usr/bin/env python3
"""
Test script for the gdocs_insert functionality.

This script tests various insertion scenarios:
1. Insert at start (default)
2. Insert at specific index
3. Insert after heading
4. Insert after search text

Requirements:
- Authenticated Google Drive access
- Will create a temporary test document
"""

import sys
from src.auth import get_auth
from src.docs_ops import create_doc, insert_content_at, read_doc_as_markdown
from src.drive_ops import delete_file

def test_insert_functionality():
    """Test the insert_content_at function with various scenarios."""
    
    # Authenticate
    auth = get_auth()
    if not auth.authenticate():
        print("❌ Authentication failed")
        return False
    
    print("✅ Authenticated successfully\n")
    
    # Create a test document
    print("📝 Creating test document...")
    doc_result = create_doc(
        title="Test Document - Insert Functionality",
        content="""# Test Document

## Introduction
This is the introduction section.

## Methodology
This section describes the methodology.

## Results
This section contains the results.

## Conclusion
Final thoughts and conclusions.
""",
        content_type='markdown'
    )
    
    if not doc_result:
        print("❌ Failed to create test document")
        return False
    
    doc_id = doc_result['id']
    print(f"✅ Created test document: {doc_id}")
    print(f"   URL: {doc_result['url']}\n")
    
    try:
        # Test 1: Insert at start (default)
        print("Test 1: Insert at start of document")
        success = insert_content_at(
            doc_id,
            "**INSERTED AT START**\n\n",
            content_type='markdown'
        )
        if success:
            print("  ✅ Insert at start succeeded\n")
        else:
            print("  ❌ Insert at start failed\n")
            return False
        
        # Test 2: Insert after heading (before testing index to avoid splitting headings)
        print("Test 2: Insert after 'Introduction' heading")
        success = insert_content_at(
            doc_id,
            "\n*This content was inserted after the Introduction heading.*\n",
            content_type='markdown',
            heading="Introduction",
            position='after'
        )
        if success:
            print("  ✅ Insert after heading succeeded\n")
        else:
            print("  ❌ Insert after heading failed\n")
            return False
        
        # Test 3: Insert after search text
        print("Test 3: Insert after 'methodology' text")
        success = insert_content_at(
            doc_id,
            " **[INSERTED AFTER 'methodology']** ",
            content_type='markdown',
            search_text="methodology",
            position='after'
        )
        if success:
            print("  ✅ Insert after search text succeeded\n")
        else:
            print("  ❌ Insert after search text failed\n")
            return False
        
        # Test 4: Insert before heading
        print("Test 4: Insert before 'Conclusion' heading using search")
        success = insert_content_at(
            doc_id,
            "\n**[INSERTED BEFORE CONCLUSION]**\n",
            content_type='markdown',
            heading="Conclusion",
            position='before'
        )
        if success:
            print("  ✅ Insert before search text succeeded\n")
        else:
            print("  ❌ Insert before search text failed\n")
            return False
        
        # Show final result
        print("=" * 60)
        print("Final document content (as markdown):")
        print("=" * 60)
        final_content = read_doc_as_markdown(doc_id)
        if final_content:
            print(final_content)
        else:
            print("❌ Failed to read final content")
        
        print("\n" + "=" * 60)
        print(f"✅ All tests passed!")
        print(f"View document at: {doc_result['url']}")
        print("=" * 60)
        
        # Ask if user wants to delete the test document
        response = input("\nDelete test document? (y/N): ")
        if response.lower() == 'y':
            if delete_file(doc_id, permanent=True):
                print("✅ Test document deleted")
            else:
                print("⚠️  Failed to delete test document")
        else:
            print(f"ℹ️  Test document preserved: {doc_result['url']}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == '__main__':
    success = test_insert_functionality()
    sys.exit(0 if success else 1)
