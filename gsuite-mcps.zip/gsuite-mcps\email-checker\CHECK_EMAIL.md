# Check Email

Reference the GTD categorization rules in `prompts/categorize.md`.

## Task
1. List uncategorized emails in my inbox using `gmail_list_uncategorized`
2. Read each email to understand context
3. Categorize using GTD methodology and apply the single most relevant label in Gmail
4. Present results in this table format (newest first):

| # | Subject | From | Date | Category | What To Do |
|---|---------|------|------|----------|------------|

- **Subject**: Make clickable link to Gmail (`https://mail.google.com/mail/u/0/#inbox/{id}`)
- **Category**: The GTD label applied (Urgent, Action, Reply Needed, etc.)
- **What To Do**: 1-sentence action summary (or "None" for Review/Ignore)

## GTD Categories (pick ONE per email)
- **Urgent** - Needs attention TODAY (wins over other categories)
- **Action** - I must DO something
- **Reply Needed** - Needs written response only
- **Waiting For** - Tracking someone else
- **Review** - Read/digest, no action
- **Ignore** - Safe to skip
