# Cursor prompt — install G Suite MCPs (Gmail / Calendar / Drive)

Attach the `gsuite-mcps` folder (or zip) in **Cursor Agent** and paste the prompt below.

---

## Prompt to paste

```
Install the G Suite MCP pack from the attached gsuite-mcps folder/zip into Cursor.

Do this, in order:

1. Unpack if needed. The pack contains:
   - email-checker/   → Gmail MCP
   - calendar-assistant/ → Calendar MCP
   - gdrive-assistant/ → Drive/Docs/Sheets/Slides MCP

2. Copy those three folders into ~/.cursor/mcp-servers/ (Windows: %USERPROFILE%\.cursor\mcp-servers\).
   Overwrite code files. Never copy credentials.json or gdrive_token.json from my machine into chat or into a share zip.
   Keep my existing credentials.json / gdrive_token.json if already present.

3. Ensure a shared Python venv at ~/.cursor/mcp-servers/.venv exists. Prefer Python 3.10+.
   Install requirements from all three folders into that venv.

4. Merge these three servers into ~/.cursor/mcp.json without removing other servers. Use absolute paths to the shared venv python and each mcp_server.py. Names:
   - "user-gmail-assistant"
   - "user-calendar-assistant"
   - "user-gdrive-assistant"

5. Do not invent OAuth credentials. If credentials.json is missing, tell me how to create a Google Cloud Desktop OAuth client and where to put credentials.json (see each SETUP.md). Then run CLI auth once per MCP so I can complete the browser consent.

6. When finished, print:
   - the mcp.json snippets written
   - which MCPs still need OAuth
   - reminder to reload Cursor Settings → MCP

Privacy Mode stays ON. Never ask me to disable it.
```

---

## After install

1. Reload **Cursor Settings → MCP** until the three servers are green.
2. Complete Google OAuth if prompted.
3. Smoke test: inbox summary, today’s calendar, Drive search for a known file.
