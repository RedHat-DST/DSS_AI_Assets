"""
Google Calendar Assistant CLI.

Command-line interface for quick calendar access.

Usage:
    python -m src.cli calendars       # List all calendars
    python -m src.cli today           # View today's events
    python -m src.cli upcoming [days] # View upcoming events
    python -m src.cli search "query"  # Search events
    python -m src.cli event <id>      # View specific event
    python -m src.cli now             # View current/next event
    python -m src.cli auth-status     # Check authentication status
"""

import sys
from datetime import datetime, timedelta
from typing import Optional
import pytz

import click

from .auth import get_auth, CalendarAuth
from .calendar_ops import (
    list_calendars, get_todays_events, get_upcoming_events,
    search_events, get_event, get_current_or_next_event
)


def format_datetime(dt: Optional[datetime], all_day: bool = False) -> str:
    """Format datetime for display."""
    if not dt:
        return "Unknown"
    
    if all_day:
        return dt.strftime("%a, %b %d")
    
    # Check if today
    now = datetime.now(dt.tzinfo if dt.tzinfo else pytz.UTC)
    if dt.date() == now.date():
        return f"Today at {dt.strftime('%I:%M %p')}"
    elif dt.date() == (now + timedelta(days=1)).date():
        return f"Tomorrow at {dt.strftime('%I:%M %p')}"
    else:
        return dt.strftime("%a, %b %d at %I:%M %p")


def format_time_range(start: Optional[datetime], end: Optional[datetime], all_day: bool = False) -> str:
    """Format a time range."""
    if not start:
        return "Unknown time"
    
    if all_day:
        if not end or (end.date() == start.date()) or (end.date() == start.date() + timedelta(days=1)):
            return format_datetime(start, all_day=True)
        else:
            return f"{start.strftime('%a, %b %d')} - {(end - timedelta(days=1)).strftime('%a, %b %d')}"
    
    if not end:
        return format_datetime(start)
    
    # Same day
    if start.date() == end.date():
        return f"{format_datetime(start)} - {end.strftime('%I:%M %p')}"
    else:
        return f"{format_datetime(start)} - {format_datetime(end)}"


def print_event(event: dict, verbose: bool = False):
    """Print a single event."""
    summary = event.get('summary', 'No Title')
    start = event.get('start_datetime')
    end = event.get('end_datetime')
    all_day = event.get('is_all_day', False)
    
    time_str = format_time_range(start, end, all_day)
    
    click.echo(f"\n📅 {summary}")
    click.echo(f"   {time_str}")
    
    if event.get('location'):
        click.echo(f"   📍 {event['location']}")
    
    if event.get('conference_link'):
        click.echo(f"   🔗 {event['conference_link']}")
    
    if verbose:
        if event.get('description'):
            click.echo(f"\n   Description:")
            for line in event['description'].split('\n'):
                click.echo(f"   {line}")
        
        attendees = event.get('attendees', [])
        if attendees:
            click.echo(f"\n   Attendees ({len(attendees)}):")
            for att in attendees[:10]:  # Limit to 10
                status_icon = {
                    'accepted': '✅',
                    'declined': '❌',
                    'tentative': '❓',
                    'needsAction': '⏳'
                }.get(att.get('responseStatus', 'needsAction'), '⏳')
                name = att.get('displayName') or att.get('email', 'Unknown')
                click.echo(f"     {status_icon} {name}")
            if len(attendees) > 10:
                click.echo(f"     ... and {len(attendees) - 10} more")
        
        if event.get('html_link'):
            click.echo(f"\n   View in Calendar: {event['html_link']}")


@click.group()
def cli():
    """Google Calendar Assistant - View and search your calendar."""
    pass


@cli.command()
def calendars():
    """List all accessible calendars."""
    auth = get_auth()
    if not auth.authenticate():
        click.echo("❌ Authentication failed. Please check your credentials.", err=True)
        sys.exit(1)
    
    cals = list_calendars()
    
    if not cals:
        click.echo("No calendars found.")
        return
    
    click.echo(f"\n📅 Your Calendars ({len(cals)}):\n")
    
    for cal in cals:
        primary = "⭐ " if cal.get('primary') else ""
        summary = cal.get('summary', 'Unknown')
        cal_id = cal.get('id', '')
        access = cal.get('accessRole', 'unknown')
        
        click.echo(f"{primary}{summary}")
        click.echo(f"   ID: {cal_id}")
        click.echo(f"   Access: {access}")
        if cal.get('description'):
            click.echo(f"   {cal['description']}")
        click.echo()


@cli.command()
@click.option('-c', '--calendar', default='primary', help='Calendar ID')
def today(calendar):
    """View today's events."""
    auth = get_auth()
    if not auth.authenticate():
        click.echo("❌ Authentication failed. Please check your credentials.", err=True)
        sys.exit(1)
    
    events = get_todays_events(calendar_id=calendar)
    
    if not events:
        click.echo("📭 No events today.")
        return
    
    click.echo(f"\n📅 Today's Schedule ({len(events)} events):")
    
    for event in events:
        print_event(event)


@cli.command()
@click.argument('days', default=7, type=int)
@click.option('-c', '--calendar', default='primary', help='Calendar ID')
@click.option('-n', '--max-results', default=50, type=int, help='Maximum number of events')
def upcoming(days, calendar, max_results):
    """View upcoming events for the next N days (default: 7)."""
    auth = get_auth()
    if not auth.authenticate():
        click.echo("❌ Authentication failed. Please check your credentials.", err=True)
        sys.exit(1)
    
    events = get_upcoming_events(days=days, calendar_id=calendar, max_results=max_results)
    
    if not events:
        click.echo(f"📭 No events in the next {days} days.")
        return
    
    click.echo(f"\n📅 Upcoming Events (next {days} days, {len(events)} total):")
    
    for event in events:
        print_event(event)


@cli.command()
@click.argument('query')
@click.option('-c', '--calendar', default='primary', help='Calendar ID')
@click.option('-n', '--max-results', default=50, type=int, help='Maximum number of results')
def search(query, calendar, max_results):
    """Search for events by text query."""
    auth = get_auth()
    if not auth.authenticate():
        click.echo("❌ Authentication failed. Please check your credentials.", err=True)
        sys.exit(1)
    
    events = search_events(query, calendar_id=calendar, max_results=max_results)
    
    if not events:
        click.echo(f"📭 No events found for: {query}")
        return
    
    click.echo(f"\n🔍 Search results for: {query}\n")
    click.echo(f"Found {len(events)} events:")
    
    for event in events:
        print_event(event)


@cli.command()
@click.argument('event_id')
@click.option('-c', '--calendar', default='primary', help='Calendar ID')
def event(event_id, calendar):
    """View details for a specific event."""
    auth = get_auth()
    if not auth.authenticate():
        click.echo("❌ Authentication failed. Please check your credentials.", err=True)
        sys.exit(1)
    
    evt = get_event(event_id, calendar_id=calendar)
    
    if not evt:
        click.echo(f"❌ Event not found: {event_id}")
        return
    
    print_event(evt, verbose=True)


@cli.command()
@click.option('-c', '--calendar', default='primary', help='Calendar ID')
def now(calendar):
    """View current event or next upcoming event."""
    auth = get_auth()
    if not auth.authenticate():
        click.echo("❌ Authentication failed. Please check your credentials.", err=True)
        sys.exit(1)
    
    evt = get_current_or_next_event(calendar_id=calendar)
    
    if not evt:
        click.echo("📭 No current or upcoming events in the next 24 hours.")
        return
    
    if evt.get('is_current'):
        click.echo("\n🔴 HAPPENING NOW:")
    else:
        click.echo("\n⏭️  NEXT UP:")
    
    print_event(evt, verbose=True)


@cli.command()
def auth_status():
    """Check authentication status."""
    auth = get_auth()
    
    click.echo("\n🔐 Authentication Status\n")
    
    # Check token file
    if auth.token_file.exists():
        click.echo(f"Token file: Found ({auth.token_file})")
    else:
        click.echo("Token file: Not found")
        click.echo("  Run any command to start authentication.")
        return
    
    # Check credentials file
    if not auth.credentials_file.exists():
        click.echo(f"Credentials: ❌ Not found at {auth.credentials_file}")
        click.echo("  Please follow SETUP.md to configure Google Cloud credentials.")
        return
    else:
        click.echo("Credentials: Found")
    
    # Try to authenticate
    if auth.authenticate():
        # Test actual Calendar API access
        try:
            from .calendar_ops import list_calendars
            cals = list_calendars()
            click.echo(f"Status: ✅ Authenticated with Calendar access")
            click.echo(f"Calendars accessible: {len(cals)}")
            user_email = auth.get_user_email()
            if user_email:
                click.echo(f"Account: {user_email}")
        except Exception as e:
            click.echo(f"Status: ⚠️  Token valid but Calendar access failed")
            click.echo(f"Error: {str(e)}")
            click.echo("\nYou may need to re-authenticate with Calendar scope.")
            click.echo("Delete gdrive_token.json and run any command to re-authenticate.")
    else:
        click.echo("Status: ❌ Authentication failed")


if __name__ == '__main__':
    cli()
