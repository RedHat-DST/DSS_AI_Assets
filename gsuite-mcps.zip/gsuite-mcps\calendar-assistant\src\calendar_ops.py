"""
Google Calendar Operations Module.

Provides high-level functions for Calendar interactions:
- List calendars
- Get events for a time range
- Search events
- Get event details
- Get today's schedule
- Get upcoming events
- Create events with full metadata support
"""

from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dateutil import parser as date_parser
import pytz

from .auth import get_calendar_service


def list_calendars(calendar_service=None) -> List[Dict[str, Any]]:
    """
    List all calendars accessible to the user.

    Args:
        calendar_service: Optional Calendar service (uses default if not provided)

    Returns:
        List of calendar dictionaries with id, summary, description, timezone
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        calendar_list = calendar_service.calendarList().list().execute()
        calendars = []

        for cal in calendar_list.get('items', []):
            calendars.append({
                'id': cal.get('id'),
                'summary': cal.get('summary'),
                'description': cal.get('description', ''),
                'timezone': cal.get('timeZone', ''),
                'primary': cal.get('primary', False),
                'backgroundColor': cal.get('backgroundColor', ''),
                'accessRole': cal.get('accessRole', '')
            })

        return calendars

    except Exception as e:
        print(f"❌ Failed to list calendars: {e}")
        return []


def get_events(
    calendar_id: str = 'primary',
    time_min: Optional[datetime] = None,
    time_max: Optional[datetime] = None,
    max_results: int = 50,
    single_events: bool = True,
    order_by: str = 'startTime',
    calendar_service=None
) -> List[Dict[str, Any]]:
    """
    Get calendar events for a time range.

    Args:
        calendar_id: Calendar ID (default: 'primary')
        time_min: Start time for event search
        time_max: End time for event search
        max_results: Maximum number of events to return
        single_events: Expand recurring events into instances
        order_by: Sort order ('startTime' or 'updated')
        calendar_service: Optional Calendar service

    Returns:
        List of event dictionaries
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        # Default to today if no time specified
        if time_min is None:
            time_min = datetime.now(pytz.UTC).replace(hour=0, minute=0, second=0, microsecond=0)
        
        # Convert to RFC3339 format
        time_min_str = time_min.isoformat()
        time_max_str = time_max.isoformat() if time_max else None

        # Build request parameters
        params = {
            'calendarId': calendar_id,
            'timeMin': time_min_str,
            'maxResults': max_results,
            'singleEvents': single_events,
            'orderBy': order_by if single_events else None
        }

        if time_max_str:
            params['timeMax'] = time_max_str

        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}

        events_result = calendar_service.events().list(**params).execute()
        events = events_result.get('items', [])

        # Parse and format events
        formatted_events = []
        for event in events:
            formatted_events.append(_format_event(event))

        return formatted_events

    except Exception as e:
        print(f"❌ Failed to get events: {e}")
        return []


def get_event(
    event_id: str,
    calendar_id: str = 'primary',
    calendar_service=None
) -> Optional[Dict[str, Any]]:
    """
    Get details for a specific event.

    Args:
        event_id: Event ID
        calendar_id: Calendar ID (default: 'primary')
        calendar_service: Optional Calendar service

    Returns:
        Event dictionary or None if not found
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        event = calendar_service.events().get(
            calendarId=calendar_id,
            eventId=event_id
        ).execute()

        return _format_event(event)

    except Exception as e:
        print(f"❌ Failed to get event: {e}")
        return None


def get_todays_events(calendar_id: str = 'primary', calendar_service=None) -> List[Dict[str, Any]]:
    """
    Get all events for today.

    Args:
        calendar_id: Calendar ID (default: 'primary')
        calendar_service: Optional Calendar service

    Returns:
        List of today's events
    """
    now = datetime.now(pytz.UTC)
    start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end_of_day = start_of_day + timedelta(days=1)

    return get_events(
        calendar_id=calendar_id,
        time_min=start_of_day,
        time_max=end_of_day,
        calendar_service=calendar_service
    )


def get_upcoming_events(
    days: int = 7,
    calendar_id: str = 'primary',
    max_results: int = 50,
    calendar_service=None
) -> List[Dict[str, Any]]:
    """
    Get upcoming events for the next N days.

    Args:
        days: Number of days to look ahead
        calendar_id: Calendar ID (default: 'primary')
        max_results: Maximum number of events
        calendar_service: Optional Calendar service

    Returns:
        List of upcoming events
    """
    now = datetime.now(pytz.UTC)
    future = now + timedelta(days=days)

    return get_events(
        calendar_id=calendar_id,
        time_min=now,
        time_max=future,
        max_results=max_results,
        calendar_service=calendar_service
    )


def search_events(
    query: str,
    calendar_id: str = 'primary',
    time_min: Optional[datetime] = None,
    time_max: Optional[datetime] = None,
    max_results: int = 50,
    calendar_service=None
) -> List[Dict[str, Any]]:
    """
    Search for events by text query.

    Args:
        query: Search query string
        calendar_id: Calendar ID (default: 'primary')
        time_min: Start time for search
        time_max: End time for search
        max_results: Maximum number of results
        calendar_service: Optional Calendar service

    Returns:
        List of matching events
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        # Build request parameters
        params = {
            'calendarId': calendar_id,
            'q': query,
            'maxResults': max_results,
            'singleEvents': True,
            'orderBy': 'startTime'
        }

        if time_min:
            params['timeMin'] = time_min.isoformat()
        if time_max:
            params['timeMax'] = time_max.isoformat()

        events_result = calendar_service.events().list(**params).execute()
        events = events_result.get('items', [])

        # Parse and format events
        formatted_events = []
        for event in events:
            formatted_events.append(_format_event(event))

        return formatted_events

    except Exception as e:
        print(f"❌ Failed to search events: {e}")
        return []


def get_current_or_next_event(calendar_id: str = 'primary', calendar_service=None) -> Optional[Dict[str, Any]]:
    """
    Get the current event (if one is happening now) or the next upcoming event.

    Args:
        calendar_id: Calendar ID (default: 'primary')
        calendar_service: Optional Calendar service

    Returns:
        Current or next event, or None
    """
    now = datetime.now(pytz.UTC)
    
    # Get events for the next 24 hours
    events = get_events(
        calendar_id=calendar_id,
        time_min=now,
        time_max=now + timedelta(days=1),
        max_results=10,
        calendar_service=calendar_service
    )

    if not events:
        return None

    # Check if any event is currently happening
    for event in events:
        start = event.get('start_datetime')
        end = event.get('end_datetime')
        if start and end and start <= now <= end:
            event['is_current'] = True
            return event

    # Return the next event
    if events:
        events[0]['is_current'] = False
        return events[0]

    return None


def get_free_busy(
    time_min: datetime,
    time_max: datetime,
    calendar_ids: List[str] = None,
    calendar_service=None
) -> Dict[str, Any]:
    """
    Get free/busy information for calendars.

    Args:
        time_min: Start time
        time_max: End time
        calendar_ids: List of calendar IDs (default: ['primary'])
        calendar_service: Optional Calendar service

    Returns:
        Dictionary with free/busy information
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    if calendar_ids is None:
        calendar_ids = ['primary']

    try:
        body = {
            'timeMin': time_min.isoformat(),
            'timeMax': time_max.isoformat(),
            'items': [{'id': cal_id} for cal_id in calendar_ids]
        }

        result = calendar_service.freebusy().query(body=body).execute()
        return result

    except Exception as e:
        print(f"❌ Failed to get free/busy: {e}")
        return {}


def create_event(
    summary: str,
    start_time: datetime,
    end_time: datetime,
    calendar_id: str = 'primary',
    description: Optional[str] = None,
    location: Optional[str] = None,
    attendees: Optional[List[str]] = None,
    conference_solution: Optional[str] = None,
    attachments: Optional[List[Dict[str, str]]] = None,
    reminders: Optional[Dict[str, Any]] = None,
    recurrence: Optional[List[str]] = None,
    color_id: Optional[str] = None,
    visibility: Optional[str] = None,
    transparency: Optional[str] = None,
    timezone: Optional[str] = None,
    calendar_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a new calendar event with comprehensive metadata support.

    Args:
        summary: Event title/summary (required)
        start_time: Event start datetime (required)
        end_time: Event end datetime (required)
        calendar_id: Calendar ID (default: 'primary')
        description: Event description/notes
        location: Event location (address or place name)
        attendees: List of attendee email addresses
        conference_solution: Type of video conference ('hangoutsMeet', 'zoom', or custom URL)
        attachments: List of attachment dicts with 'fileUrl', 'title', 'mimeType'
        reminders: Reminder settings dict with 'useDefault' or 'overrides' list
        recurrence: List of RRULE strings for recurring events
        color_id: Color ID (1-11) for event color
        visibility: Event visibility ('default', 'public', 'private', 'confidential')
        transparency: Time transparency ('opaque' or 'transparent' for free/busy)
        timezone: Timezone for the event (default: UTC)
        calendar_service: Optional Calendar service

    Returns:
        Created event dictionary or None on failure
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        # Build event object
        event = {
            'summary': summary,
        }

        # Handle timezone
        if timezone is None:
            timezone = 'UTC'

        # Set start and end times
        if isinstance(start_time, datetime):
            # Check if it's an all-day event (time is midnight and matches end)
            if (start_time.time().hour == 0 and start_time.time().minute == 0 and 
                end_time.time().hour == 0 and end_time.time().minute == 0):
                # All-day event
                event['start'] = {'date': start_time.strftime('%Y-%m-%d')}
                event['end'] = {'date': end_time.strftime('%Y-%m-%d')}
            else:
                # Timed event
                event['start'] = {
                    'dateTime': start_time.isoformat(),
                    'timeZone': timezone
                }
                event['end'] = {
                    'dateTime': end_time.isoformat(),
                    'timeZone': timezone
                }

        # Optional fields
        if description:
            event['description'] = description

        if location:
            event['location'] = location

        if attendees:
            event['attendees'] = [{'email': email} for email in attendees]

        # Conference data
        if conference_solution:
            if conference_solution.lower() == 'hangoutsmeet' or conference_solution.lower() == 'meet':
                event['conferenceData'] = {
                    'createRequest': {
                        'requestId': f"meet-{datetime.now().timestamp()}",
                        'conferenceSolutionKey': {'type': 'hangoutsMeet'}
                    }
                }
            elif conference_solution.lower() == 'zoom':
                # For Zoom, user should provide URL in description or location
                # We'll add a note in the description
                if description:
                    event['description'] = f"{description}\n\nZoom link: (Please add manually or use Zoom integration)"
                else:
                    event['description'] = "Zoom link: (Please add manually or use Zoom integration)"
            elif conference_solution.startswith('http'):
                # Custom video conference URL
                event['conferenceData'] = {
                    'entryPoints': [{
                        'entryPointType': 'video',
                        'uri': conference_solution,
                        'label': 'Join video call'
                    }]
                }

        # Attachments
        if attachments:
            event['attachments'] = attachments

        # Reminders
        if reminders:
            event['reminders'] = reminders
        else:
            # Use default reminders
            event['reminders'] = {'useDefault': True}

        # Recurrence
        if recurrence:
            event['recurrence'] = recurrence

        # Color
        if color_id:
            event['colorId'] = str(color_id)

        # Visibility
        if visibility:
            event['visibility'] = visibility

        # Transparency
        if transparency:
            event['transparency'] = transparency

        # Create the event
        # Use conferenceDataVersion=1 if we're creating conference data
        params = {
            'calendarId': calendar_id,
            'body': event
        }
        
        if conference_solution and conference_solution.lower() in ['hangoutsmeet', 'meet']:
            params['conferenceDataVersion'] = 1

        created_event = calendar_service.events().insert(**params).execute()

        return _format_event(created_event)

    except Exception as e:
        print(f"❌ Failed to create event: {e}")
        return None


def update_event(
    event_id: str,
    calendar_id: str = 'primary',
    summary: Optional[str] = None,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    description: Optional[str] = None,
    location: Optional[str] = None,
    attendees: Optional[List[str]] = None,
    calendar_service=None
) -> Optional[Dict[str, Any]]:
    """
    Update an existing calendar event.

    Args:
        event_id: Event ID to update (required)
        calendar_id: Calendar ID (default: 'primary')
        summary: New event title
        start_time: New start datetime
        end_time: New end datetime
        description: New description
        location: New location
        attendees: New list of attendee emails
        calendar_service: Optional Calendar service

    Returns:
        Updated event dictionary or None on failure
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        # Get the existing event first
        existing_event = calendar_service.events().get(
            calendarId=calendar_id,
            eventId=event_id
        ).execute()

        # Update only the provided fields
        if summary is not None:
            existing_event['summary'] = summary

        if start_time is not None:
            existing_event['start'] = {
                'dateTime': start_time.isoformat(),
                'timeZone': existing_event['start'].get('timeZone', 'UTC')
            }

        if end_time is not None:
            existing_event['end'] = {
                'dateTime': end_time.isoformat(),
                'timeZone': existing_event['end'].get('timeZone', 'UTC')
            }

        if description is not None:
            existing_event['description'] = description

        if location is not None:
            existing_event['location'] = location

        if attendees is not None:
            existing_event['attendees'] = [{'email': email} for email in attendees]

        # Update the event
        updated_event = calendar_service.events().update(
            calendarId=calendar_id,
            eventId=event_id,
            body=existing_event
        ).execute()

        return _format_event(updated_event)

    except Exception as e:
        print(f"❌ Failed to update event: {e}")
        return None


def delete_event(
    event_id: str,
    calendar_id: str = 'primary',
    calendar_service=None
) -> bool:
    """
    Delete a calendar event.

    Args:
        event_id: Event ID to delete (required)
        calendar_id: Calendar ID (default: 'primary')
        calendar_service: Optional Calendar service

    Returns:
        True if successful, False otherwise
    """
    if calendar_service is None:
        calendar_service = get_calendar_service()

    try:
        calendar_service.events().delete(
            calendarId=calendar_id,
            eventId=event_id
        ).execute()
        return True

    except Exception as e:
        print(f"❌ Failed to delete event: {e}")
        return False


def _format_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Format a raw Calendar API event into a more usable structure.

    Args:
        event: Raw event from Calendar API

    Returns:
        Formatted event dictionary
    """
    # Parse start and end times
    start = event.get('start', {})
    end = event.get('end', {})

    # Handle both dateTime and date (all-day events)
    start_dt = start.get('dateTime')
    end_dt = end.get('dateTime')
    is_all_day = False

    if not start_dt:
        # All-day event
        start_dt = start.get('date')
        end_dt = end.get('date')
        is_all_day = True

    # Parse datetime strings
    start_datetime = None
    end_datetime = None
    if start_dt:
        try:
            start_datetime = date_parser.parse(start_dt)
        except Exception:
            pass
    if end_dt:
        try:
            end_datetime = date_parser.parse(end_dt)
        except Exception:
            pass

    # Get attendees
    attendees = []
    for attendee in event.get('attendees', []):
        attendees.append({
            'email': attendee.get('email', ''),
            'displayName': attendee.get('displayName', ''),
            'responseStatus': attendee.get('responseStatus', 'needsAction'),
            'organizer': attendee.get('organizer', False),
            'self': attendee.get('self', False)
        })

    # Format location
    location = event.get('location', '')
    
    # Check for conference/meet links
    conference_data = event.get('conferenceData', {})
    conference_link = None
    if conference_data:
        for entry_point in conference_data.get('entryPoints', []):
            if entry_point.get('entryPointType') == 'video':
                conference_link = entry_point.get('uri')
                break

    # Get attachments
    attachments = []
    for attachment in event.get('attachments', []):
        attachments.append({
            'fileUrl': attachment.get('fileUrl', ''),
            'title': attachment.get('title', 'Untitled'),
            'mimeType': attachment.get('mimeType', ''),
            'iconLink': attachment.get('iconLink', ''),
            'fileId': attachment.get('fileId', '')
        })

    return {
        'id': event.get('id'),
        'summary': event.get('summary', 'No Title'),
        'description': event.get('description', ''),
        'location': location,
        'start': start_dt,
        'end': end_dt,
        'start_datetime': start_datetime,
        'end_datetime': end_datetime,
        'is_all_day': is_all_day,
        'status': event.get('status', ''),
        'attendees': attendees,
        'organizer': event.get('organizer', {}),
        'creator': event.get('creator', {}),
        'hangout_link': event.get('hangoutLink', ''),
        'conference_link': conference_link or event.get('hangoutLink', ''),
        'html_link': event.get('htmlLink', ''),
        'recurring_event_id': event.get('recurringEventId', ''),
        'created': event.get('created', ''),
        'updated': event.get('updated', ''),
        'transparency': event.get('transparency', 'opaque'),  # opaque or transparent
        'visibility': event.get('visibility', 'default'),  # default, public, private
        'attachments': attachments,
    }
