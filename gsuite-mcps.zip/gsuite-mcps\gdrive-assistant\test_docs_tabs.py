#!/usr/bin/env python3
"""
Comprehensive test for Google Docs tab create, edit, and delete.

Tests:
1. Create a document in the specified Drive folder
2. Create tabs (Tab A, Tab B, Tab C at index 1)
3. List tabs and verify count and order
4. Update a tab (rename Tab C to "Tab C Renamed")
5. Append content to tabs and read back
6. Delete a tab (Tab B) and verify
7. Final tab list and document URL

Requirements:
- Authenticated Google Drive access
- Test document is created in folder 1vSNhxgT2erehA5T1eBOZXxTPvvbBUqwp
"""

import sys
from datetime import datetime

from src.auth import get_auth
from src.docs_ops import (
    create_doc,
    list_tabs,
    create_tab,
    update_tab,
    delete_tab,
    append_to_doc,
    read_tab,
)
from src.drive_ops import delete_file

TEST_FOLDER_ID = "1vSNhxgT2erehA5T1eBOZXxTPvvbBUqwp"


def _tab_by_title(tabs, title):
    """Return first tab dict with matching title, or None."""
    for t in tabs:
        if t.get("title") == title:
            return t
    return None


def test_docs_tabs():
    """Run full tab create/edit/delete test."""
    auth = get_auth()
    if not auth.authenticate():
        print("❌ Authentication failed")
        return False

    print("✅ Authenticated successfully\n")

    # Create test document in target folder
    title = f"Test Docs Tabs - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    print("📝 Creating test document...")
    doc_result = create_doc(
        title=title,
        folder_id=TEST_FOLDER_ID,
    )
    if not doc_result:
        print("❌ Failed to create test document")
        return False

    doc_id = doc_result["id"]
    url = doc_result["url"]
    print(f"✅ Created document: {doc_id}")
    print(f"   URL: {url}\n")

    try:
        # Step 1: Create tabs
        print("Step 1: Create tabs (Tab A, Tab B, Tab C at index 1)")
        r1 = create_tab(doc_id, "Tab A")
        if not r1:
            print("  ❌ create_tab Tab A failed")
            return False
        print("  ✅ Tab A created")

        r2 = create_tab(doc_id, "Tab B")
        if not r2:
            print("  ❌ create_tab Tab B failed")
            return False
        print("  ✅ Tab B created")

        r3 = create_tab(doc_id, "Tab C", index=1)
        if not r3:
            print("  ❌ create_tab Tab C at index 1 failed")
            return False
        print("  ✅ Tab C created at index 1\n")

        # Step 2: List tabs and verify
        print("Step 2: List tabs and verify")
        tabs = list_tabs(doc_id)
        if not tabs:
            print("  ❌ list_tabs failed")
            return False
        if len(tabs) < 3:
            print(f"  ❌ Expected at least 3 tabs, got {len(tabs)}")
            return False
        print(f"  ✅ Found {len(tabs)} tab(s)")

        tab_a = _tab_by_title(tabs, "Tab A")
        tab_b = _tab_by_title(tabs, "Tab B")
        tab_c = _tab_by_title(tabs, "Tab C")
        if not tab_a or not tab_b or not tab_c:
            print("  ❌ Could not find Tab A, Tab B, or Tab C by title")
            return False
        tab_a_id = tab_a.get("tab_id")
        tab_b_id = tab_b.get("tab_id")
        tab_c_id = tab_c.get("tab_id")
        if not tab_a_id or not tab_b_id or not tab_c_id:
            print("  ❌ One or more tab_id missing (document may not support tabs)")
            return False
        print("  ✅ Tab A, Tab B, Tab C present with IDs\n")

        # Step 3: Update tab (rename Tab C)
        print("Step 3: Update tab (rename Tab C to 'Tab C Renamed')")
        r_update = update_tab(doc_id, tab_c_id, title="Tab C Renamed")
        if not r_update:
            print("  ❌ update_tab failed")
            return False
        print("  ✅ Tab C renamed\n")

        # Step 4: Append content and read back
        print("Step 4: Append content to Tab A and Tab C Renamed, then read")
        ok_a = append_to_doc(doc_id, "Content in Tab A\n", content_type="plain", tab_id=tab_a_id)
        if not ok_a:
            print("  ❌ append_to_doc Tab A failed")
            return False
        ok_c = append_to_doc(
            doc_id, "Content in Tab C Renamed\n", content_type="plain", tab_id=tab_c_id
        )
        if not ok_c:
            print("  ❌ append_to_doc Tab C failed")
            return False
        print("  ✅ Appended content to Tab A and Tab C")

        result_a = read_tab(doc_id, tab_id=tab_a_id)
        result_c = read_tab(doc_id, tab_id=tab_c_id)
        if not result_a or "Content in Tab A" not in (result_a.get("text") or ""):
            print("  ❌ read_tab Tab A: content not found")
            return False
        if not result_c or "Content in Tab C Renamed" not in (result_c.get("text") or ""):
            print("  ❌ read_tab Tab C: content not found")
            return False
        print("  ✅ Read back content verified\n")

        # Step 5: Delete Tab B
        print("Step 5: Delete Tab B")
        r_del = delete_tab(doc_id, tab_b_id)
        if not r_del:
            print("  ❌ delete_tab failed")
            return False
        print("  ✅ Tab B deleted")

        tabs_after = list_tabs(doc_id)
        if not tabs_after:
            print("  ❌ list_tabs after delete failed")
            return False
        if _tab_by_title(tabs_after, "Tab B"):
            print("  ❌ Tab B still present after delete")
            return False
        if len(tabs_after) != len(tabs) - 1:
            print(f"  ❌ Expected {len(tabs) - 1} tabs after delete, got {len(tabs_after)}")
            return False
        print("  ✅ Tab list updated, Tab B gone\n")

        # Step 6: Final summary
        print("=" * 60)
        print("Final tab list:")
        for t in list_tabs(doc_id) or []:
            print(f"  - {t.get('title')} (id: {t.get('tab_id')})")
        print("=" * 60)
        print(f"✅ All tests passed!")
        print(f"View document at: {url}")
        print("=" * 60)

        if sys.stdin.isatty():
            response = input("\nDelete test document? (y/N): ")
            if response.lower() == "y":
                if delete_file(doc_id, permanent=True):
                    print("✅ Test document deleted")
                else:
                    print("⚠️  Failed to delete test document")
            else:
                print(f"ℹ️  Test document preserved: {url}")
        else:
            print(f"\nℹ️  Non-interactive run: test document preserved at {url}")

        return True

    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_docs_tabs()
    sys.exit(0 if success else 1)
