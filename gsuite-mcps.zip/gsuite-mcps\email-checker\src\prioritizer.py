"""
Email Prioritization Engine.

Scores and prioritizes emails based on:
- VIP sender detection
- Priority keywords in subject
- Jira ticket references
- Unread status and recency
- Direct recipient vs CC
"""

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

import yaml


# Default config path
PROJECT_ROOT = Path(__file__).parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "config.yaml"


class EmailPrioritizer:
    """Scores and prioritizes emails based on configurable rules."""

    def __init__(self, config_path: Optional[Path] = None):
        """
        Initialize prioritizer with configuration.

        Args:
            config_path: Path to config.yaml (uses default if not provided)
        """
        self.config_path = config_path or DEFAULT_CONFIG_PATH
        self.config = self._load_config()

        # Pre-process config for faster lookups
        self.vip_senders = set(
            email.lower() for email in self.config.get('vip_senders', []) or []
        )
        self.priority_keywords = [
            kw.lower() for kw in self.config.get('priority_keywords', []) or []
        ]
        self.jira_projects = set(
            proj.upper() for proj in self.config.get('jira_projects', []) or []
        )
        self.priority_domains = set(
            domain.lower() for domain in self.config.get('priority_domains', []) or []
        )

        # Thresholds
        thresholds = self.config.get('thresholds', {})
        self.high_threshold = thresholds.get('high', 50)
        self.medium_threshold = thresholds.get('medium', 25)

        # Scoring weights
        scoring = self.config.get('scoring', {})
        self.score_vip = scoring.get('vip_sender', 50)
        self.score_priority_domain = scoring.get('priority_domain', 30)
        self.score_jira = scoring.get('jira_ticket', 20)
        self.score_keyword = scoring.get('priority_keyword', 15)
        self.score_unread = scoring.get('unread', 10)
        self.score_recent = scoring.get('recent', 10)
        self.score_direct = scoring.get('direct_recipient', 5)

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r') as f:
                    return yaml.safe_load(f) or {}
        except Exception as e:
            print(f"⚠️  Failed to load config: {e}")
        return {}

    def score_email(
        self,
        email: Dict[str, Any],
        user_email: Optional[str] = None
    ) -> Tuple[int, str, List[str]]:
        """
        Calculate priority score for an email.

        Args:
            email: Email dictionary with metadata
            user_email: Current user's email (for direct recipient check)

        Returns:
            Tuple of (score, priority_level, reasons)
            priority_level: 'HIGH', 'MEDIUM', or 'LOW'
        """
        score = 0
        reasons = []

        # Extract sender email
        from_email = email.get('from_email', '').lower()
        if not from_email:
            # Try to extract from 'from' field
            from_field = email.get('from', '')
            email_match = re.search(r'<([^>]+)>', from_field)
            if email_match:
                from_email = email_match.group(1).lower()
            elif '@' in from_field:
                from_email = from_field.strip().lower()

        # VIP sender check
        if from_email in self.vip_senders:
            score += self.score_vip
            reasons.append(f"VIP sender (+{self.score_vip})")

        # Priority domain check
        if from_email:
            domain = from_email.split('@')[-1] if '@' in from_email else ''
            if domain in self.priority_domains:
                score += self.score_priority_domain
                reasons.append(f"Priority domain (+{self.score_priority_domain})")

        # Priority keywords in subject
        subject = email.get('subject', '').lower()
        matched_keywords = [kw for kw in self.priority_keywords if kw in subject]
        if matched_keywords:
            score += self.score_keyword
            reasons.append(f"Keyword '{matched_keywords[0]}' (+{self.score_keyword})")

        # Jira ticket check
        jira_tickets = email.get('jira_tickets', [])
        if not jira_tickets:
            # Try to extract from subject/snippet
            text = f"{email.get('subject', '')} {email.get('snippet', '')}"
            jira_tickets = self._extract_jira_tickets(text)

        if jira_tickets:
            # Check if any match our tracked projects
            tracked = [t for t in jira_tickets if t.split('-')[0] in self.jira_projects]
            if tracked:
                score += self.score_jira
                reasons.append(f"Jira {tracked[0]} (+{self.score_jira})")
            elif jira_tickets:
                # Still give some points for any Jira reference
                score += self.score_jira // 2
                reasons.append(f"Jira {jira_tickets[0]} (+{self.score_jira // 2})")

        # Unread check
        is_unread = email.get('is_unread', False)
        if not is_unread:
            # Check labels
            labels = email.get('labels', [])
            is_unread = 'UNREAD' in labels
        if is_unread:
            score += self.score_unread
            reasons.append(f"Unread (+{self.score_unread})")

        # Recency check (< 4 hours)
        date_obj = email.get('date_obj')
        if date_obj:
            now = datetime.now(timezone.utc)
            if date_obj.tzinfo is None:
                # Assume UTC if no timezone
                date_obj = date_obj.replace(tzinfo=timezone.utc)
            age_hours = (now - date_obj).total_seconds() / 3600
            if age_hours < 4:
                score += self.score_recent
                reasons.append(f"Recent ({age_hours:.1f}h ago, +{self.score_recent})")

        # Direct recipient check
        if user_email:
            to_field = email.get('to', '').lower()
            if user_email.lower() in to_field:
                score += self.score_direct
                reasons.append(f"Direct recipient (+{self.score_direct})")

        # Determine priority level
        if score >= self.high_threshold:
            priority = 'HIGH'
        elif score >= self.medium_threshold:
            priority = 'MEDIUM'
        else:
            priority = 'LOW'

        return score, priority, reasons

    def prioritize_emails(
        self,
        emails: List[Dict[str, Any]],
        user_email: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Score and sort emails by priority.

        Args:
            emails: List of email dictionaries
            user_email: Current user's email for direct recipient check

        Returns:
            List of emails with added priority fields, sorted by score (descending)
        """
        scored_emails = []

        for email in emails:
            score, priority, reasons = self.score_email(email, user_email)
            email_copy = email.copy()
            email_copy['priority_score'] = score
            email_copy['priority_level'] = priority
            email_copy['priority_reasons'] = reasons
            scored_emails.append(email_copy)

        # Sort by score descending
        scored_emails.sort(key=lambda e: e['priority_score'], reverse=True)

        return scored_emails

    def get_priority_summary(
        self,
        emails: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate a summary of email priorities.

        Args:
            emails: List of prioritized emails (with priority_level field)

        Returns:
            Dictionary with priority breakdown
        """
        high = [e for e in emails if e.get('priority_level') == 'HIGH']
        medium = [e for e in emails if e.get('priority_level') == 'MEDIUM']
        low = [e for e in emails if e.get('priority_level') == 'LOW']

        return {
            'total': len(emails),
            'high_count': len(high),
            'medium_count': len(medium),
            'low_count': len(low),
            'high_emails': high,
            'medium_emails': medium,
            'low_emails': low
        }

    def _extract_jira_tickets(self, text: str) -> List[str]:
        """Extract Jira ticket references from text."""
        pattern = r'\b([A-Z]{2,10}-\d+)\b'
        matches = re.findall(pattern, text)
        return list(set(matches))


# Singleton instance
_default_prioritizer: Optional[EmailPrioritizer] = None


def get_prioritizer() -> EmailPrioritizer:
    """Get the default EmailPrioritizer instance."""
    global _default_prioritizer
    if _default_prioritizer is None:
        _default_prioritizer = EmailPrioritizer()
    return _default_prioritizer


def prioritize_emails(
    emails: List[Dict[str, Any]],
    user_email: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Convenience function to prioritize emails."""
    return get_prioritizer().prioritize_emails(emails, user_email)

