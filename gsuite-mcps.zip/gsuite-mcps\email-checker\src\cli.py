"""
Gmail Email Assistant CLI.

Command-line interface for quick email access and prioritization.

Usage:
    python -m src.cli inbox          # View inbox
    python -m src.cli priority       # View prioritized emails
    python -m src.cli unread         # View unread emails
    python -m src.cli search "query" # Search emails
    python -m src.cli read <id>      # Read specific email
    python -m src.cli summary        # Inbox summary stats
    python -m src.cli draft --to <email> --subject <subject> --body <body>  # Create draft
    python -m src.cli auth_status    # Check authentication status
"""

import sys
from datetime import datetime
from typing import Optional

import click

from .auth import get_auth, GmailAuth
from .gmail_ops import (
    search_emails, get_inbox, get_unread, read_email, get_inbox_summary, 
    create_draft, get_labels, ensure_gtd_labels, get_emails_without_gtd_labels,
    apply_labels, GTD_LABELS
)
from .prioritizer import prioritize_emails, get_prioritizer


# Color scheme for priority levels
PRIORITY_COLORS = {
    'HIGH': 'red',
    'MEDIUM': 'yellow',
    'LOW': 'white'
}


def format_date(date_obj: Optional[datetime]) -> str:
    """Format date for display."""
    if not date_obj:
        return "Unknown"
    now = datetime.now(date_obj.tzinfo) if date_obj.tzinfo else datetime.now()
    diff = now - date_obj

    if diff.days == 0:
        hours = diff.seconds // 3600
        if hours == 0:
            minutes = diff.seconds // 60
            return f"{minutes}m ago"
        return f"{hours}h ago"
    elif diff.days == 1:
        return "Yesterday"
    elif diff.days < 7:
        return f"{diff.days}d ago"
    else:
        return date_obj.strftime("%b %d")


def truncate(text: str, length: int) -> str:
    """Truncate text to specified length."""
    if len(text) <= length:
        return text
    return text[:length - 3] + "..."


def print_email_row(email: dict, show_priority: bool = False):
    """Print a single email row."""
    priority = email.get('priority_level', 'LOW')
    color = PRIORITY_COLORS.get(priority, 'white')

    # Format components
    date_str = format_date(email.get('date_obj'))
    from_str = truncate(email.get('from', 'Unknown'), 30)
    subject_str = truncate(email.get('subject', 'No Subject'), 50)
    unread_marker = "●" if email.get('is_unread') else " "

    # Priority indicator
    if show_priority:
        priority_char = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '⚪'}.get(priority, '⚪')
        score = email.get('priority_score', 0)
        click.echo(
            f"{priority_char} "
            f"{click.style(unread_marker, fg='blue')} "
            f"{click.style(date_str.ljust(10), fg='cyan')} "
            f"{click.style(from_str.ljust(32), fg=color)} "
            f"{subject_str} "
            f"{click.style(f'[{score}]', fg='bright_black')}"
        )
    else:
        click.echo(
            f"{click.style(unread_marker, fg='blue')} "
            f"{click.style(date_str.ljust(10), fg='cyan')} "
            f"{click.style(from_str.ljust(32), fg='white')} "
            f"{subject_str}"
        )

    # Show email ID in dim text for reference
    email_id = email.get('id', '')
    click.echo(f"   {click.style(f'ID: {email_id}', fg='bright_black')}")


def print_email_detail(email: dict):
    """Print full email details."""
    click.echo()
    click.echo(click.style("=" * 70, fg='bright_black'))

    # Priority info if available
    if 'priority_level' in email:
        priority = email['priority_level']
        color = PRIORITY_COLORS.get(priority, 'white')
        score = email.get('priority_score', 0)
        reasons = email.get('priority_reasons', [])
        click.echo(f"Priority: {click.style(f'{priority} ({score} points)', fg=color, bold=True)}")
        if reasons:
            click.echo(f"  Reasons: {', '.join(reasons)}")
        click.echo()

    # Headers
    click.echo(f"{click.style('From:', fg='cyan')}    {email.get('from', 'Unknown')}")
    click.echo(f"{click.style('To:', fg='cyan')}      {email.get('to', 'Unknown')}")
    if email.get('cc'):
        click.echo(f"{click.style('Cc:', fg='cyan')}      {email['cc']}")
    click.echo(f"{click.style('Date:', fg='cyan')}    {email.get('date', 'Unknown')}")
    click.echo(f"{click.style('Subject:', fg='cyan')} {email.get('subject', 'No Subject')}")

    # Jira tickets
    if email.get('jira_tickets'):
        click.echo(f"{click.style('Jira:', fg='cyan')}    {', '.join(email['jira_tickets'])}")

    # Labels
    labels = email.get('labels', [])
    if labels:
        label_str = ', '.join(l for l in labels if not l.startswith('Label_'))
        if label_str:
            click.echo(f"{click.style('Labels:', fg='cyan')}  {label_str}")

    # URL
    click.echo(f"{click.style('URL:', fg='cyan')}     {email.get('url', '')}")

    click.echo(click.style("-" * 70, fg='bright_black'))

    # Body
    body = email.get('body', email.get('snippet', ''))
    if body:
        click.echo(body[:2000])  # Limit body length
        if len(body) > 2000:
            click.echo(click.style(f"\n... ({len(body) - 2000} more characters)", fg='bright_black'))
    else:
        click.echo(click.style("(No body content)", fg='bright_black'))

    click.echo(click.style("=" * 70, fg='bright_black'))
    click.echo()


@click.group()
@click.pass_context
def cli(ctx):
    """Gmail Email Assistant - Review and prioritize your emails."""
    ctx.ensure_object(dict)


@cli.command()
@click.option('-n', '--num', default=20, help='Number of emails to show')
@click.pass_context
def inbox(ctx, num: int):
    """View recent inbox emails."""
    click.echo(click.style("\n📥 Inbox", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        emails = get_inbox(max_results=num)

        if not emails:
            click.echo("No emails found.")
            return

        click.echo(f"Showing {len(emails)} emails:\n")
        for email in emails:
            print_email_row(email)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.option('-n', '--num', default=30, help='Number of emails to analyze')
@click.pass_context
def priority(ctx, num: int):
    """View emails sorted by priority."""
    click.echo(click.style("\n📊 Priority View", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        user_email = auth.get_user_email()

        # Get inbox emails
        emails = get_inbox(max_results=num)

        if not emails:
            click.echo("No emails found.")
            return

        # Prioritize
        prioritized = prioritize_emails(emails, user_email)

        # Get summary
        prioritizer = get_prioritizer()
        summary = prioritizer.get_priority_summary(prioritized)

        # Show summary
        click.echo(f"Analyzed {summary['total']} emails:")
        click.echo(f"  🔴 HIGH:   {summary['high_count']}")
        click.echo(f"  🟡 MEDIUM: {summary['medium_count']}")
        click.echo(f"  ⚪ LOW:    {summary['low_count']}")
        click.echo()

        # Show HIGH priority first
        if summary['high_emails']:
            click.echo(click.style("── HIGH PRIORITY ──", fg='red', bold=True))
            for email in summary['high_emails']:
                print_email_row(email, show_priority=True)
            click.echo()

        # Show MEDIUM priority
        if summary['medium_emails']:
            click.echo(click.style("── MEDIUM PRIORITY ──", fg='yellow', bold=True))
            for email in summary['medium_emails'][:10]:  # Limit display
                print_email_row(email, show_priority=True)
            if len(summary['medium_emails']) > 10:
                click.echo(click.style(f"   ... and {len(summary['medium_emails']) - 10} more", fg='bright_black'))
            click.echo()

        # Show LOW priority count only
        if summary['low_emails']:
            click.echo(click.style(f"── LOW PRIORITY ({summary['low_count']} emails) ──", fg='bright_black'))
            for email in summary['low_emails'][:5]:
                print_email_row(email, show_priority=True)
            if len(summary['low_emails']) > 5:
                click.echo(click.style(f"   ... and {len(summary['low_emails']) - 5} more", fg='bright_black'))

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.option('-n', '--num', default=20, help='Number of emails to show')
@click.pass_context
def unread(ctx, num: int):
    """View unread emails."""
    click.echo(click.style("\n📬 Unread Emails", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        emails = get_unread(max_results=num)

        if not emails:
            click.echo("No unread emails! 🎉")
            return

        user_email = auth.get_user_email()
        prioritized = prioritize_emails(emails, user_email)

        click.echo(f"Found {len(prioritized)} unread emails:\n")
        for email in prioritized:
            print_email_row(email, show_priority=True)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('query')
@click.option('-n', '--num', default=20, help='Number of results')
@click.pass_context
def search(ctx, query: str, num: int):
    """Search emails with Gmail query syntax."""
    click.echo(click.style(f"\n🔍 Search: {query}", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        emails = search_emails(query, max_results=num)

        if not emails:
            click.echo("No emails found matching your query.")
            return

        user_email = auth.get_user_email()
        prioritized = prioritize_emails(emails, user_email)

        click.echo(f"Found {len(prioritized)} emails:\n")
        for email in prioritized:
            print_email_row(email, show_priority=True)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('message_id')
@click.pass_context
def read(ctx, message_id: str):
    """Read a specific email by ID."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        email = read_email(message_id)

        if not email:
            click.echo(click.style(f"❌ Email not found: {message_id}", fg='red'))
            sys.exit(1)

        # Add priority info
        user_email = auth.get_user_email()
        prioritized = prioritize_emails([email], user_email)
        if prioritized:
            email = prioritized[0]

        print_email_detail(email)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.pass_context
def summary(ctx):
    """Show inbox summary statistics."""
    click.echo(click.style("\n📈 Inbox Summary", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        stats = get_inbox_summary()

        if not stats:
            click.echo("Failed to get inbox summary.")
            return

        click.echo(f"Account:        {stats.get('email', 'Unknown')}")
        click.echo(f"Total messages: {stats.get('total_messages', 0):,}")
        click.echo(f"Total threads:  {stats.get('total_threads', 0):,}")
        click.echo(f"Unread:         {stats.get('unread_count', 0)}")
        click.echo(f"Today:          {stats.get('today_count', 0)}")
        click.echo()

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.pass_context
def auth_status(ctx):
    """Check authentication status."""
    click.echo(click.style("\n🔐 Authentication Status", fg='green', bold=True))
    click.echo()

    auth = GmailAuth()

    if auth.token_file.exists():
        click.echo(f"Token file: {click.style('Found', fg='green')} ({auth.token_file})")
    else:
        click.echo(f"Token file: {click.style('Not found', fg='yellow')}")
        click.echo("  Run any command to start authentication.")
        return

    if auth.credentials_file.exists():
        click.echo(f"Credentials: {click.style('Found', fg='green')}")
    else:
        click.echo(f"Credentials: {click.style('Not found', fg='red')}")
        click.echo("  Please follow SETUP.md to configure Google Cloud credentials.")
        return

    # Try to authenticate
    if auth.authenticate():
        click.echo(f"Status: {click.style('Authenticated', fg='green')}")
        email = auth.get_user_email()
        if email:
            click.echo(f"Account: {email}")
    else:
        click.echo(f"Status: {click.style('Not authenticated', fg='red')}")


@cli.command()
@click.option('--to', required=True, help='Recipient email address(es), comma-separated')
@click.option('--subject', required=True, help='Email subject line')
@click.option('--body', required=True, help='Email body content')
@click.option('--cc', default='', help='CC recipients, comma-separated')
@click.option('--reply-to', 'reply_to_message_id', default='', help='Message ID to reply to (for threading)')
@click.option('--thread-id', 'thread_id', default='', help='Thread ID to add draft to')
@click.option('--content-type', 'content_type', default='markdown', 
              type=click.Choice(['markdown', 'plain', 'html', 'auto']),
              help="Body format: 'markdown' (default), 'plain' (for > quotes), 'html', or 'auto'")
@click.pass_context
def draft(ctx, to: str, subject: str, body: str, cc: str, reply_to_message_id: str, thread_id: str, content_type: str):
    """Create a draft email in Gmail."""
    click.echo(click.style("\n📝 Creating Draft", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = create_draft(
            to=to,
            subject=subject,
            body=body,
            cc=cc,
            reply_to_message_id=reply_to_message_id,
            thread_id=thread_id,
            content_type=content_type
        )

        if not result:
            click.echo(click.style("❌ Failed to create draft", fg='red'))
            sys.exit(1)

        click.echo(click.style("✅ Draft created successfully!", fg='green'))
        click.echo()
        click.echo(f"Draft ID:  {result.get('draft_id', '')}")
        click.echo(f"Thread ID: {result.get('thread_id', '')}")
        click.echo(f"View:      {result.get('url', '')}")
        click.echo()

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.pass_context
def labels(ctx):
    """Show GTD labels and setup status."""
    click.echo(click.style("\n🏷️  GTD Labels", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        # Get existing labels
        existing_labels = {label['name']: label for label in get_labels()}
        
        click.echo("GTD Label Status:\n")
        
        all_exist = True
        for label_name, colors in GTD_LABELS.items():
            if label_name in existing_labels:
                click.echo(f"  ✅ {label_name}")
            else:
                click.echo(f"  ❌ {label_name} (not created)")
                all_exist = False
        
        click.echo()
        
        if all_exist:
            click.echo(click.style("All GTD labels are set up! ✨", fg='green'))
        else:
            click.echo("Run 'python -m src.cli setup-labels' to create missing labels.")
        
        click.echo()

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command('setup-labels')
@click.pass_context
def setup_labels(ctx):
    """Create GTD labels in Gmail."""
    click.echo(click.style("\n🏷️  Setting up GTD Labels", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        label_ids = ensure_gtd_labels()
        
        click.echo()
        click.echo(f"✅ {len(label_ids)} GTD labels ready")
        click.echo()

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.option('-n', '--num', default=20, help='Number of emails to show')
@click.pass_context
def uncategorized(ctx, num: int):
    """List inbox emails without GTD labels (for categorization in Cursor)."""
    click.echo(click.style("\n📋 Uncategorized Emails", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        # Check if GTD labels exist
        existing_labels = {label['name'] for label in get_labels()}
        gtd_exists = any(name in existing_labels for name in GTD_LABELS.keys())
        
        if not gtd_exists:
            click.echo(click.style("⚠️  GTD labels not found. Run 'python -m src.cli setup-labels' first.", fg='yellow'))
            click.echo()
        
        # Get emails without GTD labels
        emails = get_emails_without_gtd_labels(max_results=num)

        if not emails:
            click.echo("No uncategorized emails found! 🎉")
            click.echo("All inbox emails have been categorized.")
            return

        user_email = auth.get_user_email()
        prioritized = prioritize_emails(emails, user_email)

        click.echo(f"Found {len(prioritized)} uncategorized emails:\n")
        
        for i, email in enumerate(prioritized, 1):
            priority = email.get('priority_level', 'LOW')
            icon = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '⚪'}.get(priority, '⚪')
            unread = "📬 " if email.get('is_unread') else ""
            
            click.echo(f"{i}. {icon} {unread}{email.get('subject', 'No Subject')}")
            click.echo(f"   From: {email.get('from', 'Unknown')}")
            click.echo(f"   Date: {email.get('date', 'Unknown')}")
            click.echo(f"   ID: {click.style(email.get('id', ''), fg='bright_black')}")
            click.echo()

        click.echo(click.style("─" * 50, fg='bright_black'))
        click.echo("Use Cursor with MCP tools to categorize these emails.")
        click.echo("Example: 'Categorize email #1' or 'gmail_categorize_email <id>'")

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command('apply-label')
@click.argument('message_id')
@click.argument('label_name')
@click.pass_context
def apply_label_cmd(ctx, message_id: str, label_name: str):
    """Apply a GTD label to an email."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        # Validate label name
        valid_labels = list(GTD_LABELS.keys())
        
        # Allow shorthand (e.g., "Action" instead of "GTD/Action")
        if not label_name.startswith('GTD/'):
            label_name = f'GTD/{label_name}'
        
        if label_name not in valid_labels:
            click.echo(click.style(f"❌ Invalid label: {label_name}", fg='red'))
            click.echo(f"Valid labels: {', '.join(valid_labels)}")
            sys.exit(1)

        if apply_labels(message_id, [label_name]):
            click.echo(click.style(f"✅ Applied '{label_name}' to {message_id}", fg='green'))
        else:
            click.echo(click.style(f"❌ Failed to apply label", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


def main():
    """Main entry point."""
    cli(obj={})


if __name__ == '__main__':
    main()

