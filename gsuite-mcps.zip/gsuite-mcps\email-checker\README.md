# Gmail Email Assistant

A CLI tool and MCP (Model Context Protocol) server for Gmail email prioritization and management. Designed for high-volume email triage with intelligent scoring and AI assistant integration.

## Features

- **🚀 One-Command Triage** - Just type `@CHECK_EMAIL.md` in Cursor to categorize your inbox
- **📊 Smart Email Prioritization** - Scores emails based on sender importance, keywords, Jira tickets, and recency
- **🔍 Gmail Search** - Full Gmail query syntax support
- **✉️ Draft Creation** - Create reply drafts with proper threading and quoting
- **🤖 MCP Integration** - Use with AI assistants like Cursor for intelligent email management
- **⚡ CLI Interface** - Fast command-line access to all features

## Installation

### 1. Clone and Install Dependencies

```bash
cd email-checker
pip install -r requirements.txt
```

### 2. Google Cloud Setup

You'll need OAuth 2.0 credentials from Google Cloud Console. See [SETUP.md](SETUP.md) for detailed instructions.

Quick summary:
1. Create a project in [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the Gmail API
3. Configure OAuth consent screen
4. Create OAuth 2.0 credentials (Desktop app)
5. Download and save as `credentials.json` in this directory

### 3. First Authentication

```bash
python -m src.cli inbox
```

This opens a browser for Google OAuth. After authorization, your token is saved to `gdrive_token.json`.

## CLI Usage

```bash
# View inbox (prioritized)
python -m src.cli inbox [-n NUM]

# View priority breakdown
python -m src.cli priority [-n NUM]

# View unread only
python -m src.cli unread [-n NUM]

# Search emails (Gmail query syntax)
python -m src.cli search "from:boss@company.com" [-n NUM]

# List uncategorized emails for GTD triage
python -m src.cli uncategorized [-n NUM]

# Read specific email by ID
python -m src.cli read <message_id>

# Get inbox statistics
python -m src.cli summary

# Create a draft email
python -m src.cli draft --to "recipient@example.com" --subject "Hello" --body "Message body"

# Check authentication status
python -m src.cli auth_status
```

**Note:** `-n NUM` specifies the number of emails to return (default: 20-30 depending on command).

## Quick Email Check in Cursor

The fastest way to triage your inbox in Cursor:

1. Open the Cursor chat/composer
2. Type `@CHECK_EMAIL.md` and press Enter
3. The AI will automatically:
   - List your uncategorized emails
   - Read and analyze each one
   - Apply GTD labels (Urgent, Action, Reply Needed, etc.)
   - Present a summary table with clickable links

That's it! The `CHECK_EMAIL.md` file contains the workflow instructions that the AI follows to categorize your inbox using the GTD methodology.

## MCP Server Integration

### Cursor IDE Setup

Add to your MCP configuration (typically `~/.cursor/mcp.json`):

```json
{
  "mcpServers": {
    "gmail-assistant": {
      "command": "python",
      "args": ["/path/to/email-checker/mcp_server.py"],
      "env": {}
    }
  }
}
```

### Available MCP Tools

| Tool | Description |
|------|-------------|
| `gmail_inbox` | Get prioritized inbox emails |
| `gmail_search` | Search with Gmail query syntax |
| `gmail_read` | Read full email content |
| `gmail_priority_report` | Priority breakdown (HIGH/MEDIUM/LOW) |
| `gmail_summary` | Inbox statistics |
| `gmail_create_draft` | Create a draft email |

## Email Prioritization

Emails are scored based on multiple factors:

| Factor | Points |
|--------|--------|
| VIP sender (configurable) | +50 |
| Priority domain (e.g., redhat.com) | +30 |
| Jira ticket reference | +20 |
| Priority keyword in subject | +15 |
| Unread status | +10 |
| Recent (< 4 hours old) | +10 |
| Direct recipient (TO, not CC) | +5 |

**Priority Levels:**
- **HIGH**: Score ≥ 50
- **MEDIUM**: Score ≥ 25
- **LOW**: Score < 25

## Configuration

Edit `config/config.yaml` to customize:

```yaml
# VIP senders (get +50 points)
vip_senders:
  - important-person@company.com

# Keywords that trigger priority (in subject)
priority_keywords:
  - urgent
  - action required
  - deadline

# Jira projects to watch
jira_projects:
  - RHEL
  - CORE

# Domains to prioritize
priority_domains:
  - redhat.com
```

## Gmail Query Syntax

Use standard Gmail search operators:

```
from:user@example.com       # From specific sender
to:recipient@example.com    # To specific recipient
subject:keyword             # Subject contains keyword
is:unread                   # Unread only
has:attachment              # Has attachments
after:2024/01/01            # After date
before:2024/12/31           # Before date
label:important             # Has label
```

## Project Structure

```
email-checker/
├── credentials.json      # OAuth client (gitignored)
├── gdrive_token.json     # Auth token (gitignored)
├── config/
│   ├── config.yaml       # VIP senders, keywords, scoring
│   └── network.yaml      # Contact relationships for GTD categorization
├── mcp_server.py         # MCP server for AI integration
├── requirements.txt      # Python dependencies
├── SETUP.md              # Google Cloud setup guide
└── src/
    ├── auth.py           # OAuth 2.0 authentication
    ├── gmail_ops.py      # Gmail API operations
    ├── prioritizer.py    # Email scoring engine
    └── cli.py            # Command-line interface
```

## Security Notes

- **Never commit** `credentials.json` or `gdrive_token.json`
- Token files use restricted permissions (0o600)
- OAuth tokens auto-refresh before expiry
- Only `gmail.readonly` and `gmail.compose` scopes are requested

## Requirements

- Python 3.10+
- Google account with Gmail
- Google Cloud project with Gmail API enabled

## License

Private/Internal Use



