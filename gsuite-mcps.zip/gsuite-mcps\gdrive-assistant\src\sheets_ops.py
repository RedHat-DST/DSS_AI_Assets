"""
Google Sheets Operations Module.

Provides high-level functions for Google Sheets interactions:
- Create spreadsheets
- Read and write cell ranges
- Export to CSV
- Manage sheets/tabs
"""

import csv
import io
from pathlib import Path
from typing import Optional, Dict, Any, List, Union

from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload

from .auth import get_sheets_service, get_drive_service


def create_spreadsheet(
    title: str,
    sheet_names: Optional[List[str]] = None,
    folder_id: Optional[str] = None,
    sheets_service=None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a new Google Sheets spreadsheet.

    Args:
        title: Spreadsheet title
        sheet_names: Optional list of sheet/tab names (default creates one "Sheet1")
        folder_id: Optional folder ID to create spreadsheet in
        sheets_service: Optional Sheets service instance
        drive_service: Optional Drive service instance

    Returns:
        Dictionary with spreadsheet info or None on failure
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Build spreadsheet body
        body = {'properties': {'title': title}}
        
        if sheet_names:
            body['sheets'] = [
                {'properties': {'title': name}} for name in sheet_names
            ]

        spreadsheet = sheets_service.spreadsheets().create(
            body=body,
            fields='spreadsheetId,spreadsheetUrl,sheets.properties'
        ).execute()

        spreadsheet_id = spreadsheet.get('spreadsheetId')
        print(f"✅ Created spreadsheet: {title} (ID: {spreadsheet_id})")

        # Move to folder if specified
        if folder_id:
            file = drive_service.files().get(
                fileId=spreadsheet_id,
                fields='parents'
            ).execute()
            
            previous_parents = ",".join(file.get('parents', []))
            
            drive_service.files().update(
                fileId=spreadsheet_id,
                addParents=folder_id,
                removeParents=previous_parents,
                fields='id, parents'
            ).execute()
            print(f"✅ Moved to folder: {folder_id}")

        sheets_info = []
        for sheet in spreadsheet.get('sheets', []):
            props = sheet.get('properties', {})
            sheets_info.append({
                'sheet_id': props.get('sheetId'),
                'title': props.get('title'),
                'index': props.get('index')
            })

        return {
            'id': spreadsheet_id,
            'title': title,
            'url': spreadsheet.get('spreadsheetUrl'),
            'sheets': sheets_info
        }

    except HttpError as e:
        print(f"❌ Failed to create spreadsheet: {e}")
        return None


def read_range(
    spreadsheet_id: str,
    range_notation: str,
    value_render_option: str = 'FORMATTED_VALUE',
    sheets_service=None
) -> Optional[List[List[Any]]]:
    """
    Read a range of cells from a spreadsheet.

    Args:
        spreadsheet_id: Spreadsheet ID
        range_notation: A1 notation range (e.g., "Sheet1!A1:D10" or "A1:D10")
        value_render_option: How to render values ('FORMATTED_VALUE', 'UNFORMATTED_VALUE', 'FORMULA')
        sheets_service: Optional Sheets service instance

    Returns:
        2D list of cell values or None on failure
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        result = sheets_service.spreadsheets().values().get(
            spreadsheetId=spreadsheet_id,
            range=range_notation,
            valueRenderOption=value_render_option
        ).execute()

        values = result.get('values', [])
        return values

    except HttpError as e:
        print(f"❌ Failed to read range: {e}")
        return None


def write_range(
    spreadsheet_id: str,
    range_notation: str,
    values: List[List[Any]],
    value_input_option: str = 'USER_ENTERED',
    sheets_service=None
) -> bool:
    """
    Write values to a range of cells.

    Args:
        spreadsheet_id: Spreadsheet ID
        range_notation: A1 notation range (e.g., "Sheet1!A1:D10")
        values: 2D list of values to write
        value_input_option: How to interpret input ('RAW' or 'USER_ENTERED')
        sheets_service: Optional Sheets service instance

    Returns:
        True if successful, False otherwise
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        body = {'values': values}
        
        result = sheets_service.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id,
            range=range_notation,
            valueInputOption=value_input_option,
            body=body
        ).execute()

        updated = result.get('updatedCells', 0)
        print(f"✅ Updated {updated} cells")
        return True

    except HttpError as e:
        print(f"❌ Failed to write range: {e}")
        return False


def append_rows(
    spreadsheet_id: str,
    sheet_name: str,
    rows: List[List[Any]],
    value_input_option: str = 'USER_ENTERED',
    sheets_service=None
) -> bool:
    """
    Append rows to the end of a sheet.

    Args:
        spreadsheet_id: Spreadsheet ID
        sheet_name: Name of the sheet/tab to append to
        rows: List of rows (each row is a list of values)
        value_input_option: How to interpret input ('RAW' or 'USER_ENTERED')
        sheets_service: Optional Sheets service instance

    Returns:
        True if successful, False otherwise
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        body = {'values': rows}
        
        result = sheets_service.spreadsheets().values().append(
            spreadsheetId=spreadsheet_id,
            range=f"'{sheet_name}'!A:A",
            valueInputOption=value_input_option,
            insertDataOption='INSERT_ROWS',
            body=body
        ).execute()

        updates = result.get('updates', {})
        updated_rows = updates.get('updatedRows', 0)
        print(f"✅ Appended {updated_rows} rows")
        return True

    except HttpError as e:
        print(f"❌ Failed to append rows: {e}")
        return False


def create_sheet(
    spreadsheet_id: str,
    title: str,
    index: Optional[int] = None,
    sheets_service=None
) -> Optional[Dict[str, Any]]:
    """
    Add a new sheet/tab to an existing spreadsheet.

    Args:
        spreadsheet_id: Spreadsheet ID
        title: Name for the new sheet
        index: Optional position for the sheet (0-based)
        sheets_service: Optional Sheets service instance

    Returns:
        Dictionary with sheet info or None on failure
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        properties = {'title': title}
        if index is not None:
            properties['index'] = index

        request = {
            'addSheet': {
                'properties': properties
            }
        }

        result = sheets_service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={'requests': [request]}
        ).execute()

        replies = result.get('replies', [])
        if replies:
            sheet_props = replies[0].get('addSheet', {}).get('properties', {})
            print(f"✅ Created sheet: {title}")
            return {
                'sheet_id': sheet_props.get('sheetId'),
                'title': sheet_props.get('title'),
                'index': sheet_props.get('index')
            }

        return None

    except HttpError as e:
        print(f"❌ Failed to create sheet: {e}")
        return None


def delete_sheet(
    spreadsheet_id: str,
    sheet_id: int,
    sheets_service=None
) -> bool:
    """
    Delete a sheet/tab from a spreadsheet.

    Args:
        spreadsheet_id: Spreadsheet ID
        sheet_id: Sheet ID (not the name, but the numeric ID)
        sheets_service: Optional Sheets service instance

    Returns:
        True if successful, False otherwise
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        request = {
            'deleteSheet': {
                'sheetId': sheet_id
            }
        }

        sheets_service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={'requests': [request]}
        ).execute()

        print(f"✅ Deleted sheet: {sheet_id}")
        return True

    except HttpError as e:
        print(f"❌ Failed to delete sheet: {e}")
        return False


def get_spreadsheet_info(
    spreadsheet_id: str,
    sheets_service=None
) -> Optional[Dict[str, Any]]:
    """
    Get information about a spreadsheet.

    Args:
        spreadsheet_id: Spreadsheet ID
        sheets_service: Optional Sheets service instance

    Returns:
        Dictionary with spreadsheet info or None on failure
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        spreadsheet = sheets_service.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            fields='spreadsheetId,spreadsheetUrl,properties,sheets.properties'
        ).execute()

        sheets_info = []
        for sheet in spreadsheet.get('sheets', []):
            props = sheet.get('properties', {})
            grid_props = props.get('gridProperties', {})
            sheets_info.append({
                'sheet_id': props.get('sheetId'),
                'title': props.get('title'),
                'index': props.get('index'),
                'row_count': grid_props.get('rowCount'),
                'column_count': grid_props.get('columnCount'),
                'frozen_rows': grid_props.get('frozenRowCount', 0),
                'frozen_cols': grid_props.get('frozenColumnCount', 0)
            })

        return {
            'id': spreadsheet_id,
            'title': spreadsheet.get('properties', {}).get('title'),
            'url': spreadsheet.get('spreadsheetUrl'),
            'sheets': sheets_info
        }

    except HttpError as e:
        print(f"❌ Failed to get spreadsheet info: {e}")
        return None


def export_csv(
    spreadsheet_id: str,
    sheet_name: str,
    local_path: str,
    sheets_service=None
) -> Optional[str]:
    """
    Export a sheet to CSV file.

    Args:
        spreadsheet_id: Spreadsheet ID
        sheet_name: Name of the sheet to export
        local_path: Local path to save CSV file
        sheets_service: Optional Sheets service instance

    Returns:
        Path to exported file or None on failure
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        # Read all data from the sheet
        result = sheets_service.spreadsheets().values().get(
            spreadsheetId=spreadsheet_id,
            range=f"'{sheet_name}'",
            valueRenderOption='FORMATTED_VALUE'
        ).execute()

        values = result.get('values', [])

        if not values:
            print(f"⚠️ Sheet '{sheet_name}' is empty")
            return None

        # Write to CSV
        local_path = Path(local_path)
        if not local_path.suffix:
            local_path = local_path.with_suffix('.csv')
        local_path.parent.mkdir(parents=True, exist_ok=True)

        with open(local_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerows(values)

        print(f"✅ Exported to: {local_path}")
        return str(local_path)

    except HttpError as e:
        print(f"❌ Failed to export CSV: {e}")
        return None


def import_csv(
    spreadsheet_id: str,
    sheet_name: str,
    csv_path: str,
    start_cell: str = 'A1',
    sheets_service=None
) -> bool:
    """
    Import data from a CSV file to a sheet.

    Args:
        spreadsheet_id: Spreadsheet ID
        sheet_name: Name of the sheet to import to
        csv_path: Path to CSV file
        start_cell: Starting cell for import (e.g., 'A1')
        sheets_service: Optional Sheets service instance

    Returns:
        True if successful, False otherwise
    """
    csv_path = Path(csv_path)
    if not csv_path.exists():
        print(f"❌ File not found: {csv_path}")
        return False

    try:
        # Read CSV file
        with open(csv_path, 'r', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            rows = list(reader)

        if not rows:
            print(f"⚠️ CSV file is empty")
            return False

        # Write to sheet
        range_notation = f"'{sheet_name}'!{start_cell}"
        return write_range(spreadsheet_id, range_notation, rows, sheets_service=sheets_service)

    except Exception as e:
        print(f"❌ Failed to import CSV: {e}")
        return False


def clear_range(
    spreadsheet_id: str,
    range_notation: str,
    sheets_service=None
) -> bool:
    """
    Clear values from a range (keeps formatting).

    Args:
        spreadsheet_id: Spreadsheet ID
        range_notation: A1 notation range to clear
        sheets_service: Optional Sheets service instance

    Returns:
        True if successful, False otherwise
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        sheets_service.spreadsheets().values().clear(
            spreadsheetId=spreadsheet_id,
            range=range_notation
        ).execute()

        print(f"✅ Cleared range: {range_notation}")
        return True

    except HttpError as e:
        print(f"❌ Failed to clear range: {e}")
        return False


def batch_read(
    spreadsheet_id: str,
    ranges: List[str],
    value_render_option: str = 'FORMATTED_VALUE',
    sheets_service=None
) -> Optional[Dict[str, List[List[Any]]]]:
    """
    Read multiple ranges in a single request.

    Args:
        spreadsheet_id: Spreadsheet ID
        ranges: List of A1 notation ranges
        value_render_option: How to render values
        sheets_service: Optional Sheets service instance

    Returns:
        Dictionary mapping range names to values, or None on failure
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        result = sheets_service.spreadsheets().values().batchGet(
            spreadsheetId=spreadsheet_id,
            ranges=ranges,
            valueRenderOption=value_render_option
        ).execute()

        value_ranges = result.get('valueRanges', [])
        return {
            vr.get('range'): vr.get('values', [])
            for vr in value_ranges
        }

    except HttpError as e:
        print(f"❌ Failed to batch read: {e}")
        return None


def batch_write(
    spreadsheet_id: str,
    data: Dict[str, List[List[Any]]],
    value_input_option: str = 'USER_ENTERED',
    sheets_service=None
) -> bool:
    """
    Write to multiple ranges in a single request.

    Args:
        spreadsheet_id: Spreadsheet ID
        data: Dictionary mapping range names to values
        value_input_option: How to interpret input
        sheets_service: Optional Sheets service instance

    Returns:
        True if successful, False otherwise
    """
    if sheets_service is None:
        sheets_service = get_sheets_service()

    try:
        value_ranges = [
            {'range': range_name, 'values': values}
            for range_name, values in data.items()
        ]

        body = {
            'valueInputOption': value_input_option,
            'data': value_ranges
        }

        result = sheets_service.spreadsheets().values().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body=body
        ).execute()

        updated = result.get('totalUpdatedCells', 0)
        print(f"✅ Updated {updated} cells across {len(data)} ranges")
        return True

    except HttpError as e:
        print(f"❌ Failed to batch write: {e}")
        return False

