"""
Google Docs Operations Module.

Provides high-level functions for Google Docs interactions:
- Create documents from markdown
- Read document content
- Export to various formats
- Append and insert content
"""

import io
import re
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from urllib.parse import urlparse, parse_qs

from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload

from .auth import get_docs_service, get_drive_service
from .converters import markdown_to_docs_requests, docs_to_markdown, plain_text_to_requests


def parse_gdocs_url(url_or_id: str) -> Dict[str, Optional[str]]:
    """
    Extract doc_id and optional tab_id from Google Docs URL or plain ID.
    
    Args:
        url_or_id: Google Docs URL or document ID
    
    Examples:
        https://docs.google.com/document/d/ABC123/edit
        → {'doc_id': 'ABC123', 'tab_id': None}
        
        https://docs.google.com/document/d/ABC123/edit?tab=t.xyz789
        → {'doc_id': 'ABC123', 'tab_id': 't.xyz789'}
        
        https://docs.google.com/document/d/ABC123/edit#heading=h.xyz789
        → {'doc_id': 'ABC123', 'tab_id': 'h.xyz789'}
        
        ABC123
        → {'doc_id': 'ABC123', 'tab_id': None}
    
    Returns:
        Dictionary with 'doc_id' and 'tab_id' (or None)
    """
    # If it doesn't look like a URL, treat it as a plain doc_id
    if not url_or_id.startswith('http'):
        return {'doc_id': url_or_id, 'tab_id': None}
    
    try:
        parsed = urlparse(url_or_id)
        
        # Extract doc_id from path
        # Path format: /document/d/{DOC_ID}/edit or /document/d/{DOC_ID}
        path_match = re.search(r'/document/d/([a-zA-Z0-9_-]+)', parsed.path)
        if not path_match:
            # Invalid URL format, return as-is assuming it's a doc_id
            return {'doc_id': url_or_id, 'tab_id': None}
        
        doc_id = path_match.group(1)
        
        # Extract tab_id from query parameters or fragment
        tab_id = None
        
        # First check query parameters for ?tab=TAB_ID
        if parsed.query:
            query_params = parse_qs(parsed.query)
            if 'tab' in query_params:
                tab_id = query_params['tab'][0]
        
        # If no tab in query, check fragment
        # Fragment format: #heading=h.TAB_ID or just h.TAB_ID
        if not tab_id and parsed.fragment:
            # Look for heading=h.TAB_ID pattern
            heading_match = re.search(r'heading=h\.([a-zA-Z0-9_-]+)', parsed.fragment)
            if heading_match:
                # The tab_id in the API includes the "h." prefix
                tab_id = f"h.{heading_match.group(1)}"
            # Also check for bookmark= pattern (alternative format)
            elif 'bookmark=' in parsed.fragment:
                bookmark_match = re.search(r'bookmark=([a-zA-Z0-9_-]+)', parsed.fragment)
                if bookmark_match:
                    tab_id = bookmark_match.group(1)
        
        return {'doc_id': doc_id, 'tab_id': tab_id}
    
    except Exception as e:
        # If parsing fails, treat the whole thing as a doc_id
        return {'doc_id': url_or_id, 'tab_id': None}


def create_doc(
    title: str,
    content: Optional[str] = None,
    content_type: str = 'markdown',
    folder_id: Optional[str] = None,
    docs_service=None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a new Google Doc.

    Args:
        title: Document title
        content: Initial content (markdown or plain text)
        content_type: Content format ('markdown' or 'plain')
        folder_id: Optional folder ID to create document in
        docs_service: Optional Docs service instance
        drive_service: Optional Drive service instance

    Returns:
        Dictionary with document info (id, title, url) or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Create empty document
        doc = docs_service.documents().create(
            body={'title': title}
        ).execute()

        doc_id = doc.get('documentId')
        print(f"✅ Created document: {title} (ID: {doc_id})")

        # Add content if provided
        if content:
            if content_type == 'markdown':
                requests = markdown_to_docs_requests(content)
            else:
                requests = plain_text_to_requests(content)

            if requests:
                docs_service.documents().batchUpdate(
                    documentId=doc_id,
                    body={'requests': requests}
                ).execute()
                print(f"✅ Added content to document")

        # Move to folder if specified
        if folder_id:
            # Get current parent
            file = drive_service.files().get(
                fileId=doc_id,
                fields='parents'
            ).execute()
            
            previous_parents = ",".join(file.get('parents', []))
            
            # Move to new folder
            drive_service.files().update(
                fileId=doc_id,
                addParents=folder_id,
                removeParents=previous_parents,
                fields='id, parents'
            ).execute()
            print(f"✅ Moved to folder: {folder_id}")

        return {
            'id': doc_id,
            'title': title,
            'url': f"https://docs.google.com/document/d/{doc_id}/edit"
        }

    except HttpError as e:
        print(f"❌ Failed to create document: {e}")
        return None


def read_doc(
    doc_id: str,
    docs_service=None
) -> Optional[Dict[str, Any]]:
    """
    Read a Google Doc's content.

    Args:
        doc_id: Document ID
        docs_service: Optional Docs service instance

    Returns:
        Dictionary with document info and plain text content, or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()

    try:
        # Request with tabs content included (for backward compatibility with new API)
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()

        # Extract plain text content - handle both old and new structure
        text_parts = []
        
        # Check if document uses new tab structure
        tabs = doc.get('tabs', [])
        if tabs:
            # New structure: content is in tabs
            for tab in tabs:
                if 'documentTab' in tab:
                    content = tab['documentTab'].get('body', {}).get('content', [])
                    for element in content:
                        if 'paragraph' in element:
                            para = element['paragraph']
                            for elem in para.get('elements', []):
                                if 'textRun' in elem:
                                    text_parts.append(elem['textRun'].get('content', ''))
        else:
            # Old structure: content is directly in body
            content = doc.get('body', {}).get('content', [])
            for element in content:
                if 'paragraph' in element:
                    para = element['paragraph']
                    for elem in para.get('elements', []):
                        if 'textRun' in elem:
                            text_parts.append(elem['textRun'].get('content', ''))

        return {
            'id': doc_id,
            'title': doc.get('title', 'Untitled'),
            'url': f"https://docs.google.com/document/d/{doc_id}/edit",
            'text': ''.join(text_parts),
            'raw': doc  # Full document structure
        }

    except HttpError as e:
        print(f"❌ Failed to read document: {e}")
        return None


def read_doc_as_markdown(
    doc_id: str,
    docs_service=None
) -> Optional[str]:
    """
    Read a Google Doc and convert to Markdown.

    Args:
        doc_id: Document ID
        docs_service: Optional Docs service instance

    Returns:
        Markdown formatted string or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()

    try:
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()
        return docs_to_markdown(doc)

    except HttpError as e:
        print(f"❌ Failed to read document: {e}")
        return None


def export_doc(
    doc_id: str,
    local_path: str,
    format: str = 'pdf',
    drive_service=None
) -> Optional[str]:
    """
    Export a Google Doc to a local file.

    Args:
        doc_id: Document ID
        local_path: Local path to save file
        format: Export format ('pdf', 'docx', 'txt', 'html', 'md')
        drive_service: Optional Drive service instance

    Returns:
        Path to exported file or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    # Map formats to MIME types
    mime_types = {
        'pdf': 'application/pdf',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'txt': 'text/plain',
        'html': 'text/html',
    }

    # Handle markdown specially
    if format == 'md':
        try:
            markdown = read_doc_as_markdown(doc_id)
            if markdown:
                local_path = Path(local_path)
                if not local_path.suffix:
                    local_path = local_path.with_suffix('.md')
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_text(markdown)
                print(f"✅ Exported to: {local_path}")
                return str(local_path)
            return None
        except Exception as e:
            print(f"❌ Failed to export as markdown: {e}")
            return None

    mime_type = mime_types.get(format)
    if not mime_type:
        print(f"❌ Unsupported export format: {format}")
        print(f"   Supported formats: {', '.join(mime_types.keys())}, md")
        return None

    try:
        request = drive_service.files().export_media(
            fileId=doc_id,
            mimeType=mime_type
        )

        local_path = Path(local_path)
        if not local_path.suffix:
            local_path = local_path.with_suffix(f'.{format}')
        local_path.parent.mkdir(parents=True, exist_ok=True)

        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        
        done = False
        while not done:
            status, done = downloader.next_chunk()

        with open(local_path, 'wb') as f:
            f.write(fh.getvalue())

        print(f"✅ Exported to: {local_path}")
        return str(local_path)

    except HttpError as e:
        print(f"❌ Export failed: {e}")
        return None


def append_to_doc(
    doc_id: str,
    content: str,
    content_type: str = 'markdown',
    tab_id: Optional[str] = None,
    docs_service=None
) -> bool:
    """
    Append content to the end of a Google Doc or specific tab.

    Args:
        doc_id: Document ID
        content: Content to append (markdown or plain text)
        content_type: Content format ('markdown' or 'plain')
        tab_id: Optional tab ID to append to specific tab (e.g., 't.xyz123').
                If omitted, appends to first tab or document body for legacy docs.
        docs_service: Optional Docs service instance

    Returns:
        True if successful, False otherwise

    Note:
        When appending to a specific tab, paragraph styles (headings, code blocks,
        blockquotes, etc.) are applied. If the API errors on certain styles in tabs,
        a fallback to heading-only styles may be used. Text content and text
        formatting (bold, italic, links, lists) work correctly.

        Content is automatically chunked if it exceeds ~500KB to avoid API limits.
        Unicode characters including emojis may cause issues with markdown formatting
        due to index calculation differences between Python and Google Docs API.
    """
    if docs_service is None:
        docs_service = get_docs_service()

    # Check content size and chunk if necessary
    # Google Docs API has limits. For markdown, the conversion creates many requests
    # (insertText, updateTextStyle, createParagraphBullets), so we need smaller chunks.
    # Conservative limit: 50KB for markdown, 200KB for plain text
    MAX_CHUNK_SIZE = 50 * 1024 if content_type == 'markdown' else 200 * 1024

    if len(content.encode('utf-8')) > MAX_CHUNK_SIZE:
        print(f"⚠️  Content size ({len(content.encode('utf-8')):,} bytes) exceeds limit. Chunking...")
        return _append_to_doc_chunked(doc_id, content, content_type, tab_id, docs_service)

    return _append_to_doc_single(doc_id, content, content_type, tab_id, docs_service)


def _append_to_doc_chunked(
    doc_id: str,
    content: str,
    content_type: str,
    tab_id: Optional[str],
    docs_service
) -> bool:
    """Append large content in chunks to avoid API limits."""
    # Use conservative chunk sizes
    MAX_CHUNK_SIZE = 50 * 1024 if content_type == 'markdown' else 200 * 1024

    # For plain text, chunk by bytes
    if content_type == 'plain':
        chunks = []
        current_chunk = ""

        for line in content.split('\n'):
            test_chunk = current_chunk + line + '\n'
            if len(test_chunk.encode('utf-8')) > MAX_CHUNK_SIZE and current_chunk:
                chunks.append(current_chunk)
                current_chunk = line + '\n'
            else:
                current_chunk = test_chunk

        if current_chunk:
            chunks.append(current_chunk)

    # For markdown, chunk by paragraphs to preserve formatting
    else:
        chunks = []
        current_chunk = ""
        paragraphs = content.split('\n\n')

        for para in paragraphs:
            test_chunk = current_chunk + para + '\n\n'
            if len(test_chunk.encode('utf-8')) > MAX_CHUNK_SIZE and current_chunk:
                chunks.append(current_chunk)
                current_chunk = para + '\n\n'
            else:
                current_chunk = test_chunk

        if current_chunk:
            chunks.append(current_chunk)

    print(f"📦 Splitting content into {len(chunks)} chunks")

    # Append each chunk
    # Note: Each chunk append modifies the document, so the function will
    # automatically fetch fresh document state for each chunk
    for i, chunk in enumerate(chunks, 1):
        chunk_size = len(chunk.encode('utf-8'))
        print(f"   Appending chunk {i}/{len(chunks)} ({chunk_size:,} bytes)...")

        # Each call to _append_to_doc_single fetches the document fresh,
        # ensuring we always have the correct end index
        if not _append_to_doc_single(doc_id, chunk, content_type, tab_id, docs_service):
            print(f"❌ Failed to append chunk {i}/{len(chunks)}")
            return False

        # Small delay between chunks to avoid rate limiting
        if i < len(chunks):
            import time
            time.sleep(0.5)

    print(f"✅ Successfully appended all {len(chunks)} chunks")
    return True


def _append_to_doc_single(
    doc_id: str,
    content: str,
    content_type: str,
    tab_id: Optional[str],
    docs_service
) -> bool:
    """Append content in a single operation (internal helper)."""
    try:
        # Get document with tabs content
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()

        # Find the target body and end index
        target_tab_id = None
        if tab_id:
            # Find the specific tab
            target_tab = None
            for tab in doc.get('tabs', []):
                if tab.get('tabProperties', {}).get('tabId') == tab_id:
                    target_tab = tab
                    break

            if not target_tab:
                print(f"❌ Tab not found: {tab_id}")
                # List available tabs to help user
                available_tabs = []
                for tab in doc.get('tabs', []):
                    tid = tab.get('tabProperties', {}).get('tabId')
                    title = tab.get('tabProperties', {}).get('title', 'Untitled')
                    available_tabs.append(f"{tid} ({title})")
                print(f"   Available tabs: {', '.join(available_tabs)}")
                return False

            # Get end index from the tab's body
            body_content = target_tab.get('documentTab', {}).get('body', {}).get('content', [])
            target_tab_id = tab_id
        else:
            # Use first tab or document body (legacy)
            if 'tabs' in doc and len(doc['tabs']) > 0:
                body_content = doc['tabs'][0].get('documentTab', {}).get('body', {}).get('content', [])
                target_tab_id = doc['tabs'][0].get('tabProperties', {}).get('tabId')
            else:
                body_content = doc.get('body', {}).get('content', [])

        # Find end index
        if body_content:
            last_element = body_content[-1]
            end_index = last_element.get('endIndex', 1) - 1
        else:
            end_index = 1

        # Build requests - need to adjust indices for appending
        if content_type == 'markdown':
            # No leading newline (avoids extra blank line at top when appending to a tab).
            # Converter indices start at 1; first char must go at end_index, so offset = end_index - 1.
            append_offset = end_index - 1
            requests = []
            md_requests = markdown_to_docs_requests(content)
            for req in md_requests:
                if 'insertText' in req:
                    req['insertText']['location']['index'] += append_offset
                elif 'updateTextStyle' in req:
                    req['updateTextStyle']['range']['startIndex'] += append_offset
                    req['updateTextStyle']['range']['endIndex'] += append_offset
                elif 'updateParagraphStyle' in req:
                    req['updateParagraphStyle']['range']['startIndex'] += append_offset
                    req['updateParagraphStyle']['range']['endIndex'] += append_offset
                elif 'createParagraphBullets' in req:
                    req['createParagraphBullets']['range']['startIndex'] += append_offset
                    req['createParagraphBullets']['range']['endIndex'] += append_offset

            requests.extend(md_requests)
        else:
            requests = [{
                'insertText': {
                    'location': {'index': end_index},
                    'text': '\n' + content
                }
            }]

        # Add tabId to requests when targeting specific tab (all paragraph styles included).
        if target_tab_id:
            filtered_requests = []
            for request in requests:
                request_type = list(request.keys())[0]
                request_body = request[request_type]

                if request_type == 'updateParagraphStyle' and 'range' in request_body:
                    request_body['range']['tabId'] = target_tab_id
                    filtered_requests.append(request)
                    continue

                if request_type == 'insertText' and 'location' in request_body:
                    request_body['location']['tabId'] = target_tab_id

                elif request_type == 'updateTextStyle' and 'range' in request_body:
                    request_body['range']['tabId'] = target_tab_id

                elif request_type == 'createParagraphBullets' and 'range' in request_body:
                    request_body['range']['tabId'] = target_tab_id

                filtered_requests.append(request)

            requests = filtered_requests

        # Execute the batch update
        docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={'requests': requests}
        ).execute()

        if target_tab_id:
            print(f"✅ Appended content to tab {target_tab_id}")
        else:
            print(f"✅ Appended content to document")
        return True

    except HttpError as e:
        print(f"❌ Failed to append content: {e}")
        return False


def insert_text(
    doc_id: str,
    text: str,
    index: int = 1,
    docs_service=None
) -> bool:
    """
    Insert plain text at a specific position in a document.

    Args:
        doc_id: Document ID
        text: Text to insert
        index: Position to insert at (1-based, 1 is start of document)
        docs_service: Optional Docs service instance

    Returns:
        True if successful, False otherwise
    """
    if docs_service is None:
        docs_service = get_docs_service()

    try:
        requests = [{
            'insertText': {
                'location': {'index': index},
                'text': text
            }
        }]

        docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={'requests': requests}
        ).execute()

        print(f"✅ Inserted text at position {index}")
        return True

    except HttpError as e:
        print(f"❌ Failed to insert text: {e}")
        return False


def replace_text(
    doc_id: str,
    find: str,
    replace: str,
    match_case: bool = True,
    docs_service=None
) -> int:
    """
    Find and replace text in a document.

    Args:
        doc_id: Document ID
        find: Text to find
        replace: Replacement text
        match_case: Whether to match case
        docs_service: Optional Docs service instance

    Returns:
        Number of replacements made, or -1 on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()

    try:
        requests = [{
            'replaceAllText': {
                'containsText': {
                    'text': find,
                    'matchCase': match_case
                },
                'replaceText': replace
            }
        }]

        result = docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={'requests': requests}
        ).execute()

        # Get replacement count from response
        replies = result.get('replies', [])
        if replies:
            count = replies[0].get('replaceAllText', {}).get('occurrencesChanged', 0)
            print(f"✅ Replaced {count} occurrences")
            return count
        
        return 0

    except HttpError as e:
        print(f"❌ Failed to replace text: {e}")
        return -1


def get_doc_info(
    doc_id: str,
    docs_service=None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Get detailed information about a Google Doc.

    Args:
        doc_id: Document ID
        docs_service: Optional Docs service instance
        drive_service: Optional Drive service instance

    Returns:
        Dictionary with document info or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Get Docs metadata
        doc = docs_service.documents().get(documentId=doc_id).execute()
        
        # Get Drive metadata for more info
        file = drive_service.files().get(
            fileId=doc_id,
            fields='id, name, createdTime, modifiedTime, owners, shared, webViewLink'
        ).execute()

        return {
            'id': doc_id,
            'title': doc.get('title', 'Untitled'),
            'url': f"https://docs.google.com/document/d/{doc_id}/edit",
            'created_time': file.get('createdTime'),
            'modified_time': file.get('modifiedTime'),
            'owners': [o.get('emailAddress') for o in file.get('owners', [])],
            'shared': file.get('shared', False),
            'revision_id': doc.get('revisionId'),
        }

    except HttpError as e:
        print(f"❌ Failed to get document info: {e}")
        return None


def create_doc_from_file(
    file_path: str,
    title: Optional[str] = None,
    folder_id: Optional[str] = None,
    docs_service=None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a Google Doc from a local markdown file.

    Args:
        file_path: Path to local markdown file
        title: Document title (defaults to filename)
        folder_id: Optional folder ID to create document in
        docs_service: Optional Docs service instance
        drive_service: Optional Drive service instance

    Returns:
        Dictionary with document info or None on failure
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        print(f"❌ File not found: {file_path}")
        return None
    
    # Read file content
    content = file_path.read_text()
    
    # Determine title
    if title is None:
        title = file_path.stem
    
    # Determine content type based on extension
    content_type = 'markdown' if file_path.suffix.lower() in ['.md', '.markdown'] else 'plain'
    
    return create_doc(
        title=title,
        content=content,
        content_type=content_type,
        folder_id=folder_id,
        docs_service=docs_service,
        drive_service=drive_service
    )


# =============================================================================
# Tab Operations (Google Docs Tabs API - Added July 2024)
# =============================================================================

def list_tabs(
    doc_id_or_url: str,
    include_children: bool = True,
    docs_service=None
) -> Optional[List[Dict[str, Any]]]:
    """
    List all tabs in a Google Doc.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL
        include_children: Whether to include nested child tabs
        docs_service: Optional Docs service instance

    Returns:
        List of tab dictionaries with id, title, index, parent info, or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()

    # Parse URL to extract doc_id
    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']

    try:
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()

        tabs = doc.get('tabs', [])
        
        if not tabs:
            # Document doesn't use tabs, treat as single implicit tab
            return [{
                'tab_id': None,
                'title': doc.get('title', 'Untitled'),
                'index': 0,
                'parent_tab_id': None,
                'is_document_tab': True,
                'level': 0
            }]

        tab_list = []

        def process_tab(tab, index, parent_id=None, level=0):
            """Recursively process tabs and their children."""
            tab_id = tab.get('tabProperties', {}).get('tabId')
            title = tab.get('tabProperties', {}).get('title', f'Tab {index + 1}')

            tab_info = {
                'tab_id': tab_id,
                'title': title,
                'index': index,
                'parent_tab_id': parent_id,
                'is_document_tab': 'documentTab' in tab,
                'level': level
            }

            tab_list.append(tab_info)

            # Process child tabs if requested
            if include_children:
                child_tabs = tab.get('childTabs', [])
                for child_index, child_tab in enumerate(child_tabs):
                    process_tab(child_tab, child_index, tab_id, level + 1)
        
        # Process all top-level tabs
        for idx, tab in enumerate(tabs):
            process_tab(tab, idx)

        print(f"✅ Found {len(tab_list)} tab(s) in document")
        return tab_list

    except HttpError as e:
        print(f"❌ Failed to list tabs: {e}")
        return None


def create_tab(
    doc_id_or_url: str,
    title: str,
    index: Optional[int] = None,
    parent_tab_id: Optional[str] = None,
    icon_emoji: Optional[str] = None,
    docs_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a new tab in a Google Doc.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL
        title: Tab title (user-visible name)
        index: Optional 0-based index within parent (inserts at position; subsequent tabs shift)
        parent_tab_id: Optional parent tab ID for creating a child tab
        icon_emoji: Optional single emoji for tab icon
        docs_service: Optional Docs service instance

    Returns:
        Dict with doc_id, tab_id (from list_tabs after create), url; or None on failure.
        The API does not return the new tabId in batchUpdate; we refetch via list_tabs.
    """
    if docs_service is None:
        docs_service = get_docs_service()

    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']

    tab_properties = {'title': title}
    if index is not None:
        tab_properties['index'] = index
    if parent_tab_id:
        tab_properties['parentTabId'] = parent_tab_id
    if icon_emoji:
        tab_properties['iconEmoji'] = icon_emoji

    try:
        docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={'requests': [{'addDocumentTab': {'tabProperties': tab_properties}}]}
        ).execute()
        print(f"✅ Created tab: {title}")

        # Refetch document to get new tab IDs (API does not return them in batchUpdate)
        tabs = list_tabs(doc_id, include_children=True, docs_service=docs_service)
        if not tabs:
            return {'doc_id': doc_id, 'url': f"https://docs.google.com/document/d/{doc_id}/edit"}

        # Match by title and optional index/parent to find the new tab
        new_tab_id = None
        for t in tabs:
            if t.get('title') == title:
                new_tab_id = t.get('tab_id')
                break
        return {
            'doc_id': doc_id,
            'tab_id': new_tab_id,
            'url': f"https://docs.google.com/document/d/{doc_id}/edit"
        }
    except HttpError as e:
        print(f"❌ Failed to create tab: {e}")
        return None


def update_tab(
    doc_id_or_url: str,
    tab_id: str,
    title: Optional[str] = None,
    icon_emoji: Optional[str] = None,
    docs_service=None
) -> Optional[Dict[str, Any]]:
    """
    Update properties of a tab in a Google Doc.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL
        tab_id: Tab ID to update
        title: New title (optional)
        icon_emoji: New icon emoji (optional)
        docs_service: Optional Docs service instance

    Returns:
        Dict with doc_id, tab_id on success; None on failure.
    """
    if docs_service is None:
        docs_service = get_docs_service()

    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']

    if not title and icon_emoji is None:
        print("❌ At least one of title or icon_emoji must be provided")
        return None

    tab_properties = {'tabId': tab_id}
    fields = []
    if title is not None:
        tab_properties['title'] = title
        fields.append('title')
    if icon_emoji is not None:
        tab_properties['iconEmoji'] = icon_emoji
        fields.append('iconEmoji')

    try:
        docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={
                'requests': [{
                    'updateDocumentTabProperties': {
                        'tabProperties': tab_properties,
                        'fields': ','.join(fields)
                    }
                }]
            }
        ).execute()
        print(f"✅ Updated tab: {tab_id}")
        return {'doc_id': doc_id, 'tab_id': tab_id}
    except HttpError as e:
        print(f"❌ Failed to update tab: {e}")
        return None


def delete_tab(
    doc_id_or_url: str,
    tab_id: str,
    docs_service=None
) -> Optional[Dict[str, Any]]:
    """
    Delete a tab from a Google Doc. Child tabs are deleted as well.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL
        tab_id: Tab ID to delete
        docs_service: Optional Docs service instance

    Returns:
        Dict with doc_id on success; None on failure.
    """
    if docs_service is None:
        docs_service = get_docs_service()

    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']

    try:
        docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={'requests': [{'deleteTab': {'tabId': tab_id}}]}
        ).execute()
        print(f"✅ Deleted tab: {tab_id}")
        return {'doc_id': doc_id}
    except HttpError as e:
        print(f"❌ Failed to delete tab: {e}")
        return None


def read_tab(
    doc_id_or_url: str,
    tab_id: Optional[str] = None,
    tab_index: int = 0,
    docs_service=None
) -> Optional[Dict[str, Any]]:
    """
    Read content from a specific tab in a Google Doc.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL (can include tab fragment)
        tab_id: Tab ID (takes precedence over URL fragment and tab_index if provided)
        tab_index: Tab index (0-based, defaults to first tab)
        docs_service: Optional Docs service instance

    Returns:
        Dictionary with tab info and plain text content, or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()

    # Parse URL to extract doc_id and tab_id
    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']
    
    # Use tab_id from URL if not explicitly provided
    if tab_id is None and parsed['tab_id'] is not None:
        tab_id = parsed['tab_id']

    try:
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()

        tabs = doc.get('tabs', [])
        
        if not tabs:
            # No tabs structure - read entire document
            content = doc.get('body', {}).get('content', [])
            text_parts = []
            for element in content:
                if 'paragraph' in element:
                    para = element['paragraph']
                    for elem in para.get('elements', []):
                        if 'textRun' in elem:
                            text_parts.append(elem['textRun'].get('content', ''))
            
            return {
                'id': doc_id,
                'title': doc.get('title', 'Untitled'),
                'tab_id': None,
                'tab_title': doc.get('title', 'Untitled'),
                'tab_index': 0,
                'url': f"https://docs.google.com/document/d/{doc_id}/edit",
                'text': ''.join(text_parts),
                'raw': doc
            }

        # Find the target tab
        target_tab = None
        target_index = 0
        
        if tab_id:
            # Search by tab ID
            for idx, tab in enumerate(tabs):
                if tab.get('tabProperties', {}).get('tabId') == tab_id:
                    target_tab = tab
                    target_index = idx
                    break
        else:
            # Use tab index
            if 0 <= tab_index < len(tabs):
                target_tab = tabs[tab_index]
                target_index = tab_index

        if not target_tab:
            print(f"❌ Tab not found: tab_id={tab_id}, tab_index={tab_index}")
            return None

        # Extract content from the tab
        text_parts = []
        tab_content = target_tab.get('documentTab', {}).get('body', {}).get('content', [])
        
        for element in tab_content:
            if 'paragraph' in element:
                para = element['paragraph']
                for elem in para.get('elements', []):
                    if 'textRun' in elem:
                        text_parts.append(elem['textRun'].get('content', ''))

        tab_title = target_tab.get('tabProperties', {}).get('title', f'Tab {target_index + 1}')
        tab_id_actual = target_tab.get('tabProperties', {}).get('tabId')

        return {
            'id': doc_id,
            'title': doc.get('title', 'Untitled'),
            'tab_id': tab_id_actual,
            'tab_title': tab_title,
            'tab_index': target_index,
            'url': f"https://docs.google.com/document/d/{doc_id}/edit",
            'text': ''.join(text_parts),
            'raw': target_tab
        }

    except HttpError as e:
        print(f"❌ Failed to read tab: {e}")
        return None


def read_tab_as_markdown(
    doc_id_or_url: str,
    tab_id: Optional[str] = None,
    tab_index: int = 0,
    docs_service=None
) -> Optional[str]:
    """
    Read a specific tab from a Google Doc and convert to Markdown.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL (can include tab fragment)
        tab_id: Tab ID (takes precedence over URL fragment and tab_index if provided)
        tab_index: Tab index (0-based, defaults to first tab)
        docs_service: Optional Docs service instance

    Returns:
        Markdown formatted string or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()

    # Parse URL to extract doc_id and tab_id
    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']
    
    # Use tab_id from URL if not explicitly provided
    if tab_id is None and parsed['tab_id'] is not None:
        tab_id = parsed['tab_id']

    try:
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()

        tabs = doc.get('tabs', [])
        
        if not tabs:
            # No tabs structure - convert entire document
            return docs_to_markdown(doc)

        # Find the target tab
        target_tab = None
        
        if tab_id:
            # Search by tab ID
            for tab in tabs:
                if tab.get('tabProperties', {}).get('tabId') == tab_id:
                    target_tab = tab
                    break
        else:
            # Use tab index
            if 0 <= tab_index < len(tabs):
                target_tab = tabs[tab_index]

        if not target_tab:
            print(f"❌ Tab not found: tab_id={tab_id}, tab_index={tab_index}")
            return None

        # Create a temporary document structure with just this tab's content
        # to pass to the markdown converter
        temp_doc = {
            'title': doc.get('title', 'Untitled'),
            'body': target_tab.get('documentTab', {}).get('body', {}),
            'lists': doc.get('lists', {})  # Include list definitions
        }

        return docs_to_markdown(temp_doc)

    except HttpError as e:
        print(f"❌ Failed to read tab as markdown: {e}")
        return None


def export_tab(
    doc_id_or_url: str,
    tab_id: Optional[str] = None,
    local_path: str = None,
    format: str = 'pdf',
    docs_service=None,
    drive_service=None
) -> Optional[str]:
    """
    Export a specific tab from a Google Doc to a local file.
    
    Note: Google Docs API doesn't support exporting individual tabs directly.
    This function extracts the tab content and creates it as a temporary document
    for export, then deletes the temporary document.

    Args:
        doc_id_or_url: Document ID or full Google Docs URL (can include tab fragment)
        tab_id: Tab ID to export (if None, extracted from URL or uses first tab)
        local_path: Local path to save file
        format: Export format ('pdf', 'docx', 'txt', 'html', 'md')
        docs_service: Optional Docs service instance
        drive_service: Optional Drive service instance

    Returns:
        Path to exported file or None on failure
    """
    if docs_service is None:
        docs_service = get_docs_service()
    if drive_service is None:
        drive_service = get_drive_service()

    # Parse URL to extract doc_id and tab_id
    parsed = parse_gdocs_url(doc_id_or_url)
    doc_id = parsed['doc_id']
    
    # Use tab_id from URL if not explicitly provided
    if tab_id is None and parsed['tab_id'] is not None:
        tab_id = parsed['tab_id']
    
    if tab_id is None:
        print("❌ tab_id is required for export_tab. Use export_doc for full document export.")
        return None

    try:
        # Read the tab content
        tab_result = read_tab(doc_id, tab_id=tab_id, docs_service=docs_service)
        if not tab_result:
            return None

        # For markdown export, we can do it directly
        if format == 'md':
            markdown = read_tab_as_markdown(doc_id, tab_id=tab_id, docs_service=docs_service)
            if markdown:
                local_path = Path(local_path)
                if not local_path.suffix:
                    local_path = local_path.with_suffix('.md')
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_text(markdown)
                print(f"✅ Exported tab to: {local_path}")
                return str(local_path)
            return None

        # For other formats, we need to create a temporary document
        # Get the full document with tabs content
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()

        tabs = doc.get('tabs', [])
        target_tab = None
        
        for tab in tabs:
            if tab.get('tabProperties', {}).get('tabId') == tab_id:
                target_tab = tab
                break

        if not target_tab:
            print(f"❌ Tab not found: {tab_id}")
            return None

        # Create a temporary document with the tab content
        temp_title = f"{tab_result['title']} - {tab_result['tab_title']}"
        temp_doc = docs_service.documents().create(
            body={'title': temp_title}
        ).execute()
        
        temp_doc_id = temp_doc.get('documentId')
        print(f"📝 Created temporary document for export: {temp_doc_id}")

        try:
            # Copy the tab content to the temporary document
            # Note: This is a simplified approach - just copying text content
            # For full formatting preservation, we'd need to copy all structural elements
            text_content = tab_result['text']
            if text_content.strip():
                docs_service.documents().batchUpdate(
                    documentId=temp_doc_id,
                    body={'requests': [{
                        'insertText': {
                            'location': {'index': 1},
                            'text': text_content
                        }
                    }]}
                ).execute()

            # Export the temporary document
            result = export_doc(temp_doc_id, local_path, format, drive_service=drive_service)
            
            return result

        finally:
            # Clean up: delete the temporary document
            try:
                from .drive_ops import delete_file
                delete_file(temp_doc_id, permanent=True)
                print(f"🗑️  Cleaned up temporary document: {temp_doc_id}")
            except Exception as cleanup_error:
                print(f"⚠️  Warning: Failed to clean up temporary document: {cleanup_error}")

    except HttpError as e:
        print(f"❌ Failed to export tab: {e}")
        return None


# =============================================================================
# Location-Specific Content Insertion
# =============================================================================

def _get_target_content(doc: Dict[str, Any], tab_id: Optional[str] = None) -> Tuple[Dict[str, Any], Optional[str]]:
    """
    Extract the appropriate content structure and tab ID.
    
    Args:
        doc: Full document structure from Docs API
        tab_id: Optional tab ID to target specific tab
    
    Returns:
        Tuple of (body_content dict, actual_tab_id)
        
    Raises:
        ValueError: If specified tab_id not found
    """
    tabs = doc.get('tabs', [])
    
    if tab_id:
        # Find specific tab
        for tab in tabs:
            if tab.get('tabProperties', {}).get('tabId') == tab_id:
                return (
                    tab.get('documentTab', {}).get('body', {}),
                    tab_id
                )
        raise ValueError(f"Tab not found: {tab_id}")
    
    # Use first tab or document body
    if tabs:
        first_tab = tabs[0]
        return (
            first_tab.get('documentTab', {}).get('body', {}),
            first_tab.get('tabProperties', {}).get('tabId')
        )
    else:
        # Legacy single-body document
        return (doc.get('body', {}), None)


def _find_heading_index(
    body_content: Dict[str, Any],
    heading_text: str,
    position: str = 'after'
) -> Optional[int]:
    """
    Find the index relative to a specific heading within given content structure.
    
    Args:
        body_content: Body structure from tab or document (not full doc)
        heading_text: Heading text to match (case-insensitive)
        position: 'before' (before heading), 'after' (after heading), 'end' (end of section)
    
    Returns:
        Index within the body_content, or None if not found
    """
    content = body_content.get('content', [])
    
    for element in content:
        if 'paragraph' not in element:
            continue
            
        para = element['paragraph']
        para_style = para.get('paragraphStyle', {})
        named_style = para_style.get('namedStyleType', '')
        
        # Check if it's a heading style (HEADING_1 through HEADING_6)
        if named_style.startswith('HEADING_'):
            # Extract text from paragraph
            text_parts = []
            for elem in para.get('elements', []):
                if 'textRun' in elem:
                    text_parts.append(elem['textRun'].get('content', ''))
            
            para_text = ''.join(text_parts).strip()
            
            # Case-insensitive match
            if para_text.lower() == heading_text.lower():
                if position == 'before':
                    # Return index before heading paragraph
                    return element.get('startIndex', 1)
                elif position == 'after':
                    # Return index after heading paragraph
                    return element.get('endIndex', 1)
                elif position == 'end':
                    # For 'end', return after heading (can be enhanced later to find section end)
                    return element.get('endIndex', 1)
    
    return None


def _search_text_index(
    body_content: Dict[str, Any],
    search_text: str,
    position: str = 'after'
) -> Optional[int]:
    """
    Find index relative to search text within given content structure.
    
    Args:
        body_content: Body structure from tab or document (not full doc)
        search_text: Text to search for (case-insensitive)
        position: 'before' (before match), 'after' (after match)
    
    Returns:
        Index within the body_content, or None if not found
    """
    content = body_content.get('content', [])
    
    # Build a map of text content to document indices
    # We need to track cumulative text and corresponding document indices
    text_to_index_map = []  # List of (cumulative_text_length, doc_start_index, doc_end_index)
    accumulated_text = ""
    
    for element in content:
        if 'paragraph' not in element:
            continue
            
        para = element['paragraph']
        elem_start = element.get('startIndex', 1)
        elem_end = element.get('endIndex', 1)
        
        for text_elem in para.get('elements', []):
            if 'textRun' in text_elem:
                text = text_elem['textRun'].get('content', '')
                text_start_len = len(accumulated_text)
                accumulated_text += text
                text_end_len = len(accumulated_text)
                
                # Map this text segment to its document indices
                text_to_index_map.append({
                    'text_start': text_start_len,
                    'text_end': text_end_len,
                    'doc_start': elem_start,
                    'doc_end': elem_end
                })
    
    # Case-insensitive search
    search_lower = search_text.lower()
    text_lower = accumulated_text.lower()
    
    match_idx = text_lower.find(search_lower)
    if match_idx == -1:
        return None
    
    # Determine target character position in accumulated text
    if position == 'before':
        target_char_idx = match_idx
    else:  # 'after'
        target_char_idx = match_idx + len(search_text)
    
    # Find corresponding document index
    for mapping in text_to_index_map:
        if mapping['text_start'] <= target_char_idx <= mapping['text_end']:
            # Calculate offset within this text segment
            offset = target_char_idx - mapping['text_start']
            return mapping['doc_start'] + offset
    
    # If not found in map, return end of content
    if text_to_index_map:
        return text_to_index_map[-1]['doc_end']
    
    return None


def _resolve_insertion_index(
    doc: Dict[str, Any],
    tab_id: Optional[str] = None,
    index: Optional[int] = None,
    search_text: Optional[str] = None,
    heading: Optional[str] = None,
    position: str = 'after'
) -> Tuple[Optional[int], Optional[str], Optional[str]]:
    """
    Resolve the target insertion index from various location methods.
    
    Args:
        doc: Full document structure from Docs API
        tab_id: Optional tab ID to scope search/location to specific tab
        index: Explicit character index (UTF-16 units)
        search_text: Text pattern to search for
        heading: Heading text to find
        position: 'before', 'after', or 'end' (relative to search/heading)
    
    Returns:
        Tuple of (target_index, actual_tab_id, error_message)
        If error, target_index and actual_tab_id will be None
    """
    try:
        # Step 1: Identify target content structure (tab or document body)
        body_content, actual_tab_id = _get_target_content(doc, tab_id)
    except ValueError as e:
        return (None, None, str(e))
    
    # Step 2: Resolve location within that content
    # Priority: explicit index > search_text > heading > default (start)
    
    if index is not None:
        # Use provided index directly
        return (index, actual_tab_id, None)
    
    if search_text:
        # Search within target content for text pattern
        target_idx = _search_text_index(body_content, search_text, position)
        if target_idx is None:
            return (None, None, f"Text not found: '{search_text}'")
        return (target_idx, actual_tab_id, None)
    
    if heading:
        # Find heading within target content
        target_idx = _find_heading_index(body_content, heading, position)
        if target_idx is None:
            return (None, None, f"Heading not found: '{heading}'")
        return (target_idx, actual_tab_id, None)
    
    # Default to start of target content
    return (1, actual_tab_id, None)


def insert_content_at(
    doc_id: str,
    content: str,
    content_type: str = 'markdown',
    tab_id: Optional[str] = None,
    index: Optional[int] = None,
    search_text: Optional[str] = None,
    heading: Optional[str] = None,
    position: str = 'after',
    docs_service=None
) -> bool:
    """
    Insert formatted content at a specific location in a Google Doc.
    
    Supports multiple targeting methods:
    - By index: Specify exact character position (UTF-16 units)
    - By search: Find text and insert before/after it
    - By heading: Find heading and insert after it
    - Default: Insert at start of document/tab
    
    All methods support optional tab_id to target specific tabs.
    
    Args:
        doc_id: Document ID
        content: Content to insert (markdown or plain text)
        content_type: Content format ('markdown' or 'plain')
        tab_id: Optional tab ID to target specific tab
        index: Character position (UTF-16 code units). Takes precedence over other methods.
        search_text: Search for this text and insert relative to it
        heading: Find this heading and insert relative to it
        position: Position relative to search_text or heading: 'before', 'after', 'end'
        docs_service: Optional Docs service instance
    
    Returns:
        True if successful, False otherwise
    
    Note:
        When inserting into specific tabs, paragraph styles (headings, blockquotes)
        may not apply due to Google Docs API limitations. Text formatting works correctly.
    """
    if docs_service is None:
        docs_service = get_docs_service()
    
    try:
        # Get document with tabs content
        doc = docs_service.documents().get(
            documentId=doc_id,
            includeTabsContent=True
        ).execute()
        
        # Resolve the insertion location
        target_index, target_tab_id, error = _resolve_insertion_index(
            doc, tab_id, index, search_text, heading, position
        )
        
        if error:
            print(f"❌ {error}")
            return False
        
        # Build requests based on content type
        if content_type == 'markdown':
            # Get markdown requests (starting at index 0 by default)
            md_requests = markdown_to_docs_requests(content)
            
            # Adjust all indices to target location
            requests = []
            for req in md_requests:
                if 'insertText' in req:
                    req['insertText']['location']['index'] += target_index
                elif 'updateTextStyle' in req:
                    req['updateTextStyle']['range']['startIndex'] += target_index
                    req['updateTextStyle']['range']['endIndex'] += target_index
                elif 'updateParagraphStyle' in req:
                    req['updateParagraphStyle']['range']['startIndex'] += target_index
                    req['updateParagraphStyle']['range']['endIndex'] += target_index
                elif 'createParagraphBullets' in req:
                    req['createParagraphBullets']['range']['startIndex'] += target_index
                    req['createParagraphBullets']['range']['endIndex'] += target_index
                
                requests.append(req)
        else:
            # Plain text insertion
            requests = [{
                'insertText': {
                    'location': {'index': target_index},
                    'text': content
                }
            }]
        
        # Add tabId to requests when targeting specific tab (all paragraph styles included).
        if target_tab_id:
            filtered_requests = []
            for request in requests:
                request_type = list(request.keys())[0]
                request_body = request[request_type]

                if request_type == 'updateParagraphStyle' and 'range' in request_body:
                    request_body['range']['tabId'] = target_tab_id
                    filtered_requests.append(request)
                    continue

                if request_type == 'insertText' and 'location' in request_body:
                    request_body['location']['tabId'] = target_tab_id

                elif request_type == 'updateTextStyle' and 'range' in request_body:
                    request_body['range']['tabId'] = target_tab_id

                elif request_type == 'createParagraphBullets' and 'range' in request_body:
                    request_body['range']['tabId'] = target_tab_id

                filtered_requests.append(request)

            requests = filtered_requests
        
        # Execute the batch update
        docs_service.documents().batchUpdate(
            documentId=doc_id,
            body={'requests': requests}
        ).execute()
        
        # Build success message
        location_desc = []
        if index is not None:
            location_desc.append(f"index {index}")
        elif search_text:
            location_desc.append(f"{position} '{search_text}'")
        elif heading:
            location_desc.append(f"{position} heading '{heading}'")
        else:
            location_desc.append("start")
        
        if target_tab_id:
            location_desc.append(f"in tab {target_tab_id}")
        
        print(f"✅ Inserted content at {' '.join(location_desc)}")
        return True
    
    except HttpError as e:
        print(f"❌ Failed to insert content: {e}")
        return False
    except Exception as e:
        print(f"❌ Failed to insert content: {e}")
        return False


