#!/usr/bin/env python3
"""
Full test: Google Doc with README in 3 tabs.

Creates a document in the testing folder from README.md (first tab),
adds two more tabs, puts the full README content into each of the
three tabs, and prints the document URL and tab list.

Target folder: 1vSNhxgT2erehA5T1eBOZXxTPvvbBUqwp
"""

import sys
from pathlib import Path

from src.auth import get_auth
from src.docs_ops import (
    create_doc_from_file,
    list_tabs,
    create_tab,
    update_tab,
    append_to_doc,
)

TEST_FOLDER_ID = "1vSNhxgT2erehA5T1eBOZXxTPvvbBUqwp"


def _tab_by_title(tabs, title):
    """Return first tab dict with matching title, or None."""
    for t in tabs:
        if t.get("title") == title:
            return t
    return None


def test_readme_tabs():
    """Create doc from README, add 3 tabs all containing README, print URL and tabs."""
    auth = get_auth()
    if not auth.authenticate():
        print("Authentication failed")
        return False

    print("Authenticated successfully\n")

    readme_path = Path("README.md")
    if not readme_path.exists():
        print(f"README.md not found at {readme_path.absolute()}")
        return False

    readme_content = readme_path.read_text()

    try:
        # Step 1: Create doc from README in target folder (first tab has README)
        print("Step 1: Create document from README.md in testing folder...")
        doc_result = create_doc_from_file(
            str(readme_path),
            title="README - 3 Tabs Test",
            folder_id=TEST_FOLDER_ID,
        )
        if not doc_result:
            print("  Failed to create document")
            return False
        doc_id = doc_result["id"]
        url = doc_result["url"]
        print(f"  Created document: {doc_id}")
        print(f"  URL: {url}\n")

        # Step 2: Get first tab ID and rename to "Tab 1"
        tabs = list_tabs(doc_id)
        if not tabs:
            print("  Failed to list tabs")
            return False
        first_tab = tabs[0]
        first_tab_id = first_tab.get("tab_id")
        if first_tab_id:
            print("Step 2: Rename first tab to 'Tab 1'...")
            update_tab(doc_id, first_tab_id, title="Tab 1")
            print("  Done\n")
        else:
            print("Step 2: First tab has no tab_id (legacy doc), skipping rename\n")

        # Step 3: Create Tab 2 and Tab 3
        print("Step 3: Create Tab 2 and Tab 3...")
        if not create_tab(doc_id, "Tab 2"):
            print("  Failed to create Tab 2")
            return False
        if not create_tab(doc_id, "Tab 3"):
            print("  Failed to create Tab 3")
            return False
        print("  Done\n")

        # Step 4: Resolve tab IDs for Tab 2 and Tab 3
        tabs = list_tabs(doc_id)
        tab2 = _tab_by_title(tabs, "Tab 2")
        tab3 = _tab_by_title(tabs, "Tab 3")
        if not tab2 or not tab3:
            print("  Could not find Tab 2 or Tab 3 after create")
            return False
        tab2_id = tab2.get("tab_id")
        tab3_id = tab3.get("tab_id")
        if not tab2_id or not tab3_id:
            print("  Tab 2 or Tab 3 missing tab_id")
            return False

        # Step 5: Fill Tab 2 and Tab 3 with README content
        print("Step 5: Append README content to Tab 2 and Tab 3...")
        if not append_to_doc(doc_id, readme_content, content_type="markdown", tab_id=tab2_id):
            print("  Failed to append README to Tab 2")
            return False
        print("  Tab 2 filled")
        if not append_to_doc(doc_id, readme_content, content_type="markdown", tab_id=tab3_id):
            print("  Failed to append README to Tab 3")
            return False
        print("  Tab 3 filled\n")

        # Step 6: Output
        tabs = list_tabs(doc_id)
        print("=" * 60)
        print("Success: document has at least 3 tabs, each containing README")
        print("=" * 60)
        print(f"Document URL: {url}")
        print(f"Folder: https://drive.google.com/drive/folders/{TEST_FOLDER_ID}")
        print("\nTabs:")
        for t in tabs:
            print(f"  - {t.get('title')} (id: {t.get('tab_id')})")
        print("=" * 60)
        return True

    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_readme_tabs()
    sys.exit(0 if success else 1)
