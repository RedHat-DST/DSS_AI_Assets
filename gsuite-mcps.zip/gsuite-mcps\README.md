# G Suite MCPs for Cursor (Gmail / Calendar / Drive)

Share pack of the three Google Workspace MCP servers used with Cursor Agent:

| Folder | Cursor MCP name | Purpose |
|--------|-----------------|---------|
| `email-checker/` | `user-gmail-assistant` | Gmail search, triage, draft creation |
| `calendar-assistant/` | `user-calendar-assistant` | Google Calendar read/create/update |
| `gdrive-assistant/` | `user-gdrive-assistant` | Drive, Docs, Sheets, Slides |

This pack does **not** include OAuth secrets (`credentials.json`, `gdrive_token.json`), virtualenvs, or personal tokens — only placeholders.

## Requirements

- Cursor IDE
- Python 3.10+
- Google Cloud OAuth client (Desktop app) with Gmail, Calendar, Drive, Docs, Sheets, Slides APIs enabled
- Associate uses their own Google account

## Quick install (Cursor Agent)

1. Attach this folder (or a zip of `gsuite-mcps`) in Cursor Agent.
2. Paste the prompt from **INSTALL_PROMPT.md**.
3. Complete Google OAuth once when the agent asks you to auth.
4. Reload **Cursor Settings → MCP** until the three servers are green.

## Manual install

1. Copy each folder under `~/.cursor/mcp-servers/` (Windows: `%USERPROFILE%\.cursor\mcp-servers\`).
2. Create one shared venv (recommended):

```bash
cd ~/.cursor/mcp-servers
python -m venv .venv
# Windows:
.venv\Scripts\pip install -r email-checker/requirements.txt -r calendar-assistant/requirements.txt -r gdrive-assistant/requirements.txt
# macOS/Linux:
.venv/bin/pip install -r email-checker/requirements.txt -r calendar-assistant/requirements.txt -r gdrive-assistant/requirements.txt
```

3. Place your Google OAuth `credentials.json` in each MCP folder (or symlink one shared credentials file). Rename placeholders are intentional — do not commit real credentials.
4. Merge into `~/.cursor/mcp.json` using the snippets in each `mcp_config_example.json` (absolute paths; Windows use `.venv\Scripts\python.exe`).
5. Auth once per MCP via CLI (`python -m src.cli auth` / equivalent in SETUP.md).

## Security

- Never commit `credentials.json` or `gdrive_token.json`.
- Prefer Privacy Mode ON in Cursor when handling customer mail/drive content.
- Drafts only for customer email — humans send.
