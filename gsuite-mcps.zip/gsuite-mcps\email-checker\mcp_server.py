#!/usr/bin/env python3
"""
Gmail Email Assistant MCP Server.

Exposes Gmail functionality to Claude in Cursor via the Model Context Protocol.

Tools provided:
- gmail_inbox: Get prioritized inbox summary
- gmail_search: Search emails with query
- gmail_read: Read full email content
- gmail_priority_report: Generate priority breakdown
- gmail_summary: Get inbox statistics
"""

import sys
from pathlib import Path
from typing import Any

# Add project to path for imports
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from src.auth import get_auth
from src.gmail_ops import (
    search_emails, get_inbox, get_unread, read_email, get_inbox_summary, 
    create_draft, get_labels, ensure_gtd_labels, get_emails_without_gtd_labels,
    apply_labels, remove_labels, archive_to_folder, is_meeting_notes_email,
    GTD_LABELS, MEETING_ARCHIVE_LABEL
)
from src.prioritizer import prioritize_emails, get_prioritizer


# Initialize MCP server
server = Server("gmail-assistant")


def format_email_for_output(email: dict, include_body: bool = False) -> str:
    """Format an email for text output."""
    lines = []

    # Priority info if available
    if 'priority_level' in email:
        priority = email['priority_level']
        score = email.get('priority_score', 0)
        reasons = email.get('priority_reasons', [])
        lines.append(f"Priority: {priority} ({score} points)")
        if reasons:
            lines.append(f"  Reasons: {', '.join(reasons)}")

    # Core fields
    lines.append(f"From: {email.get('from', 'Unknown')}")
    lines.append(f"Subject: {email.get('subject', 'No Subject')}")
    lines.append(f"Date: {email.get('date', 'Unknown')}")

    if email.get('to'):
        lines.append(f"To: {email['to']}")

    if email.get('cc'):
        lines.append(f"CC: {email['cc']}")

    # Status
    status_parts = []
    if email.get('is_unread'):
        status_parts.append("UNREAD")
    if email.get('jira_tickets'):
        status_parts.append(f"Jira: {', '.join(email['jira_tickets'])}")
    if status_parts:
        lines.append(f"Status: {', '.join(status_parts)}")

    lines.append(f"ID: {email.get('id', '')}")
    if email.get('thread_id'):
        lines.append(f"Thread ID: {email['thread_id']}")
    lines.append(f"URL: {email.get('url', '')}")

    if include_body:
        lines.append("")
        lines.append("--- Body ---")
        body = email.get('body', email.get('snippet', ''))
        if body:
            # Limit body length for output (50k chars allows most emails through)
            if len(body) > 50000:
                lines.append(body[:50000])
                lines.append(f"... ({len(body) - 50000} more characters)")
            else:
                lines.append(body)
        else:
            lines.append("(No body content)")

    return "\n".join(lines)


def ensure_authenticated():
    """Ensure Gmail is authenticated, raise if not."""
    auth = get_auth()
    if not auth.authenticate():
        raise RuntimeError(
            "Gmail authentication required. Run 'python -m src.cli auth_status' "
            "from the email-checker directory to authenticate."
        )
    return auth


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available Gmail tools."""
    return [
        Tool(
            name="gmail_inbox",
            description="Get recent inbox emails, sorted by priority. Returns emails with priority scores based on VIP senders, keywords, Jira tickets, and recency.",
            inputSchema={
                "type": "object",
                "properties": {
                    "num_emails": {
                        "type": "integer",
                        "description": "Number of emails to retrieve (default: 20, max: 50)",
                        "default": 20
                    },
                    "unread_only": {
                        "type": "boolean",
                        "description": "Only show unread emails",
                        "default": False
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="gmail_search",
            description="Search emails using Gmail query syntax. Supports operators like from:, to:, subject:, after:, before:, has:attachment, is:unread, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Gmail search query (e.g., 'from:boss@company.com subject:urgent')"
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 20)",
                        "default": 20
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="gmail_read",
            description="Read the full content of a specific email by its ID. Use this to see the complete body of an email.",
            inputSchema={
                "type": "object",
                "properties": {
                    "message_id": {
                        "type": "string",
                        "description": "The Gmail message ID to read"
                    }
                },
                "required": ["message_id"]
            }
        ),
        Tool(
            name="gmail_priority_report",
            description="Generate a priority breakdown of inbox emails, categorized as HIGH, MEDIUM, and LOW priority with explanations.",
            inputSchema={
                "type": "object",
                "properties": {
                    "num_emails": {
                        "type": "integer",
                        "description": "Number of emails to analyze (default: 30)",
                        "default": 30
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="gmail_summary",
            description="Get inbox statistics including total messages, unread count, and today's email count.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="gmail_create_draft",
            description="Create a draft email in Gmail. Can be used to compose new emails or draft replies to existing threads.",
            inputSchema={
                "type": "object",
                "properties": {
                    "to": {
                        "type": "string",
                        "description": "Recipient email address(es), comma-separated for multiple"
                    },
                    "subject": {
                        "type": "string",
                        "description": "Email subject line"
                    },
                    "body": {
                        "type": "string",
                        "description": "Email body content (plain text, markdown, or HTML depending on content_type)"
                    },
                    "cc": {
                        "type": "string",
                        "description": "CC recipients, comma-separated (optional)",
                        "default": ""
                    },
                    "reply_to_message_id": {
                        "type": "string",
                        "description": "Message ID of email being replied to (optional, for threading)",
                        "default": ""
                    },
                    "thread_id": {
                        "type": "string",
                        "description": "Thread ID to add the draft to (optional, for replies)",
                        "default": ""
                    },
                    "content_type": {
                        "type": "string",
                        "description": "Body format: 'markdown' (default), 'plain' (text with > quotes), 'html', or 'auto' (detect)",
                        "default": "markdown",
                        "enum": ["markdown", "plain", "html", "auto"]
                    }
                },
                "required": ["to", "subject", "body"]
            }
        ),
        # GTD Categorization Tools
        Tool(
            name="gmail_setup_gtd_labels",
            description="Create GTD labels in Gmail (Urgent, Action, Reply Needed, Waiting For, Review, Ignore, Needs Review). Run this once before using categorization.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="gmail_list_uncategorized",
            description="List inbox emails that don't have GTD labels yet. Use this to find emails that need categorization.",
            inputSchema={
                "type": "object",
                "properties": {
                    "num_emails": {
                        "type": "integer",
                        "description": "Number of emails to retrieve (default: 30, max: 50)",
                        "default": 30
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="gmail_apply_gtd_label",
            description="Apply a GTD label to an email. Use ONE label per email (Urgent wins if applicable). Valid labels: GTD/Urgent, GTD/Action, GTD/Reply Needed, GTD/Waiting For, GTD/Review, GTD/Ignore, GTD/Needs Review",
            inputSchema={
                "type": "object",
                "properties": {
                    "message_id": {
                        "type": "string",
                        "description": "Gmail message ID"
                    },
                    "labels": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "GTD label to apply - use single label (e.g., ['GTD/Action']). Urgent wins over other labels."
                    }
                },
                "required": ["message_id", "labels"]
            }
        ),
        Tool(
            name="gmail_remove_gtd_label",
            description="Remove GTD labels from an email.",
            inputSchema={
                "type": "object",
                "properties": {
                    "message_id": {
                        "type": "string",
                        "description": "Gmail message ID"
                    },
                    "labels": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of GTD label names to remove"
                    }
                },
                "required": ["message_id", "labels"]
            }
        ),
        Tool(
            name="gmail_get_labels",
            description="List all Gmail labels including GTD labels and their IDs.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""

    try:
        if name == "gmail_inbox":
            return await handle_inbox(arguments)
        elif name == "gmail_search":
            return await handle_search(arguments)
        elif name == "gmail_read":
            return await handle_read(arguments)
        elif name == "gmail_priority_report":
            return await handle_priority_report(arguments)
        elif name == "gmail_summary":
            return await handle_summary(arguments)
        elif name == "gmail_create_draft":
            return await handle_create_draft(arguments)
        elif name == "gmail_setup_gtd_labels":
            return await handle_setup_gtd_labels(arguments)
        elif name == "gmail_list_uncategorized":
            return await handle_list_uncategorized(arguments)
        elif name == "gmail_apply_gtd_label":
            return await handle_apply_gtd_label(arguments)
        elif name == "gmail_remove_gtd_label":
            return await handle_remove_gtd_label(arguments)
        elif name == "gmail_get_labels":
            return await handle_get_labels(arguments)
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_inbox(arguments: dict) -> list[TextContent]:
    """Handle gmail_inbox tool call."""
    auth = ensure_authenticated()
    user_email = auth.get_user_email()

    num_emails = min(arguments.get("num_emails", 20), 50)
    unread_only = arguments.get("unread_only", False)

    if unread_only:
        emails = get_unread(max_results=num_emails)
    else:
        emails = get_inbox(max_results=num_emails)

    if not emails:
        return [TextContent(type="text", text="No emails found.")]

    # Prioritize emails
    prioritized = prioritize_emails(emails, user_email)

    # Format output
    lines = [f"📥 {'Unread ' if unread_only else ''}Inbox ({len(prioritized)} emails)\n"]

    for i, email in enumerate(prioritized, 1):
        priority = email.get('priority_level', 'LOW')
        score = email.get('priority_score', 0)
        icon = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '⚪'}.get(priority, '⚪')
        unread = "📬 " if email.get('is_unread') else ""

        lines.append(f"{i}. {icon} {unread}{email.get('subject', 'No Subject')}")
        lines.append(f"   From: {email.get('from', 'Unknown')}")
        lines.append(f"   Date: {email.get('date', 'Unknown')}")
        if email.get('priority_reasons'):
            lines.append(f"   Priority: {priority} ({score}) - {', '.join(email['priority_reasons'])}")
        lines.append(f"   ID: {email.get('id', '')}")
        lines.append("")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_search(arguments: dict) -> list[TextContent]:
    """Handle gmail_search tool call."""
    auth = ensure_authenticated()
    user_email = auth.get_user_email()

    query = arguments.get("query", "")
    num_results = min(arguments.get("num_results", 20), 50)

    if not query:
        return [TextContent(type="text", text="Please provide a search query.")]

    emails = search_emails(query, max_results=num_results)

    if not emails:
        return [TextContent(type="text", text=f"No emails found for query: {query}")]

    # Prioritize results
    prioritized = prioritize_emails(emails, user_email)

    # Format output
    lines = [f"🔍 Search results for: {query}\n", f"Found {len(prioritized)} emails:\n"]

    for i, email in enumerate(prioritized, 1):
        priority = email.get('priority_level', 'LOW')
        icon = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '⚪'}.get(priority, '⚪')
        unread = "📬 " if email.get('is_unread') else ""

        lines.append(f"{i}. {icon} {unread}{email.get('subject', 'No Subject')}")
        lines.append(f"   From: {email.get('from', 'Unknown')}")
        lines.append(f"   Date: {email.get('date', 'Unknown')}")
        if email.get('jira_tickets'):
            lines.append(f"   Jira: {', '.join(email['jira_tickets'])}")
        lines.append(f"   ID: {email.get('id', '')}")
        lines.append("")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_read(arguments: dict) -> list[TextContent]:
    """Handle gmail_read tool call."""
    auth = ensure_authenticated()
    user_email = auth.get_user_email()

    message_id = arguments.get("message_id", "")

    if not message_id:
        return [TextContent(type="text", text="Please provide a message_id.")]

    email = read_email(message_id)

    if not email:
        return [TextContent(type="text", text=f"Email not found: {message_id}")]

    # Add priority info
    prioritized = prioritize_emails([email], user_email)
    if prioritized:
        email = prioritized[0]

    # Format full output
    output = format_email_for_output(email, include_body=True)

    return [TextContent(type="text", text=output)]


async def handle_priority_report(arguments: dict) -> list[TextContent]:
    """Handle gmail_priority_report tool call."""
    auth = ensure_authenticated()
    user_email = auth.get_user_email()

    num_emails = min(arguments.get("num_emails", 30), 50)

    emails = get_inbox(max_results=num_emails)

    if not emails:
        return [TextContent(type="text", text="No emails to analyze.")]

    # Prioritize
    prioritized = prioritize_emails(emails, user_email)
    prioritizer = get_prioritizer()
    summary = prioritizer.get_priority_summary(prioritized)

    # Format report
    lines = [
        "📊 Email Priority Report\n",
        f"Analyzed {summary['total']} emails:\n",
        f"🔴 HIGH priority:   {summary['high_count']} emails",
        f"🟡 MEDIUM priority: {summary['medium_count']} emails",
        f"⚪ LOW priority:    {summary['low_count']} emails",
        ""
    ]

    # Detail HIGH priority emails
    if summary['high_emails']:
        lines.append("\n── HIGH PRIORITY (requires attention) ──\n")
        for email in summary['high_emails']:
            lines.append(f"• {email.get('subject', 'No Subject')}")
            lines.append(f"  From: {email.get('from', 'Unknown')}")
            lines.append(f"  Reasons: {', '.join(email.get('priority_reasons', []))}")
            lines.append(f"  ID: {email.get('id', '')}")
            lines.append("")

    # Summary of MEDIUM priority
    if summary['medium_emails']:
        lines.append(f"\n── MEDIUM PRIORITY ({summary['medium_count']} emails) ──\n")
        for email in summary['medium_emails'][:5]:
            lines.append(f"• {email.get('subject', 'No Subject')}")
            lines.append(f"  From: {email.get('from', 'Unknown')}")
            lines.append("")
        if len(summary['medium_emails']) > 5:
            lines.append(f"... and {len(summary['medium_emails']) - 5} more medium priority emails")

    # Note about LOW priority
    if summary['low_emails']:
        lines.append(f"\n── LOW PRIORITY ({summary['low_count']} emails) ──")
        lines.append("These can likely wait or be delegated.")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_summary(arguments: dict) -> list[TextContent]:
    """Handle gmail_summary tool call."""
    ensure_authenticated()

    stats = get_inbox_summary()

    if not stats:
        return [TextContent(type="text", text="Failed to get inbox summary.")]

    lines = [
        "📈 Gmail Inbox Summary\n",
        f"Account:        {stats.get('email', 'Unknown')}",
        f"Total messages: {stats.get('total_messages', 0):,}",
        f"Total threads:  {stats.get('total_threads', 0):,}",
        f"Unread:         {stats.get('unread_count', 0)}",
        f"Today:          {stats.get('today_count', 0)}"
    ]

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_create_draft(arguments: dict) -> list[TextContent]:
    """Handle gmail_create_draft tool call."""
    ensure_authenticated()

    to = arguments.get("to", "")
    subject = arguments.get("subject", "")
    body = arguments.get("body", "")
    cc = arguments.get("cc", "")
    reply_to_message_id = arguments.get("reply_to_message_id", "")
    thread_id = arguments.get("thread_id", "")
    content_type = arguments.get("content_type", "markdown")

    if not to or not subject or not body:
        return [TextContent(type="text", text="Please provide 'to', 'subject', and 'body' fields.")]

    result = create_draft(
        to=to,
        subject=subject,
        body=body,
        cc=cc,
        reply_to_message_id=reply_to_message_id,
        thread_id=thread_id,
        content_type=content_type
    )

    if not result:
        return [TextContent(type="text", text="Failed to create draft.")]

    lines = [
        "✅ Draft created successfully!\n",
        f"Draft ID: {result.get('draft_id', '')}",
        f"Thread ID: {result.get('thread_id', '')}",
        f"View draft: {result.get('url', '')}"
    ]

    return [TextContent(type="text", text="\n".join(lines))]


# =============================================================================
# GTD Categorization Handlers
# =============================================================================

async def handle_setup_gtd_labels(arguments: dict) -> list[TextContent]:
    """Handle gmail_setup_gtd_labels tool call."""
    ensure_authenticated()

    label_ids = ensure_gtd_labels()

    lines = [
        "🏷️ GTD Labels Setup\n",
        f"Created/verified {len(label_ids)} labels:\n"
    ]

    for label_name in GTD_LABELS.keys():
        if label_name in label_ids:
            lines.append(f"  ✅ {label_name}")
        else:
            lines.append(f"  ❌ {label_name} (failed)")

    lines.append("\nYou can now use gmail_apply_gtd_label to categorize emails.")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_list_uncategorized(arguments: dict) -> list[TextContent]:
    """Handle gmail_list_uncategorized tool call."""
    auth = ensure_authenticated()
    user_email = auth.get_user_email()

    num_emails = min(arguments.get("num_emails", 30), 50)

    emails = get_emails_without_gtd_labels(max_results=num_emails)

    if not emails:
        return [TextContent(type="text", text="✨ No uncategorized emails! All inbox emails have GTD labels.")]

    # Auto-archive meeting notes before categorization
    archived_meetings = []
    remaining_emails = []
    
    for email in emails:
        if is_meeting_notes_email(email):
            # Archive to @Reference/Meetings
            if archive_to_folder(email['id'], MEETING_ARCHIVE_LABEL):
                archived_meetings.append(email)
            else:
                # If archive failed, still include in list for manual handling
                remaining_emails.append(email)
        else:
            remaining_emails.append(email)

    # Prioritize remaining emails
    prioritized = prioritize_emails(remaining_emails, user_email)

    lines = []
    
    # Report auto-archived meetings if any
    if archived_meetings:
        lines.append(f"📁 Auto-archived {len(archived_meetings)} meeting notes to {MEETING_ARCHIVE_LABEL}:")
        for email in archived_meetings:
            lines.append(f"   • {email.get('subject', 'No Subject')}")
        lines.append("")

    if not prioritized:
        if archived_meetings:
            lines.append("✨ No other uncategorized emails! All inbox emails have GTD labels.")
            return [TextContent(type="text", text="\n".join(lines))]
        return [TextContent(type="text", text="✨ No uncategorized emails! All inbox emails have GTD labels.")]

    lines.append(f"📋 Uncategorized Emails ({len(prioritized)} found)\n")
    lines.append("These emails don't have GTD labels yet:\n")

    for i, email in enumerate(prioritized, 1):
        priority = email.get('priority_level', 'LOW')
        icon = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '⚪'}.get(priority, '⚪')
        unread = "📬 " if email.get('is_unread') else ""

        lines.append(f"{i}. {icon} {unread}{email.get('subject', 'No Subject')}")
        lines.append(f"   From: {email.get('from', 'Unknown')}")
        lines.append(f"   Date: {email.get('date', 'Unknown')}")
        lines.append(f"   ID: {email.get('id', '')}")
        lines.append("")

    lines.append("─" * 50)
    lines.append("\nTo categorize an email:")
    lines.append("1. Use gmail_read to see full content")
    lines.append("2. Determine GTD category (Action, Reply Needed, etc.)")
    lines.append("3. Use gmail_apply_gtd_label to apply the label")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_apply_gtd_label(arguments: dict) -> list[TextContent]:
    """Handle gmail_apply_gtd_label tool call."""
    ensure_authenticated()

    message_id = arguments.get("message_id", "")
    labels = arguments.get("labels", [])

    if not message_id:
        return [TextContent(type="text", text="Please provide a message_id.")]

    if not labels:
        return [TextContent(type="text", text="Please provide at least one label.")]

    # Normalize label names (allow shorthand like "Action" instead of "GTD/Action")
    normalized_labels = []
    valid_label_names = list(GTD_LABELS.keys())

    for label in labels:
        if not label.startswith('GTD/'):
            label = f'GTD/{label}'
        if label in valid_label_names:
            normalized_labels.append(label)
        else:
            return [TextContent(
                type="text",
                text=f"Invalid label: {label}\n\nValid labels:\n" + "\n".join(f"  - {l}" for l in valid_label_names)
            )]

    if apply_labels(message_id, normalized_labels):
        return [TextContent(
            type="text",
            text=f"✅ Applied labels to {message_id}:\n" + "\n".join(f"  • {l}" for l in normalized_labels)
        )]
    else:
        return [TextContent(type="text", text=f"❌ Failed to apply labels to {message_id}")]


async def handle_remove_gtd_label(arguments: dict) -> list[TextContent]:
    """Handle gmail_remove_gtd_label tool call."""
    ensure_authenticated()

    message_id = arguments.get("message_id", "")
    labels = arguments.get("labels", [])

    if not message_id:
        return [TextContent(type="text", text="Please provide a message_id.")]

    if not labels:
        return [TextContent(type="text", text="Please provide at least one label to remove.")]

    # Normalize label names
    normalized_labels = []
    for label in labels:
        if not label.startswith('GTD/'):
            label = f'GTD/{label}'
        normalized_labels.append(label)

    if remove_labels(message_id, normalized_labels):
        return [TextContent(
            type="text",
            text=f"✅ Removed labels from {message_id}:\n" + "\n".join(f"  • {l}" for l in normalized_labels)
        )]
    else:
        return [TextContent(type="text", text=f"❌ Failed to remove labels from {message_id}")]


async def handle_get_labels(arguments: dict) -> list[TextContent]:
    """Handle gmail_get_labels tool call."""
    ensure_authenticated()

    all_labels = get_labels()

    # Separate GTD labels from others
    gtd_labels = []
    other_labels = []

    for label in all_labels:
        if label['name'].startswith('GTD/'):
            gtd_labels.append(label)
        elif label['type'] == 'user':
            other_labels.append(label)

    lines = ["🏷️ Gmail Labels\n"]

    # GTD Labels section
    lines.append("── GTD Labels ──")
    if gtd_labels:
        for label in sorted(gtd_labels, key=lambda x: x['name']):
            lines.append(f"  ✅ {label['name']} (ID: {label['id']})")
    else:
        lines.append("  (none - run gmail_setup_gtd_labels to create)")
    lines.append("")

    # Other user labels
    if other_labels:
        lines.append("── Other User Labels ──")
        for label in sorted(other_labels, key=lambda x: x['name'])[:20]:
            lines.append(f"  • {label['name']}")
        if len(other_labels) > 20:
            lines.append(f"  ... and {len(other_labels) - 20} more")

    return [TextContent(type="text", text="\n".join(lines))]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

