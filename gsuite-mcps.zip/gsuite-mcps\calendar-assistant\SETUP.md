# Google Cloud Setup Guide

This guide walks you through setting up Google Cloud OAuth credentials for the Calendar Assistant.

## Prerequisites

- A Google account (your Red Hat Google Workspace account or personal account)
- Access to [Google Cloud Console](https://console.cloud.google.com/)

## Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click the project dropdown at the top of the page
3. Click **New Project**
4. Enter a project name (e.g., "Calendar Assistant")
5. Click **Create**
6. Wait for the project to be created, then select it from the dropdown

## Step 2: Enable the Calendar API

1. In the left sidebar, go to **APIs & Services** > **Library**
2. Search for "Google Calendar API"
3. Click on **Google Calendar API**
4. Click **Enable**

## Step 3: Configure OAuth Consent Screen

1. In the left sidebar, go to **APIs & Services** > **OAuth consent screen**
2. Select **Internal** (for Google Workspace users) or **External** (for personal accounts)
3. Click **Create**
4. Fill in the required fields:
   - **App name**: Calendar Assistant
   - **User support email**: Your email address
   - **Developer contact email**: Your email address
5. Click **Save and Continue**
6. On the **Scopes** page, click **Add or Remove Scopes**
7. Find and select this scope:
   - `https://www.googleapis.com/auth/calendar.readonly` - Read calendar events
8. Click **Update**, then **Save and Continue**
9. On the **Test users** page (if External):
   - Click **Add Users**
   - Add your email address
   - Click **Save and Continue**
10. Click **Back to Dashboard**

## Step 4: Create OAuth 2.0 Credentials

1. In the left sidebar, go to **APIs & Services** > **Credentials**
2. Click **+ Create Credentials** at the top
3. Select **OAuth client ID**
4. For **Application type**, select **Desktop app**
5. Enter a name (e.g., "Calendar Assistant Desktop")
6. Click **Create**
7. A dialog will appear with your credentials
8. Click **Download JSON**
9. Rename the downloaded file to `credentials.json`
10. Move it to this project directory:
    ```bash
    mv ~/Downloads/client_secret_*.json ~/Code/calendar-assistant/credentials.json
    ```

## Step 5: Install Dependencies

```bash
cd ~/Code/calendar-assistant
pip install -r requirements.txt
```

Or use a virtual environment:

```bash
cd ~/Code/calendar-assistant
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Step 6: First-Time Authentication

Run the CLI to trigger the OAuth flow:

```bash
python -m src.cli today
```

This will:
1. Open your browser to Google's authorization page
2. Ask you to sign in and grant permissions
3. Redirect back to the local callback server
4. Save your token to `gdrive_token.json`

After this, you won't need to re-authenticate unless you revoke access or the token expires.

## Sharing Credentials with Other Tools

If you already have `credentials.json` from another Google API tool (like `email-checker` or `gdrive-assistant`), you can reuse it:

```bash
cd ~/Code/calendar-assistant
ln -s ../email-checker/credentials.json credentials.json
```

The same applies to the token file if it has the appropriate scopes:

```bash
ln -s ../email-checker/gdrive_token.json gdrive_token.json
```

**Note:** If the existing token doesn't have the `calendar.readonly` scope, you'll be prompted to re-authenticate.

## Troubleshooting

### "Access blocked: This app's request is invalid"
- Make sure you've added yourself as a test user (Step 3.9)
- Verify the redirect URI matches `http://localhost:8091/`

### "Permission denied" errors
- Ensure you selected the calendar.readonly scope in Step 3.7
- Try deleting `gdrive_token.json` and re-authenticating

### Token refresh issues
- Delete `gdrive_token.json` and run the CLI again
- The token will be automatically refreshed when needed

### "Calendar API not enabled"
- Go back to Step 2 and make sure you clicked "Enable" for the Calendar API
- Wait a few minutes for the change to propagate

## Security Notes

- **Never commit `credentials.json` or `gdrive_token.json` to git**
- These files contain sensitive OAuth credentials
- The `.gitignore` file is configured to exclude them
- Only request `calendar.readonly` scope for read-only access

## File Locations

After setup, you should have:

```
calendar-assistant/
├── credentials.json      # Your OAuth client credentials (from Step 4)
├── gdrive_token.json     # Auto-generated after first auth (Step 6)
└── ...
```

## Using with MCP in Cursor

After authentication works via CLI, configure the MCP server in Cursor:

1. Edit `~/.cursor/mcp.json`
2. Add the calendar-assistant configuration (see README.md)
3. Restart Cursor
4. The calendar tools should now be available to Claude

