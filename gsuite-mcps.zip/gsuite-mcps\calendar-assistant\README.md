# Google Calendar Assistant

A full-featured CLI tool and MCP (Model Context Protocol) server for Google Calendar. Designed for quick calendar queries, event management, and AI assistant integration with Cursor.

## Features

### Reading Calendar Data
- **📅 Calendar Access** - List all your calendars and their access levels
- **📆 Today's Schedule** - View all events for today
- **⏭️ Upcoming Events** - See events for the next N days
- **🔍 Search Events** - Find events by text query
- **🎯 Current Event** - Get the event happening now or next up

### Creating & Managing Events
- **✨ Event Creation** - Create events with full metadata support
- **📝 Rich Metadata** - Add descriptions, locations, attendees, attachments
- **📹 Video Conferencing** - Auto-create Google Meet links, add Zoom/custom URLs
- **🔔 Reminders** - Custom popup/email reminders
- **🔁 Recurring Events** - Support for complex recurrence patterns
- **🎨 Event Colors** - Organize with 11 color options
- **✏️ Event Updates** - Modify existing events
- **🗑️ Event Deletion** - Remove events when needed

### Integration
- **🤖 MCP Integration** - Full Model Context Protocol support for Cursor
- **🔐 OAuth 2.0** - Secure authentication with token refresh

## Installation

### 1. Clone and Install Dependencies

```bash
cd calendar-assistant
pip install -r requirements.txt
```

Or use a virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Google Cloud Setup

You'll need OAuth 2.0 credentials from Google Cloud Console. See [SETUP.md](SETUP.md) for detailed instructions.

**TL;DR for existing email-checker users:**
```bash
# Enable Calendar API in your Google Cloud project
# Then:
ln -s ../email-checker/credentials.json credentials.json
pip install -r requirements.txt
python -m src.cli auth-status
```

### 3. First Authentication

```bash
python -m src.cli today
```

This opens a browser for Google OAuth. After authorization, your token is saved to `gdrive_token.json`.

## CLI Usage

```bash
# List all calendars
python -m src.cli calendars

# View today's events
python -m src.cli today

# View upcoming events (default: 7 days)
python -m src.cli upcoming [days]

# Search events
python -m src.cli search "team meeting"

# View specific event
python -m src.cli event <event_id>

# View current or next event
python -m src.cli now

# Check authentication status
python -m src.cli auth-status
```

## MCP Server Integration

### Cursor IDE Setup

Add to your MCP configuration (typically `~/.cursor/mcp.json`):

```json
{
  "mcpServers": {
    "calendar-assistant": {
      "command": "python",
      "args": ["/path/to/calendar-assistant/mcp_server.py"],
      "env": {}
    }
  }
}
```

Or use `uv` for better dependency management:

```json
{
  "mcpServers": {
    "calendar-assistant": {
      "command": "uv",
      "args": [
        "--directory",
        "/path/to/calendar-assistant",
        "run",
        "python",
        "/path/to/calendar-assistant/mcp_server.py"
      ],
      "env": {}
    }
  }
}
```

### Available MCP Tools

#### Reading Calendar Data
| Tool | Description |
|------|-------------|
| `calendar_list_calendars` | List all accessible calendars |
| `calendar_today` | Get today's events |
| `calendar_upcoming` | Get events for next N days |
| `calendar_search` | Search events by text |
| `calendar_get_event` | Get details for specific event |
| `calendar_now` | Get current or next event |

#### Creating & Managing Events
| Tool | Description |
|------|-------------|
| `calendar_create_event` | Create a new event with comprehensive metadata |
| `calendar_update_event` | Update an existing event |
| `calendar_delete_event` | Delete an event permanently |

#### Event Creation Features

The `calendar_create_event` tool supports:
- **Basic Info**: Title, description, location, start/end times
- **Attendees**: Add participants by email address
- **Video Conferencing**: 
  - `'hangoutsMeet'` or `'meet'` - Auto-creates Google Meet link
  - `'zoom'` - Adds placeholder for Zoom link
  - Custom URL - Any video conference link
- **Attachments**: Google Drive files or public URLs with title and MIME type
- **Reminders**: Popup or email notifications at custom times
- **Recurrence**: RRULE patterns for repeating events
- **Color**: 11 color options for visual organization
- **Visibility**: Public, private, or confidential settings
- **Transparency**: Mark as busy or free time
- **Timezone**: Specify event timezone

## Usage Examples

### CLI Examples

```bash
# See what's on your calendar today
python -m src.cli today

# Check your schedule for the next 2 weeks
python -m src.cli upcoming 14

# Find all meetings with "standup" in the title
python -m src.cli search "standup"

# See what's happening right now
python -m src.cli now

# List all your calendars
python -m src.cli calendars
```

### MCP Examples (in Cursor)

Ask Claude in Cursor:

**Reading Calendar:**
- "What's on my calendar today?"
- "What meetings do I have this week?"
- "When is my next meeting?"
- "Search my calendar for 1:1 meetings"
- "Show me all events with John next month"

**Creating Events:**
- "Create a team meeting tomorrow at 2pm for 1 hour with john@example.com and jane@example.com"
- "Schedule a 1:1 with Sarah next Tuesday at 3pm, add a Google Meet link"
- "Create an all-day event for my vacation from Dec 20-27"
- "Add a recurring standup meeting every Monday at 9am"
- "Create a meeting with a custom Zoom link at https://zoom.us/j/123456789"
- "Schedule an event with reminders 30 minutes and 1 day before"

**Managing Events:**
- "Update the meeting titled 'Project Review' to start at 3pm instead"
- "Delete the event with ID abc123"
- "Change the location of tomorrow's 2pm meeting to Conference Room B"

## Project Structure

```
calendar-assistant/
├── mcp_server.py         # MCP server for Cursor
├── src/
│   ├── auth.py           # OAuth 2.0 authentication
│   ├── calendar_ops.py   # Calendar API operations
│   └── cli.py            # CLI interface
├── config/               # Configuration files
├── .cursorrules          # Cursor AI rules (optional)
├── SETUP.md              # Setup instructions
└── requirements.txt      # Python dependencies
```

## Security

- **Full Calendar Access** - Requests `calendar` scope for read/write operations
- **OAuth credentials** (`credentials.json`) and tokens (`gdrive_token.json`) are gitignored
- Token files use restricted permissions (0o600)
- Tokens auto-refresh before expiry
- All event operations require explicit user authorization through OAuth
- Input validation prevents malformed event data

## Requirements

- Python 3.10+
- Google account with Calendar
- Google Cloud project with Calendar API enabled

## Troubleshooting

### "Authentication failed"
- Run `python -m src.cli auth-status` to check token status
- Delete `gdrive_token.json` and re-authenticate if needed
- Ensure `credentials.json` exists and is valid

### "No calendars found"
- Verify Calendar API is enabled in Google Cloud Console
- Check that you granted calendar access during OAuth flow
- Make sure you're signed in to the correct Google account

### MCP Server not working in Cursor
- Verify the path in `mcp.json` is correct
- Check that dependencies are installed
- Look at Cursor's MCP logs for error messages
- Try running the server manually: `python mcp_server.py`

## License

Private/Internal Use

