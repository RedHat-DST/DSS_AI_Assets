"""Google Calendar Assistant - Core modules."""
