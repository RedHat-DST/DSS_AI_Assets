"""
Google Drive Operations Module.

Provides high-level functions for Google Drive interactions:
- List and search files
- Upload and download files
- Create folders
- Move, copy, delete files
- Share files and manage permissions
"""

import io
import mimetypes
import os
from pathlib import Path
from typing import Optional, List, Dict, Any

from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload
from googleapiclient.errors import HttpError

from .auth import get_drive_service


# Common MIME types for Google Workspace files
GOOGLE_MIME_TYPES = {
    'document': 'application/vnd.google-apps.document',
    'spreadsheet': 'application/vnd.google-apps.spreadsheet',
    'presentation': 'application/vnd.google-apps.presentation',
    'folder': 'application/vnd.google-apps.folder',
    'form': 'application/vnd.google-apps.form',
    'drawing': 'application/vnd.google-apps.drawing',
    'shortcut': 'application/vnd.google-apps.shortcut',
}

# Export MIME types for Google Workspace files
EXPORT_MIME_TYPES = {
    'application/vnd.google-apps.document': {
        'pdf': 'application/pdf',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'txt': 'text/plain',
        'html': 'text/html',
        'md': 'text/plain',  # Export as plain text, then convert
    },
    'application/vnd.google-apps.spreadsheet': {
        'pdf': 'application/pdf',
        'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'csv': 'text/csv',
    },
    'application/vnd.google-apps.presentation': {
        'pdf': 'application/pdf',
        'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    },
}


def list_files(
    folder_id: Optional[str] = None,
    query: Optional[str] = None,
    max_results: int = 100,
    file_types: Optional[List[str]] = None,
    drive_service=None
) -> List[Dict[str, Any]]:
    """
    List files in Google Drive.

    Args:
        folder_id: ID of folder to list (None for root/all)
        query: Additional query filter (Gmail-style query syntax)
        max_results: Maximum number of results
        file_types: List of file types to filter ('document', 'spreadsheet', etc.)
        drive_service: Optional Drive service instance

    Returns:
        List of file dictionaries with metadata
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Build query
        query_parts = []
        
        if folder_id:
            query_parts.append(f"'{folder_id}' in parents")
        
        if query:
            query_parts.append(query)
        
        if file_types:
            type_queries = []
            for ft in file_types:
                if ft in GOOGLE_MIME_TYPES:
                    type_queries.append(f"mimeType='{GOOGLE_MIME_TYPES[ft]}'")
            if type_queries:
                query_parts.append(f"({' or '.join(type_queries)})")
        
        # Exclude trashed files by default
        query_parts.append("trashed=false")
        
        final_query = " and ".join(query_parts) if query_parts else None

        # Execute query
        results = drive_service.files().list(
            q=final_query,
            pageSize=min(max_results, 1000),
            fields="nextPageToken, files(id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink, owners, shared, shortcutDetails)",
            orderBy="modifiedTime desc"
        ).execute()

        files = results.get('files', [])
        
        # Format results
        formatted = []
        for f in files[:max_results]:
            formatted.append(_format_file_metadata(f))
        
        return formatted

    except HttpError as e:
        print(f"❌ Failed to list files: {e}")
        return []


def search_files(
    query: str,
    max_results: int = 50,
    drive_service=None
) -> List[Dict[str, Any]]:
    """
    Search files by name or content.

    Args:
        query: Search query (searches name and fullText)
        max_results: Maximum number of results
        drive_service: Optional Drive service instance

    Returns:
        List of matching file dictionaries

    Examples:
        search_files("quarterly report")
        search_files("name contains 'budget'")
        search_files("fullText contains 'project plan'")
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # If query doesn't contain operators, search name and fullText
        if not any(op in query.lower() for op in ['contains', 'name', 'fulltext', 'mimetype']):
            search_query = f"(name contains '{query}' or fullText contains '{query}') and trashed=false"
        else:
            search_query = f"{query} and trashed=false"

        results = drive_service.files().list(
            q=search_query,
            pageSize=min(max_results, 1000),
            fields="files(id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink, owners, shared, shortcutDetails)",
            orderBy="modifiedTime desc"
        ).execute()

        files = results.get('files', [])
        return [_format_file_metadata(f) for f in files[:max_results]]

    except HttpError as e:
        print(f"❌ Search failed: {e}")
        return []


def get_file_metadata(
    file_id: str,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Get detailed metadata for a file.

    Args:
        file_id: Google Drive file ID
        drive_service: Optional Drive service instance

    Returns:
        File metadata dictionary or None if not found
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        file = drive_service.files().get(
            fileId=file_id,
            fields="id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink, webContentLink, owners, shared, permissions, description, shortcutDetails"
        ).execute()

        return _format_file_metadata(file)

    except HttpError as e:
        print(f"❌ Failed to get file metadata: {e}")
        return None


def resolve_shortcut(
    file_id: str,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Resolve a shortcut to its target file.
    
    If the file is a shortcut, returns info about the target file.
    If not a shortcut, returns info about the file itself.

    Args:
        file_id: Google Drive file ID (possibly a shortcut)
        drive_service: Optional Drive service instance

    Returns:
        Dictionary with target file info:
        - target_id: The actual file ID to use
        - target_mime_type: MIME type of the target file
        - is_shortcut: Whether the original file was a shortcut
        - shortcut_name: Name of the shortcut (if applicable)
        Or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Get file metadata including shortcut details
        file = drive_service.files().get(
            fileId=file_id,
            fields="id, name, mimeType, shortcutDetails"
        ).execute()

        mime_type = file.get('mimeType', '')
        
        # Check if this is a shortcut
        if mime_type == GOOGLE_MIME_TYPES['shortcut']:
            shortcut_details = file.get('shortcutDetails', {})
            target_id = shortcut_details.get('targetId')
            target_mime_type = shortcut_details.get('targetMimeType')
            
            if target_id:
                return {
                    'target_id': target_id,
                    'target_mime_type': target_mime_type,
                    'is_shortcut': True,
                    'shortcut_name': file.get('name'),
                    'shortcut_id': file_id,
                }
            else:
                print(f"⚠️ Shortcut has no target: {file.get('name')}")
                return None
        else:
            # Not a shortcut - return the file itself
            return {
                'target_id': file_id,
                'target_mime_type': mime_type,
                'is_shortcut': False,
                'shortcut_name': None,
                'shortcut_id': None,
            }

    except HttpError as e:
        print(f"❌ Failed to resolve shortcut: {e}")
        return None


def download_file(
    file_id: str,
    local_path: Optional[str] = None,
    export_format: Optional[str] = None,
    drive_service=None
) -> Optional[str]:
    """
    Download a file from Google Drive.

    For Google Workspace files (Docs, Sheets, Slides), specify export_format.
    For regular files, downloads the original.

    Args:
        file_id: Google Drive file ID
        local_path: Local path to save file (auto-generates if None)
        export_format: Export format for Google files ('pdf', 'docx', 'xlsx', 'csv', 'txt')
        drive_service: Optional Drive service instance

    Returns:
        Path to downloaded file or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Get file metadata first
        file_meta = drive_service.files().get(
            fileId=file_id,
            fields="name, mimeType"
        ).execute()

        file_name = file_meta['name']
        mime_type = file_meta['mimeType']

        # Determine if this is a Google Workspace file
        is_google_file = mime_type.startswith('application/vnd.google-apps.')

        if is_google_file:
            # Need to export Google files
            if not export_format:
                # Default export formats
                if 'document' in mime_type:
                    export_format = 'docx'
                elif 'spreadsheet' in mime_type:
                    export_format = 'xlsx'
                elif 'presentation' in mime_type:
                    export_format = 'pptx'
                else:
                    export_format = 'pdf'

            export_mime = EXPORT_MIME_TYPES.get(mime_type, {}).get(export_format)
            if not export_mime:
                print(f"❌ Cannot export {mime_type} to {export_format}")
                return None

            request = drive_service.files().export_media(
                fileId=file_id,
                mimeType=export_mime
            )

            # Add extension if not present
            if local_path is None:
                local_path = f"{file_name}.{export_format}"
            elif not local_path.endswith(f".{export_format}"):
                local_path = f"{local_path}.{export_format}"

        else:
            # Regular file - download directly
            request = drive_service.files().get_media(fileId=file_id)
            if local_path is None:
                local_path = file_name

        # Download the file
        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        
        done = False
        while not done:
            status, done = downloader.next_chunk()

        # Save to local file
        local_path = Path(local_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(local_path, 'wb') as f:
            f.write(fh.getvalue())

        print(f"✅ Downloaded: {local_path}")
        return str(local_path)

    except HttpError as e:
        print(f"❌ Download failed: {e}")
        return None


def upload_file(
    local_path: str,
    folder_id: Optional[str] = None,
    name: Optional[str] = None,
    mime_type: Optional[str] = None,
    convert_to_google: Optional[bool] = None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Upload a file to Google Drive.

    Args:
        local_path: Path to local file
        folder_id: ID of destination folder (None for root)
        name: Name for the file in Drive (defaults to local filename)
        mime_type: MIME type (auto-detected if None)
        convert_to_google: Convert to Google format (e.g., .docx to Google Doc).
            For markdown files (.md, .markdown), defaults to True (converts to Google Doc).
            For other files, defaults to False.
            Set explicitly to override the default behavior.
        drive_service: Optional Drive service instance

    Returns:
        Uploaded file metadata or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        local_path = Path(local_path)
        if not local_path.exists():
            print(f"❌ File not found: {local_path}")
            return None

        # Determine file name and MIME type
        file_name = name or local_path.name
        if mime_type is None:
            mime_type, _ = mimetypes.guess_type(str(local_path))
            mime_type = mime_type or 'application/octet-stream'

        # Auto-detect markdown files and default to conversion
        is_markdown = local_path.suffix.lower() in ['.md', '.markdown']
        if convert_to_google is None:
            convert_to_google = is_markdown  # Default True for markdown, False otherwise

        # Build file metadata
        file_metadata = {'name': file_name}
        if folder_id:
            file_metadata['parents'] = [folder_id]

        # Handle conversion to Google format
        upload_mime_type = mime_type
        if convert_to_google:
            # Map common formats to Google types
            conversion_map = {
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document': GOOGLE_MIME_TYPES['document'],
                'application/msword': GOOGLE_MIME_TYPES['document'],
                'text/plain': GOOGLE_MIME_TYPES['document'],
                'text/markdown': GOOGLE_MIME_TYPES['document'],
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': GOOGLE_MIME_TYPES['spreadsheet'],
                'application/vnd.ms-excel': GOOGLE_MIME_TYPES['spreadsheet'],
                'text/csv': GOOGLE_MIME_TYPES['spreadsheet'],
                'application/vnd.openxmlformats-officedocument.presentationml.presentation': GOOGLE_MIME_TYPES['presentation'],
                'application/vnd.ms-powerpoint': GOOGLE_MIME_TYPES['presentation'],
            }
            if mime_type in conversion_map:
                file_metadata['mimeType'] = conversion_map[mime_type]

        # Create media upload
        media = MediaFileUpload(
            str(local_path),
            mimetype=upload_mime_type,
            resumable=local_path.stat().st_size > 5 * 1024 * 1024  # Resumable for > 5MB
        )

        # Upload
        file = drive_service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id, name, mimeType, size, webViewLink, parents'
        ).execute()

        print(f"✅ Uploaded: {file['name']} (ID: {file['id']})")
        return _format_file_metadata(file)

    except HttpError as e:
        print(f"❌ Upload failed: {e}")
        return None


def create_folder(
    name: str,
    parent_id: Optional[str] = None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Create a folder in Google Drive.

    Args:
        name: Folder name
        parent_id: Parent folder ID (None for root)
        drive_service: Optional Drive service instance

    Returns:
        Created folder metadata or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        file_metadata = {
            'name': name,
            'mimeType': GOOGLE_MIME_TYPES['folder']
        }
        if parent_id:
            file_metadata['parents'] = [parent_id]

        folder = drive_service.files().create(
            body=file_metadata,
            fields='id, name, mimeType, webViewLink, parents'
        ).execute()

        print(f"✅ Created folder: {folder['name']} (ID: {folder['id']})")
        return _format_file_metadata(folder)

    except HttpError as e:
        print(f"❌ Failed to create folder: {e}")
        return None


def move_file(
    file_id: str,
    new_parent_id: str,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Move a file to a different folder.

    Args:
        file_id: File ID to move
        new_parent_id: Destination folder ID
        drive_service: Optional Drive service instance

    Returns:
        Updated file metadata or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        # Get current parents
        file = drive_service.files().get(
            fileId=file_id,
            fields='parents'
        ).execute()
        
        previous_parents = ",".join(file.get('parents', []))

        # Move the file
        file = drive_service.files().update(
            fileId=file_id,
            addParents=new_parent_id,
            removeParents=previous_parents,
            fields='id, name, mimeType, webViewLink, parents'
        ).execute()

        print(f"✅ Moved file: {file['name']}")
        return _format_file_metadata(file)

    except HttpError as e:
        print(f"❌ Failed to move file: {e}")
        return None


def copy_file(
    file_id: str,
    new_name: Optional[str] = None,
    folder_id: Optional[str] = None,
    drive_service=None
) -> Optional[Dict[str, Any]]:
    """
    Copy a file.

    Args:
        file_id: File ID to copy
        new_name: Name for the copy (defaults to "Copy of <original>")
        folder_id: Destination folder ID (same folder if None)
        drive_service: Optional Drive service instance

    Returns:
        Copied file metadata or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        body = {}
        if new_name:
            body['name'] = new_name
        if folder_id:
            body['parents'] = [folder_id]

        copied = drive_service.files().copy(
            fileId=file_id,
            body=body if body else None,
            fields='id, name, mimeType, webViewLink, parents'
        ).execute()

        print(f"✅ Copied to: {copied['name']} (ID: {copied['id']})")
        return _format_file_metadata(copied)

    except HttpError as e:
        print(f"❌ Failed to copy file: {e}")
        return None


def delete_file(
    file_id: str,
    permanent: bool = False,
    drive_service=None
) -> bool:
    """
    Delete a file (move to trash or permanently delete).

    Args:
        file_id: File ID to delete
        permanent: If True, permanently delete; if False, move to trash
        drive_service: Optional Drive service instance

    Returns:
        True if successful, False otherwise
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        if permanent:
            drive_service.files().delete(fileId=file_id).execute()
            print(f"✅ Permanently deleted file: {file_id}")
        else:
            drive_service.files().update(
                fileId=file_id,
                body={'trashed': True}
            ).execute()
            print(f"✅ Moved to trash: {file_id}")
        
        return True

    except HttpError as e:
        print(f"❌ Failed to delete file: {e}")
        return False


def share_file(
    file_id: str,
    email: str,
    role: str = 'reader',
    send_notification: bool = True,
    message: Optional[str] = None,
    drive_service=None
) -> bool:
    """
    Share a file with a user.

    Args:
        file_id: File ID to share
        email: Email address to share with
        role: Permission role ('reader', 'writer', 'commenter', 'owner')
        send_notification: Send email notification
        message: Optional message to include in notification
        drive_service: Optional Drive service instance

    Returns:
        True if successful, False otherwise
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        permission = {
            'type': 'user',
            'role': role,
            'emailAddress': email
        }

        drive_service.permissions().create(
            fileId=file_id,
            body=permission,
            sendNotificationEmail=send_notification,
            emailMessage=message
        ).execute()

        print(f"✅ Shared with {email} as {role}")
        return True

    except HttpError as e:
        print(f"❌ Failed to share file: {e}")
        return False


def get_share_link(
    file_id: str,
    anyone_with_link: bool = False,
    role: str = 'reader',
    drive_service=None
) -> Optional[str]:
    """
    Get a shareable link for a file.

    Args:
        file_id: File ID
        anyone_with_link: If True, create "anyone with link" access
        role: Permission role if creating new sharing ('reader', 'writer', 'commenter')
        drive_service: Optional Drive service instance

    Returns:
        Shareable URL or None on failure
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        if anyone_with_link:
            # Create "anyone with link" permission
            permission = {
                'type': 'anyone',
                'role': role
            }
            drive_service.permissions().create(
                fileId=file_id,
                body=permission
            ).execute()

        # Get the web view link
        file = drive_service.files().get(
            fileId=file_id,
            fields='webViewLink'
        ).execute()

        return file.get('webViewLink')

    except HttpError as e:
        print(f"❌ Failed to get share link: {e}")
        return None


def get_file_permissions(
    file_id: str,
    drive_service=None
) -> List[Dict[str, Any]]:
    """
    Get all permissions for a file.

    Args:
        file_id: File ID
        drive_service: Optional Drive service instance

    Returns:
        List of permission dictionaries
    """
    if drive_service is None:
        drive_service = get_drive_service()

    try:
        permissions = drive_service.permissions().list(
            fileId=file_id,
            fields='permissions(id, type, role, emailAddress, displayName)'
        ).execute()

        return permissions.get('permissions', [])

    except HttpError as e:
        print(f"❌ Failed to get permissions: {e}")
        return []


def _format_file_metadata(file: Dict[str, Any]) -> Dict[str, Any]:
    """Format raw file metadata into a consistent structure."""
    # Determine file type
    mime_type = file.get('mimeType', '')
    if mime_type == GOOGLE_MIME_TYPES['folder']:
        file_type = 'folder'
    elif mime_type == GOOGLE_MIME_TYPES['document']:
        file_type = 'document'
    elif mime_type == GOOGLE_MIME_TYPES['spreadsheet']:
        file_type = 'spreadsheet'
    elif mime_type == GOOGLE_MIME_TYPES['presentation']:
        file_type = 'presentation'
    elif mime_type == GOOGLE_MIME_TYPES['shortcut']:
        file_type = 'shortcut'
    elif mime_type.startswith('application/vnd.google-apps.'):
        file_type = 'google_file'
    else:
        file_type = 'file'

    # Format size
    size = file.get('size')
    if size:
        size = int(size)
        if size >= 1024 * 1024 * 1024:
            size_str = f"{size / (1024*1024*1024):.1f} GB"
        elif size >= 1024 * 1024:
            size_str = f"{size / (1024*1024):.1f} MB"
        elif size >= 1024:
            size_str = f"{size / 1024:.1f} KB"
        else:
            size_str = f"{size} B"
    else:
        size_str = None

    # Handle shortcut details
    shortcut_details = file.get('shortcutDetails', {})
    shortcut_target_id = shortcut_details.get('targetId')
    shortcut_target_mime = shortcut_details.get('targetMimeType')

    return {
        'id': file.get('id'),
        'name': file.get('name'),
        'type': file_type,
        'mime_type': mime_type,
        'size': size,
        'size_formatted': size_str,
        'created_time': file.get('createdTime'),
        'modified_time': file.get('modifiedTime'),
        'parents': file.get('parents', []),
        'web_link': file.get('webViewLink'),
        'download_link': file.get('webContentLink'),
        'owners': [o.get('emailAddress') for o in file.get('owners', [])],
        'shared': file.get('shared', False),
        'description': file.get('description'),
        # Shortcut info (populated only for shortcuts)
        'shortcut_target_id': shortcut_target_id,
        'shortcut_target_mime_type': shortcut_target_mime,
    }

