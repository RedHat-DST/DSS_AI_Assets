#!/usr/bin/env python3
"""
Google Drive Assistant MCP Server.

Exposes Google Drive, Docs, Sheets, and Slides functionality to Claude in Cursor
via the Model Context Protocol.

Tools provided:
- Drive: list, search, download, upload, create folder, move, delete, share
- Docs: create, read, export, append
- Sheets: create, read, write, export CSV
- Slides: create, read, add slide, export PDF
"""

import sys
from pathlib import Path
from typing import Any

# Add project to path for imports
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from src.auth import get_auth
from src.drive_ops import (
    list_files, search_files, get_file_metadata, download_file, upload_file,
    create_folder, move_file, copy_file, delete_file, share_file, get_share_link,
    resolve_shortcut
)
from src.docs_ops import (
    create_doc, read_doc, read_doc_as_markdown, export_doc, append_to_doc,
    create_doc_from_file, get_doc_info, list_tabs, read_tab, read_tab_as_markdown,
    export_tab, insert_content_at, create_tab, update_tab, delete_tab
)
from src.sheets_ops import (
    create_spreadsheet, read_range, write_range, append_rows, create_sheet,
    get_spreadsheet_info, export_csv, import_csv
)
from src.slides_ops import (
    create_presentation, get_presentation, add_slide, export_pdf as slides_export_pdf,
    add_text_box
)


# Initialize MCP server
server = Server("gdrive-assistant")


def ensure_authenticated():
    """Ensure Google APIs are authenticated, raise if not."""
    auth = get_auth()
    if not auth.authenticate():
        raise RuntimeError(
            "Google authentication required. Run 'python -m src.cli auth_status' "
            "from the gdrive-assistant directory to authenticate."
        )
    return auth


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available Google Drive tools."""
    return [
        # =============================================================================
        # Drive Tools
        # =============================================================================
        Tool(
            name="gdrive_list",
            description="List files in Google Drive. Can filter by folder, file type, and custom query.",
            inputSchema={
                "type": "object",
                "properties": {
                    "folder_id": {
                        "type": "string",
                        "description": "Folder ID to list contents of (omit for root/all files)"
                    },
                    "file_types": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Filter by types: 'document', 'spreadsheet', 'presentation', 'folder'"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 50)",
                        "default": 50
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="gdrive_search",
            description="Search for files in Google Drive by name or content.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (searches file names and content)"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 25)",
                        "default": 25
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="gdrive_get_info",
            description="Get detailed metadata for a file or folder.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "Google Drive file ID"
                    }
                },
                "required": ["file_id"]
            }
        ),
        Tool(
            name="gdrive_download",
            description="Download a file from Google Drive. For Google Docs/Sheets/Slides, specify export format.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "Google Drive file ID"
                    },
                    "local_path": {
                        "type": "string",
                        "description": "Local path to save the file"
                    },
                    "export_format": {
                        "type": "string",
                        "description": "Export format for Google files: 'pdf', 'docx', 'xlsx', 'csv', 'txt', 'pptx'"
                    }
                },
                "required": ["file_id", "local_path"]
            }
        ),
        Tool(
            name="gdrive_upload",
            description="Upload a file to Google Drive. Markdown files (.md, .markdown) are automatically converted to Google Docs by default for proper formatting.",
            inputSchema={
                "type": "object",
                "properties": {
                    "local_path": {
                        "type": "string",
                        "description": "Path to local file to upload"
                    },
                    "folder_id": {
                        "type": "string",
                        "description": "Destination folder ID (omit for root)"
                    },
                    "name": {
                        "type": "string",
                        "description": "Name for the file in Drive (defaults to local filename)"
                    },
                    "convert_to_google": {
                        "type": "boolean",
                        "description": "Convert to Google format. Defaults to True for markdown files (renders as formatted Google Doc), False for others. Set to False to upload raw markdown."
                    }
                },
                "required": ["local_path"]
            }
        ),
        Tool(
            name="gdrive_create_folder",
            description="Create a new folder in Google Drive.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Folder name"
                    },
                    "parent_id": {
                        "type": "string",
                        "description": "Parent folder ID (omit for root)"
                    }
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="gdrive_move",
            description="Move a file to a different folder.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "File ID to move"
                    },
                    "new_parent_id": {
                        "type": "string",
                        "description": "Destination folder ID"
                    }
                },
                "required": ["file_id", "new_parent_id"]
            }
        ),
        Tool(
            name="gdrive_copy",
            description="Copy a file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "File ID to copy"
                    },
                    "new_name": {
                        "type": "string",
                        "description": "Name for the copy"
                    },
                    "folder_id": {
                        "type": "string",
                        "description": "Destination folder ID"
                    }
                },
                "required": ["file_id"]
            }
        ),
        Tool(
            name="gdrive_delete",
            description="Delete a file (move to trash).",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "File ID to delete"
                    },
                    "permanent": {
                        "type": "boolean",
                        "description": "Permanently delete instead of trash",
                        "default": False
                    }
                },
                "required": ["file_id"]
            }
        ),
        Tool(
            name="gdrive_share",
            description="Share a file with another user.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "File ID to share"
                    },
                    "email": {
                        "type": "string",
                        "description": "Email address to share with"
                    },
                    "role": {
                        "type": "string",
                        "description": "Permission: 'reader', 'writer', 'commenter'",
                        "default": "reader"
                    },
                    "message": {
                        "type": "string",
                        "description": "Optional message to include in notification"
                    }
                },
                "required": ["file_id", "email"]
            }
        ),
        Tool(
            name="gdrive_get_link",
            description="Get a shareable link for a file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {
                        "type": "string",
                        "description": "File ID"
                    },
                    "anyone_with_link": {
                        "type": "boolean",
                        "description": "Make accessible to anyone with the link",
                        "default": False
                    }
                },
                "required": ["file_id"]
            }
        ),
        # =============================================================================
        # Docs Tools
        # =============================================================================
        Tool(
            name="gdocs_create",
            description="Create a new Google Doc, optionally with markdown content.",
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Document title"
                    },
                    "content": {
                        "type": "string",
                        "description": "Initial content (markdown or plain text)"
                    },
                    "content_type": {
                        "type": "string",
                        "description": "Content format: 'markdown' or 'plain'",
                        "default": "markdown"
                    },
                    "folder_id": {
                        "type": "string",
                        "description": "Folder ID to create document in"
                    }
                },
                "required": ["title"]
            }
        ),
        Tool(
            name="gdocs_create_from_file",
            description="Create a Google Doc from a local markdown file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to local markdown file"
                    },
                    "title": {
                        "type": "string",
                        "description": "Document title (defaults to filename)"
                    },
                    "folder_id": {
                        "type": "string",
                        "description": "Folder ID to create document in"
                    }
                },
                "required": ["file_path"]
            }
        ),
        Tool(
            name="gdocs_read",
            description="Read a Google Doc's content as plain text.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {
                        "type": "string",
                        "description": "Document ID"
                    }
                },
                "required": ["doc_id"]
            }
        ),
        Tool(
            name="gdocs_read_markdown",
            description="Read a Google Doc and convert to markdown format.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {
                        "type": "string",
                        "description": "Document ID"
                    }
                },
                "required": ["doc_id"]
            }
        ),
        Tool(
            name="gdocs_export",
            description="Export a Google Doc to a local file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {
                        "type": "string",
                        "description": "Document ID"
                    },
                    "local_path": {
                        "type": "string",
                        "description": "Local path to save file"
                    },
                    "format": {
                        "type": "string",
                        "description": "Export format: 'pdf', 'docx', 'txt', 'html', 'md'",
                        "default": "pdf"
                    }
                },
                "required": ["doc_id", "local_path"]
            }
        ),
        Tool(
            name="gdocs_append",
            description="Append content to the end of a Google Doc or specific tab.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {
                        "type": "string",
                        "description": "Document ID"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to append (markdown or plain text)"
                    },
                    "content_type": {
                        "type": "string",
                        "description": "Content format: 'markdown' or 'plain'",
                        "default": "markdown"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Optional tab ID to append to specific tab (e.g., 't.xyz123'). If omitted, appends to first tab."
                    }
                },
                "required": ["doc_id", "content"]
            }
        ),
        Tool(
            name="gdocs_list_tabs",
            description="List all tabs in a Google Doc. Google Docs now supports multiple tabs within a document (similar to spreadsheet sheets). Accepts full URLs or document IDs.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full Google Docs URL (e.g., https://docs.google.com/document/d/DOC_ID/edit)"
                    },
                    "include_children": {
                        "type": "boolean",
                        "description": "Include nested child tabs",
                        "default": True
                    }
                },
                "required": ["doc_id_or_url"]
            }
        ),
        Tool(
            name="gdocs_read_tab",
            description="Read content from a specific tab in a Google Doc. Accepts full URLs with tab fragments (e.g., #heading=h.TAB_ID) for direct access. Use tab_id (preferred) or tab_index to specify which tab.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full URL (e.g., https://docs.google.com/document/d/DOC_ID/edit#heading=h.TAB_ID)"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Tab ID (optional if included in URL fragment)"
                    },
                    "tab_index": {
                        "type": "integer",
                        "description": "Tab index (0-based, defaults to 0 for first tab)",
                        "default": 0
                    }
                },
                "required": ["doc_id_or_url"]
            }
        ),
        Tool(
            name="gdocs_read_tab_markdown",
            description="Read a specific tab from a Google Doc and convert to markdown format. Accepts full URLs with tab fragments (e.g., #heading=h.TAB_ID) for direct access.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full URL (e.g., https://docs.google.com/document/d/DOC_ID/edit#heading=h.TAB_ID)"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Tab ID (optional if included in URL fragment)"
                    },
                    "tab_index": {
                        "type": "integer",
                        "description": "Tab index (0-based, defaults to 0 for first tab)",
                        "default": 0
                    }
                },
                "required": ["doc_id_or_url"]
            }
        ),
        Tool(
            name="gdocs_export_tab",
            description="Export a specific tab from a Google Doc to a local file. Accepts full URLs with tab fragments (e.g., #heading=h.TAB_ID) for direct access. Creates a temporary document for non-markdown formats.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full URL (e.g., https://docs.google.com/document/d/DOC_ID/edit#heading=h.TAB_ID)"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Tab ID (optional if included in URL fragment)"
                    },
                    "local_path": {
                        "type": "string",
                        "description": "Local path to save file"
                    },
                    "format": {
                        "type": "string",
                        "description": "Export format: 'pdf', 'docx', 'txt', 'html', 'md'",
                        "default": "pdf"
                    }
                },
                "required": ["doc_id_or_url", "local_path"]
            }
        ),
        Tool(
            name="gdocs_create_tab",
            description="Create a new tab in a Google Doc. Use gdocs_list_tabs afterward to get the new tab ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full Google Docs URL"
                    },
                    "title": {
                        "type": "string",
                        "description": "Tab title (user-visible name)"
                    },
                    "index": {
                        "type": "integer",
                        "description": "Optional 0-based index within parent (inserts at position)"
                    },
                    "parent_tab_id": {
                        "type": "string",
                        "description": "Optional parent tab ID for creating a child tab"
                    },
                    "icon_emoji": {
                        "type": "string",
                        "description": "Optional single emoji for tab icon"
                    }
                },
                "required": ["doc_id_or_url", "title"]
            }
        ),
        Tool(
            name="gdocs_update_tab",
            description="Update properties of a tab in a Google Doc (e.g. title or icon).",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full Google Docs URL"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Tab ID to update"
                    },
                    "title": {
                        "type": "string",
                        "description": "New title (optional)"
                    },
                    "icon_emoji": {
                        "type": "string",
                        "description": "New icon emoji (optional)"
                    }
                },
                "required": ["doc_id_or_url", "tab_id"]
            }
        ),
        Tool(
            name="gdocs_delete_tab",
            description="Delete a tab from a Google Doc. Child tabs are deleted as well.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id_or_url": {
                        "type": "string",
                        "description": "Document ID or full Google Docs URL"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Tab ID to delete"
                    }
                },
                "required": ["doc_id_or_url", "tab_id"]
            }
        ),
        Tool(
            name="gdocs_insert",
            description="Insert formatted content at a specific location in a Google Doc. Supports markdown formatting and multiple targeting methods (index, search, heading). All location methods work with optional tab_id to target specific tabs in multi-tab documents.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {
                        "type": "string",
                        "description": "Document ID"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to insert (markdown or plain text)"
                    },
                    "content_type": {
                        "type": "string",
                        "description": "Content format: 'markdown' or 'plain'",
                        "default": "markdown"
                    },
                    "tab_id": {
                        "type": "string",
                        "description": "Optional tab ID (e.g., 't.xyz123') to target specific tab. Works with all location methods (index, search_text, heading). Use gdocs_list_tabs to get tab IDs."
                    },
                    "index": {
                        "type": "integer",
                        "description": "Character position within the tab/document (UTF-16 code units, 1-based). Takes precedence over search_text and heading."
                    },
                    "search_text": {
                        "type": "string",
                        "description": "Search for this text within the tab/document and insert relative to it. Searches within tab_id scope if provided."
                    },
                    "heading": {
                        "type": "string",
                        "description": "Find this heading within the tab/document and insert relative to it. Searches within tab_id scope if provided."
                    },
                    "position": {
                        "type": "string",
                        "description": "Position relative to search_text or heading: 'before' (before match), 'after' (after match), 'end' (end of heading section)",
                        "default": "after"
                    }
                },
                "required": ["doc_id", "content"]
            }
        ),
        # =============================================================================
        # Sheets Tools
        # =============================================================================
        Tool(
            name="gsheets_create",
            description="Create a new Google Sheets spreadsheet.",
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Spreadsheet title"
                    },
                    "sheet_names": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Names for initial sheets/tabs"
                    },
                    "folder_id": {
                        "type": "string",
                        "description": "Folder ID to create spreadsheet in"
                    }
                },
                "required": ["title"]
            }
        ),
        Tool(
            name="gsheets_read",
            description="Read a range of cells from a spreadsheet.",
            inputSchema={
                "type": "object",
                "properties": {
                    "spreadsheet_id": {
                        "type": "string",
                        "description": "Spreadsheet ID"
                    },
                    "range": {
                        "type": "string",
                        "description": "A1 notation range (e.g., 'Sheet1!A1:D10' or 'A1:D10')"
                    }
                },
                "required": ["spreadsheet_id", "range"]
            }
        ),
        Tool(
            name="gsheets_write",
            description="Write values to a range of cells.",
            inputSchema={
                "type": "object",
                "properties": {
                    "spreadsheet_id": {
                        "type": "string",
                        "description": "Spreadsheet ID"
                    },
                    "range": {
                        "type": "string",
                        "description": "A1 notation range (e.g., 'Sheet1!A1:D10')"
                    },
                    "values": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {}
                        },
                        "description": "2D array of values to write"
                    }
                },
                "required": ["spreadsheet_id", "range", "values"]
            }
        ),
        Tool(
            name="gsheets_append",
            description="Append rows to the end of a sheet.",
            inputSchema={
                "type": "object",
                "properties": {
                    "spreadsheet_id": {
                        "type": "string",
                        "description": "Spreadsheet ID"
                    },
                    "sheet_name": {
                        "type": "string",
                        "description": "Sheet/tab name"
                    },
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {}
                        },
                        "description": "List of rows to append"
                    }
                },
                "required": ["spreadsheet_id", "sheet_name", "rows"]
            }
        ),
        Tool(
            name="gsheets_info",
            description="Get information about a spreadsheet including sheets/tabs.",
            inputSchema={
                "type": "object",
                "properties": {
                    "spreadsheet_id": {
                        "type": "string",
                        "description": "Spreadsheet ID"
                    }
                },
                "required": ["spreadsheet_id"]
            }
        ),
        Tool(
            name="gsheets_export_csv",
            description="Export a sheet to CSV file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "spreadsheet_id": {
                        "type": "string",
                        "description": "Spreadsheet ID"
                    },
                    "sheet_name": {
                        "type": "string",
                        "description": "Sheet name to export"
                    },
                    "local_path": {
                        "type": "string",
                        "description": "Local path to save CSV file"
                    }
                },
                "required": ["spreadsheet_id", "sheet_name", "local_path"]
            }
        ),
        Tool(
            name="gsheets_import_csv",
            description="Import data from a CSV file to a sheet.",
            inputSchema={
                "type": "object",
                "properties": {
                    "spreadsheet_id": {
                        "type": "string",
                        "description": "Spreadsheet ID"
                    },
                    "sheet_name": {
                        "type": "string",
                        "description": "Sheet name to import to"
                    },
                    "csv_path": {
                        "type": "string",
                        "description": "Path to CSV file"
                    },
                    "start_cell": {
                        "type": "string",
                        "description": "Starting cell (e.g., 'A1')",
                        "default": "A1"
                    }
                },
                "required": ["spreadsheet_id", "sheet_name", "csv_path"]
            }
        ),
        # =============================================================================
        # Slides Tools
        # =============================================================================
        Tool(
            name="gslides_create",
            description="Create a new Google Slides presentation.",
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Presentation title"
                    },
                    "folder_id": {
                        "type": "string",
                        "description": "Folder ID to create presentation in"
                    }
                },
                "required": ["title"]
            }
        ),
        Tool(
            name="gslides_read",
            description="Read a Google Slides presentation, including metadata and text content from all slides.",
            inputSchema={
                "type": "object",
                "properties": {
                    "presentation_id": {
                        "type": "string",
                        "description": "Presentation ID"
                    }
                },
                "required": ["presentation_id"]
            }
        ),
        Tool(
            name="gslides_add_slide",
            description="Add a new slide to a presentation.",
            inputSchema={
                "type": "object",
                "properties": {
                    "presentation_id": {
                        "type": "string",
                        "description": "Presentation ID"
                    },
                    "layout": {
                        "type": "string",
                        "description": "Layout type: 'blank', 'title', 'title_body', 'title_two_columns', 'section_header'",
                        "default": "blank"
                    },
                    "index": {
                        "type": "integer",
                        "description": "Position for the slide (0-based)"
                    }
                },
                "required": ["presentation_id"]
            }
        ),
        Tool(
            name="gslides_add_text",
            description="Add a text box to a slide.",
            inputSchema={
                "type": "object",
                "properties": {
                    "presentation_id": {
                        "type": "string",
                        "description": "Presentation ID"
                    },
                    "slide_id": {
                        "type": "string",
                        "description": "Slide ID"
                    },
                    "text": {
                        "type": "string",
                        "description": "Text content"
                    },
                    "x": {
                        "type": "number",
                        "description": "X position in points",
                        "default": 100
                    },
                    "y": {
                        "type": "number",
                        "description": "Y position in points",
                        "default": 100
                    },
                    "width": {
                        "type": "number",
                        "description": "Width in points",
                        "default": 300
                    },
                    "height": {
                        "type": "number",
                        "description": "Height in points",
                        "default": 100
                    }
                },
                "required": ["presentation_id", "slide_id", "text"]
            }
        ),
        Tool(
            name="gslides_export_pdf",
            description="Export a presentation to PDF.",
            inputSchema={
                "type": "object",
                "properties": {
                    "presentation_id": {
                        "type": "string",
                        "description": "Presentation ID"
                    },
                    "local_path": {
                        "type": "string",
                        "description": "Local path to save PDF file"
                    }
                },
                "required": ["presentation_id", "local_path"]
            }
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""

    try:
        # Drive tools
        if name == "gdrive_list":
            return await handle_gdrive_list(arguments)
        elif name == "gdrive_search":
            return await handle_gdrive_search(arguments)
        elif name == "gdrive_get_info":
            return await handle_gdrive_get_info(arguments)
        elif name == "gdrive_download":
            return await handle_gdrive_download(arguments)
        elif name == "gdrive_upload":
            return await handle_gdrive_upload(arguments)
        elif name == "gdrive_create_folder":
            return await handle_gdrive_create_folder(arguments)
        elif name == "gdrive_move":
            return await handle_gdrive_move(arguments)
        elif name == "gdrive_copy":
            return await handle_gdrive_copy(arguments)
        elif name == "gdrive_delete":
            return await handle_gdrive_delete(arguments)
        elif name == "gdrive_share":
            return await handle_gdrive_share(arguments)
        elif name == "gdrive_get_link":
            return await handle_gdrive_get_link(arguments)
        
        # Docs tools
        elif name == "gdocs_create":
            return await handle_gdocs_create(arguments)
        elif name == "gdocs_create_from_file":
            return await handle_gdocs_create_from_file(arguments)
        elif name == "gdocs_read":
            return await handle_gdocs_read(arguments)
        elif name == "gdocs_read_markdown":
            return await handle_gdocs_read_markdown(arguments)
        elif name == "gdocs_export":
            return await handle_gdocs_export(arguments)
        elif name == "gdocs_append":
            return await handle_gdocs_append(arguments)
        elif name == "gdocs_list_tabs":
            return await handle_gdocs_list_tabs(arguments)
        elif name == "gdocs_read_tab":
            return await handle_gdocs_read_tab(arguments)
        elif name == "gdocs_read_tab_markdown":
            return await handle_gdocs_read_tab_markdown(arguments)
        elif name == "gdocs_export_tab":
            return await handle_gdocs_export_tab(arguments)
        elif name == "gdocs_create_tab":
            return await handle_gdocs_create_tab(arguments)
        elif name == "gdocs_update_tab":
            return await handle_gdocs_update_tab(arguments)
        elif name == "gdocs_delete_tab":
            return await handle_gdocs_delete_tab(arguments)
        elif name == "gdocs_insert":
            return await handle_gdocs_insert(arguments)
        
        # Sheets tools
        elif name == "gsheets_create":
            return await handle_gsheets_create(arguments)
        elif name == "gsheets_read":
            return await handle_gsheets_read(arguments)
        elif name == "gsheets_write":
            return await handle_gsheets_write(arguments)
        elif name == "gsheets_append":
            return await handle_gsheets_append(arguments)
        elif name == "gsheets_info":
            return await handle_gsheets_info(arguments)
        elif name == "gsheets_export_csv":
            return await handle_gsheets_export_csv(arguments)
        elif name == "gsheets_import_csv":
            return await handle_gsheets_import_csv(arguments)
        
        # Slides tools
        elif name == "gslides_create":
            return await handle_gslides_create(arguments)
        elif name == "gslides_read":
            return await handle_gslides_read(arguments)
        elif name == "gslides_add_slide":
            return await handle_gslides_add_slide(arguments)
        elif name == "gslides_add_text":
            return await handle_gslides_add_text(arguments)
        elif name == "gslides_export_pdf":
            return await handle_gslides_export_pdf(arguments)
        
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


# =============================================================================
# Drive Handlers
# =============================================================================

async def handle_gdrive_list(arguments: dict) -> list[TextContent]:
    """Handle gdrive_list tool call."""
    ensure_authenticated()

    folder_id = arguments.get("folder_id")
    file_types = arguments.get("file_types")
    max_results = arguments.get("max_results", 50)

    files = list_files(
        folder_id=folder_id,
        file_types=file_types,
        max_results=max_results
    )

    if not files:
        return [TextContent(type="text", text="No files found.")]

    lines = [f"📁 Files ({len(files)} found)\n"]
    
    for f in files:
        icon = {'folder': '📁', 'document': '📄', 'spreadsheet': '📊', 
                'presentation': '📽️', 'file': '📎'}.get(f['type'], '📎')
        size = f" ({f['size_formatted']})" if f['size_formatted'] else ""
        shared = " 🔗" if f['shared'] else ""
        
        lines.append(f"{icon} {f['name']}{size}{shared}")
        lines.append(f"   ID: {f['id']}")
        lines.append(f"   Modified: {f['modified_time']}")
        if f['web_link']:
            lines.append(f"   URL: {f['web_link']}")
        lines.append("")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_gdrive_search(arguments: dict) -> list[TextContent]:
    """Handle gdrive_search tool call."""
    ensure_authenticated()

    query = arguments.get("query", "")
    max_results = arguments.get("max_results", 25)

    if not query:
        return [TextContent(type="text", text="Please provide a search query.")]

    files = search_files(query, max_results)

    if not files:
        return [TextContent(type="text", text=f"No files found matching: {query}")]

    lines = [f"🔍 Search results for: {query}\n", f"Found {len(files)} files:\n"]
    
    for f in files:
        icon = {'folder': '📁', 'document': '📄', 'spreadsheet': '📊', 
                'presentation': '📽️', 'file': '📎'}.get(f['type'], '📎')
        
        lines.append(f"{icon} {f['name']}")
        lines.append(f"   ID: {f['id']}")
        lines.append(f"   Type: {f['type']}")
        if f['web_link']:
            lines.append(f"   URL: {f['web_link']}")
        lines.append("")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_gdrive_get_info(arguments: dict) -> list[TextContent]:
    """Handle gdrive_get_info tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    if not file_id:
        return [TextContent(type="text", text="Please provide a file_id.")]

    info = get_file_metadata(file_id)
    if not info:
        return [TextContent(type="text", text=f"File not found: {file_id}")]

    lines = [
        f"📋 File Information\n",
        f"Name: {info['name']}",
        f"ID: {info['id']}",
        f"Type: {info['type']}",
        f"MIME Type: {info['mime_type']}",
    ]
    
    if info['size_formatted']:
        lines.append(f"Size: {info['size_formatted']}")
    
    lines.extend([
        f"Created: {info['created_time']}",
        f"Modified: {info['modified_time']}",
        f"Owners: {', '.join(info['owners'])}",
        f"Shared: {info['shared']}",
    ])
    
    if info['web_link']:
        lines.append(f"URL: {info['web_link']}")
    if info['description']:
        lines.append(f"Description: {info['description']}")
    
    # Show shortcut target info if this is a shortcut
    if info['shortcut_target_id']:
        lines.append(f"\n📎 This is a shortcut pointing to:")
        lines.append(f"   Target ID: {info['shortcut_target_id']}")
        lines.append(f"   Target Type: {info['shortcut_target_mime_type']}")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_gdrive_download(arguments: dict) -> list[TextContent]:
    """Handle gdrive_download tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    local_path = arguments.get("local_path", "")
    export_format = arguments.get("export_format")

    if not file_id or not local_path:
        return [TextContent(type="text", text="Please provide file_id and local_path.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(file_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {file_id}")]
    
    actual_file_id = shortcut_info['target_id']

    result = download_file(actual_file_id, local_path, export_format)
    
    if result:
        return [TextContent(type="text", text=f"✅ Downloaded to: {result}")]
    else:
        return [TextContent(type="text", text="❌ Download failed")]


async def handle_gdrive_upload(arguments: dict) -> list[TextContent]:
    """Handle gdrive_upload tool call."""
    ensure_authenticated()

    local_path = arguments.get("local_path", "")
    folder_id = arguments.get("folder_id")
    name = arguments.get("name")
    convert = arguments.get("convert_to_google", False)

    if not local_path:
        return [TextContent(type="text", text="Please provide local_path.")]

    result = upload_file(local_path, folder_id, name, convert_to_google=convert)
    
    if result:
        lines = [
            "✅ File uploaded successfully!\n",
            f"Name: {result['name']}",
            f"ID: {result['id']}",
            f"Type: {result['type']}",
        ]
        if result['web_link']:
            lines.append(f"URL: {result['web_link']}")
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Upload failed")]


async def handle_gdrive_create_folder(arguments: dict) -> list[TextContent]:
    """Handle gdrive_create_folder tool call."""
    ensure_authenticated()

    name = arguments.get("name", "")
    parent_id = arguments.get("parent_id")

    if not name:
        return [TextContent(type="text", text="Please provide a folder name.")]

    result = create_folder(name, parent_id)
    
    if result:
        lines = [
            "✅ Folder created!\n",
            f"Name: {result['name']}",
            f"ID: {result['id']}",
        ]
        if result['web_link']:
            lines.append(f"URL: {result['web_link']}")
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to create folder")]


async def handle_gdrive_move(arguments: dict) -> list[TextContent]:
    """Handle gdrive_move tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    new_parent_id = arguments.get("new_parent_id", "")

    if not file_id or not new_parent_id:
        return [TextContent(type="text", text="Please provide file_id and new_parent_id.")]

    result = move_file(file_id, new_parent_id)
    
    if result:
        return [TextContent(type="text", text=f"✅ Moved {result['name']} to new folder")]
    else:
        return [TextContent(type="text", text="❌ Move failed")]


async def handle_gdrive_copy(arguments: dict) -> list[TextContent]:
    """Handle gdrive_copy tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    new_name = arguments.get("new_name")
    folder_id = arguments.get("folder_id")

    if not file_id:
        return [TextContent(type="text", text="Please provide file_id.")]

    result = copy_file(file_id, new_name, folder_id)
    
    if result:
        lines = [
            "✅ File copied!\n",
            f"Name: {result['name']}",
            f"ID: {result['id']}",
        ]
        if result['web_link']:
            lines.append(f"URL: {result['web_link']}")
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Copy failed")]


async def handle_gdrive_delete(arguments: dict) -> list[TextContent]:
    """Handle gdrive_delete tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    permanent = arguments.get("permanent", False)

    if not file_id:
        return [TextContent(type="text", text="Please provide file_id.")]

    if delete_file(file_id, permanent):
        action = "permanently deleted" if permanent else "moved to trash"
        return [TextContent(type="text", text=f"✅ File {action}")]
    else:
        return [TextContent(type="text", text="❌ Delete failed")]


async def handle_gdrive_share(arguments: dict) -> list[TextContent]:
    """Handle gdrive_share tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    email = arguments.get("email", "")
    role = arguments.get("role", "reader")
    message = arguments.get("message")

    if not file_id or not email:
        return [TextContent(type="text", text="Please provide file_id and email.")]

    if share_file(file_id, email, role, message=message):
        return [TextContent(type="text", text=f"✅ Shared with {email} as {role}")]
    else:
        return [TextContent(type="text", text="❌ Share failed")]


async def handle_gdrive_get_link(arguments: dict) -> list[TextContent]:
    """Handle gdrive_get_link tool call."""
    ensure_authenticated()

    file_id = arguments.get("file_id", "")
    anyone_with_link = arguments.get("anyone_with_link", False)

    if not file_id:
        return [TextContent(type="text", text="Please provide file_id.")]

    link = get_share_link(file_id, anyone_with_link)
    
    if link:
        access = "Anyone with the link" if anyone_with_link else "Current permissions"
        return [TextContent(type="text", text=f"🔗 Share link ({access}):\n{link}")]
    else:
        return [TextContent(type="text", text="❌ Failed to get share link")]


# =============================================================================
# Docs Handlers
# =============================================================================

async def handle_gdocs_create(arguments: dict) -> list[TextContent]:
    """Handle gdocs_create tool call."""
    ensure_authenticated()

    title = arguments.get("title", "")
    content = arguments.get("content")
    content_type = arguments.get("content_type", "markdown")
    folder_id = arguments.get("folder_id")

    if not title:
        return [TextContent(type="text", text="Please provide a title.")]

    result = create_doc(title, content, content_type, folder_id)
    
    if result:
        lines = [
            "✅ Document created!\n",
            f"Title: {result['title']}",
            f"ID: {result['id']}",
            f"URL: {result['url']}",
        ]
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to create document")]


async def handle_gdocs_create_from_file(arguments: dict) -> list[TextContent]:
    """Handle gdocs_create_from_file tool call."""
    ensure_authenticated()

    file_path = arguments.get("file_path", "")
    title = arguments.get("title")
    folder_id = arguments.get("folder_id")

    if not file_path:
        return [TextContent(type="text", text="Please provide file_path.")]

    result = create_doc_from_file(file_path, title, folder_id)
    
    if result:
        lines = [
            "✅ Document created from file!\n",
            f"Title: {result['title']}",
            f"ID: {result['id']}",
            f"URL: {result['url']}",
        ]
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to create document")]


async def handle_gdocs_read(arguments: dict) -> list[TextContent]:
    """Handle gdocs_read tool call."""
    ensure_authenticated()

    doc_id = arguments.get("doc_id", "")
    if not doc_id:
        return [TextContent(type="text", text="Please provide doc_id.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id}")]
    
    actual_doc_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n"

    result = read_doc(actual_doc_id)
    
    if result:
        max_chars = 50000
        lines = [
            shortcut_note,
            f"📄 {result['title']}\n",
            f"ID: {result['id']}",
            f"URL: {result['url']}",
            "\n--- Content ---\n",
            result['text'][:max_chars] if len(result['text']) > max_chars else result['text']
        ]
        if len(result['text']) > max_chars:
            lines.append(f"\n\n... (truncated - {len(result['text']) - max_chars} more characters)")
            lines.append(f"💡 Document exceeds {max_chars:,} chars. Use gdocs_export to download the full document locally.")
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to read document")]


async def handle_gdocs_read_markdown(arguments: dict) -> list[TextContent]:
    """Handle gdocs_read_markdown tool call."""
    ensure_authenticated()

    doc_id = arguments.get("doc_id", "")
    if not doc_id:
        return [TextContent(type="text", text="Please provide doc_id.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id}")]
    
    actual_doc_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n\n"

    result = read_doc_as_markdown(actual_doc_id)
    
    if result:
        max_chars = 50000
        content = result[:max_chars] if len(result) > max_chars else result
        text = f"{shortcut_note}📄 Document as Markdown:\n\n{content}"
        if len(result) > max_chars:
            text += f"\n\n... (truncated - {len(result) - max_chars} more characters)"
            text += f"\n💡 Document exceeds {max_chars:,} chars. Use gdocs_export to download the full document locally."
        return [TextContent(type="text", text=text)]
    else:
        return [TextContent(type="text", text="❌ Failed to read document")]


async def handle_gdocs_export(arguments: dict) -> list[TextContent]:
    """Handle gdocs_export tool call."""
    ensure_authenticated()

    doc_id = arguments.get("doc_id", "")
    local_path = arguments.get("local_path", "")
    format = arguments.get("format", "pdf")

    if not doc_id or not local_path:
        return [TextContent(type="text", text="Please provide doc_id and local_path.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id}")]
    
    actual_doc_id = shortcut_info['target_id']

    result = export_doc(actual_doc_id, local_path, format)
    
    if result:
        return [TextContent(type="text", text=f"✅ Exported to: {result}")]
    else:
        return [TextContent(type="text", text="❌ Export failed")]


async def handle_gdocs_append(arguments: dict) -> list[TextContent]:
    """Handle gdocs_append tool call."""
    ensure_authenticated()

    doc_id = arguments.get("doc_id", "")
    content = arguments.get("content", "")
    content_type = arguments.get("content_type", "markdown")
    tab_id = arguments.get("tab_id")

    if not doc_id or not content:
        return [TextContent(type="text", text="Please provide doc_id and content.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id}")]

    actual_doc_id = shortcut_info['target_id']

    if append_to_doc(actual_doc_id, content, content_type, tab_id=tab_id):
        if tab_id:
            return [TextContent(type="text", text=f"✅ Content appended to tab {tab_id}")]
        else:
            return [TextContent(type="text", text="✅ Content appended to document")]
    else:
        # Enhanced error message with suggestion to check tab IDs
        error_msg = "❌ Failed to append content"
        if tab_id:
            error_msg += f"\n\nTab '{tab_id}' not found. Tab IDs can change when tabs are modified."
            error_msg += f"\nUse gdocs_list_tabs to get current tab IDs for document {actual_doc_id[:20]}..."
        return [TextContent(type="text", text=error_msg)]


async def handle_gdocs_list_tabs(arguments: dict) -> list[TextContent]:
    """Handle gdocs_list_tabs tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    include_children = arguments.get("include_children", True)

    if not doc_id_or_url:
        return [TextContent(type="text", text="Please provide doc_id_or_url.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    
    actual_doc_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n"

    tabs = list_tabs(actual_doc_id, include_children)
    
    if tabs is None:
        return [TextContent(type="text", text="❌ Failed to list tabs")]

    if not tabs:
        return [TextContent(type="text", text="No tabs found in document.")]

    lines = [shortcut_note, f"📑 Tabs in document ({len(tabs)} total):\n"]
    
    for tab in tabs:
        indent = "  " * (1 if tab['parent_tab_id'] else 0)
        icon = "📄" if tab['is_document_tab'] else "📋"
        parent_info = f" (child of {tab['parent_tab_id']})" if tab['parent_tab_id'] else ""
        
        lines.append(f"{indent}{icon} {tab['title']}")
        if tab['tab_id']:
            lines.append(f"{indent}   ID: {tab['tab_id']}")
        lines.append(f"{indent}   Index: {tab['index']}{parent_info}")
        lines.append("")

    return [TextContent(type="text", text="\n".join(lines))]


async def handle_gdocs_read_tab(arguments: dict) -> list[TextContent]:
    """Handle gdocs_read_tab tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    tab_id = arguments.get("tab_id")
    tab_index = arguments.get("tab_index", 0)

    if not doc_id_or_url:
        return [TextContent(type="text", text="Please provide doc_id_or_url.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    
    actual_doc_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n"

    result = read_tab(actual_doc_id, tab_id=tab_id, tab_index=tab_index)
    
    if result:
        max_chars = 50000
        lines = [
            shortcut_note,
            f"📄 {result['title']} - {result['tab_title']}\n",
            f"Document ID: {result['id']}",
            f"Tab ID: {result['tab_id'] or 'N/A'}",
            f"Tab Index: {result['tab_index']}",
            f"URL: {result['url']}",
            "\n--- Tab Content ---\n",
            result['text'][:max_chars] if len(result['text']) > max_chars else result['text']
        ]
        if len(result['text']) > max_chars:
            lines.append(f"\n\n... (truncated - {len(result['text']) - max_chars} more characters)")
            lines.append(f"💡 Tab exceeds {max_chars:,} chars. Use gdocs_export_tab to download the full content.")
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to read tab")]


async def handle_gdocs_read_tab_markdown(arguments: dict) -> list[TextContent]:
    """Handle gdocs_read_tab_markdown tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    tab_id = arguments.get("tab_id")
    tab_index = arguments.get("tab_index", 0)

    if not doc_id_or_url:
        return [TextContent(type="text", text="Please provide doc_id_or_url.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    
    actual_doc_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n\n"

    result = read_tab_as_markdown(actual_doc_id, tab_id=tab_id, tab_index=tab_index)
    
    if result:
        max_chars = 50000
        content = result[:max_chars] if len(result) > max_chars else result
        text = f"{shortcut_note}📄 Tab Content as Markdown:\n\n{content}"
        if len(result) > max_chars:
            text += f"\n\n... (truncated - {len(result) - max_chars} more characters)"
            text += f"\n💡 Tab exceeds {max_chars:,} chars. Use gdocs_export_tab to download the full content."
        return [TextContent(type="text", text=text)]
    else:
        return [TextContent(type="text", text="❌ Failed to read tab as markdown")]


async def handle_gdocs_export_tab(arguments: dict) -> list[TextContent]:
    """Handle gdocs_export_tab tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    tab_id = arguments.get("tab_id")
    local_path = arguments.get("local_path", "")
    format = arguments.get("format", "pdf")

    if not doc_id_or_url or not local_path:
        return [TextContent(type="text", text="Please provide doc_id_or_url and local_path.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    
    actual_doc_id = shortcut_info['target_id']

    result = export_tab(actual_doc_id, tab_id=tab_id, local_path=local_path, format=format)
    
    if result:
        return [TextContent(type="text", text=f"✅ Exported tab to: {result}")]
    else:
        return [TextContent(type="text", text="❌ Export failed")]


async def handle_gdocs_create_tab(arguments: dict) -> list[TextContent]:
    """Handle gdocs_create_tab tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    title = arguments.get("title", "")
    index = arguments.get("index")
    parent_tab_id = arguments.get("parent_tab_id")
    icon_emoji = arguments.get("icon_emoji")

    if not doc_id_or_url or not title:
        return [TextContent(type="text", text="Please provide doc_id_or_url and title.")]

    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    actual_doc_id = shortcut_info["target_id"]

    result = create_tab(
        actual_doc_id,
        title=title,
        index=index,
        parent_tab_id=parent_tab_id,
        icon_emoji=icon_emoji,
    )
    if result:
        lines = [f"✅ Created tab: {title}", f"Document: {result.get('url', '')}"]
        if result.get("tab_id"):
            lines.append(f"Tab ID: {result['tab_id']}")
        return [TextContent(type="text", text="\n".join(lines))]
    return [TextContent(type="text", text="❌ Failed to create tab")]


async def handle_gdocs_update_tab(arguments: dict) -> list[TextContent]:
    """Handle gdocs_update_tab tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    tab_id = arguments.get("tab_id")
    title = arguments.get("title")
    icon_emoji = arguments.get("icon_emoji")

    if not doc_id_or_url or not tab_id:
        return [TextContent(type="text", text="Please provide doc_id_or_url and tab_id.")]
    if title is None and icon_emoji is None:
        return [TextContent(type="text", text="Please provide at least one of title or icon_emoji.")]

    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    actual_doc_id = shortcut_info["target_id"]

    result = update_tab(actual_doc_id, tab_id=tab_id, title=title, icon_emoji=icon_emoji)
    if result:
        return [TextContent(type="text", text=f"✅ Updated tab: {tab_id}")]
    return [TextContent(type="text", text="❌ Failed to update tab")]


async def handle_gdocs_delete_tab(arguments: dict) -> list[TextContent]:
    """Handle gdocs_delete_tab tool call."""
    ensure_authenticated()

    doc_id_or_url = arguments.get("doc_id_or_url") or arguments.get("doc_id", "")
    tab_id = arguments.get("tab_id")

    if not doc_id_or_url or not tab_id:
        return [TextContent(type="text", text="Please provide doc_id_or_url and tab_id.")]

    shortcut_info = resolve_shortcut(doc_id_or_url)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id_or_url}")]
    actual_doc_id = shortcut_info["target_id"]

    result = delete_tab(actual_doc_id, tab_id=tab_id)
    if result:
        return [TextContent(type="text", text=f"✅ Deleted tab: {tab_id}")]
    return [TextContent(type="text", text="❌ Failed to delete tab")]


async def handle_gdocs_insert(arguments: dict) -> list[TextContent]:
    """Handle gdocs_insert tool call."""
    ensure_authenticated()

    doc_id = arguments.get("doc_id", "")
    content = arguments.get("content", "")
    content_type = arguments.get("content_type", "markdown")
    tab_id = arguments.get("tab_id")
    index = arguments.get("index")
    search_text = arguments.get("search_text")
    heading = arguments.get("heading")
    position = arguments.get("position", "after")

    if not doc_id or not content:
        return [TextContent(type="text", text="Please provide doc_id and content.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(doc_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {doc_id}")]
    
    actual_doc_id = shortcut_info['target_id']

    if insert_content_at(
        actual_doc_id, 
        content, 
        content_type,
        tab_id=tab_id,
        index=index,
        search_text=search_text,
        heading=heading,
        position=position
    ):
        # Build descriptive success message
        location_parts = []
        if index is not None:
            location_parts.append(f"at index {index}")
        elif search_text:
            location_parts.append(f"{position} '{search_text}'")
        elif heading:
            location_parts.append(f"{position} heading '{heading}'")
        else:
            location_parts.append("at start")
        
        if tab_id:
            location_parts.append(f"in tab {tab_id}")
        
        return [TextContent(type="text", text=f"✅ Content inserted {' '.join(location_parts)}")]
    else:
        return [TextContent(type="text", text="❌ Failed to insert content")]


# =============================================================================
# Sheets Handlers
# =============================================================================

async def handle_gsheets_create(arguments: dict) -> list[TextContent]:
    """Handle gsheets_create tool call."""
    ensure_authenticated()

    title = arguments.get("title", "")
    sheet_names = arguments.get("sheet_names")
    folder_id = arguments.get("folder_id")

    if not title:
        return [TextContent(type="text", text="Please provide a title.")]

    result = create_spreadsheet(title, sheet_names, folder_id)
    
    if result:
        lines = [
            "✅ Spreadsheet created!\n",
            f"Title: {result['title']}",
            f"ID: {result['id']}",
            f"URL: {result['url']}",
            f"\nSheets: {', '.join(s['title'] for s in result['sheets'])}"
        ]
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to create spreadsheet")]


async def handle_gsheets_read(arguments: dict) -> list[TextContent]:
    """Handle gsheets_read tool call."""
    ensure_authenticated()

    spreadsheet_id = arguments.get("spreadsheet_id", "")
    range_notation = arguments.get("range", "")

    if not spreadsheet_id or not range_notation:
        return [TextContent(type="text", text="Please provide spreadsheet_id and range.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(spreadsheet_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {spreadsheet_id}")]
    
    actual_spreadsheet_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n"

    values = read_range(actual_spreadsheet_id, range_notation)
    
    if values is not None:
        if not values:
            return [TextContent(type="text", text=f"Range {range_notation} is empty")]
        
        # Format as table
        lines = [shortcut_note, f"📊 Data from {range_notation}:\n"]
        for row in values[:50]:  # Limit display
            lines.append("| " + " | ".join(str(cell) for cell in row) + " |")
        
        if len(values) > 50:
            lines.append(f"\n... ({len(values) - 50} more rows)")
        
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to read range")]


async def handle_gsheets_write(arguments: dict) -> list[TextContent]:
    """Handle gsheets_write tool call."""
    ensure_authenticated()

    spreadsheet_id = arguments.get("spreadsheet_id", "")
    range_notation = arguments.get("range", "")
    values = arguments.get("values", [])

    if not spreadsheet_id or not range_notation or not values:
        return [TextContent(type="text", text="Please provide spreadsheet_id, range, and values.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(spreadsheet_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {spreadsheet_id}")]
    
    actual_spreadsheet_id = shortcut_info['target_id']

    if write_range(actual_spreadsheet_id, range_notation, values):
        return [TextContent(type="text", text=f"✅ Data written to {range_notation}")]
    else:
        return [TextContent(type="text", text="❌ Failed to write data")]


async def handle_gsheets_append(arguments: dict) -> list[TextContent]:
    """Handle gsheets_append tool call."""
    ensure_authenticated()

    spreadsheet_id = arguments.get("spreadsheet_id", "")
    sheet_name = arguments.get("sheet_name", "")
    rows = arguments.get("rows", [])

    if not spreadsheet_id or not sheet_name or not rows:
        return [TextContent(type="text", text="Please provide spreadsheet_id, sheet_name, and rows.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(spreadsheet_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {spreadsheet_id}")]
    
    actual_spreadsheet_id = shortcut_info['target_id']

    if append_rows(actual_spreadsheet_id, sheet_name, rows):
        return [TextContent(type="text", text=f"✅ Appended {len(rows)} rows to {sheet_name}")]
    else:
        return [TextContent(type="text", text="❌ Failed to append rows")]


async def handle_gsheets_info(arguments: dict) -> list[TextContent]:
    """Handle gsheets_info tool call."""
    ensure_authenticated()

    spreadsheet_id = arguments.get("spreadsheet_id", "")
    if not spreadsheet_id:
        return [TextContent(type="text", text="Please provide spreadsheet_id.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(spreadsheet_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {spreadsheet_id}")]
    
    actual_spreadsheet_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n"

    info = get_spreadsheet_info(actual_spreadsheet_id)
    
    if info:
        lines = [
            shortcut_note,
            f"📊 {info['title']}\n",
            f"ID: {info['id']}",
            f"URL: {info['url']}",
            f"\nSheets ({len(info['sheets'])}):"
        ]
        
        for sheet in info['sheets']:
            lines.append(f"  • {sheet['title']} ({sheet['row_count']} rows × {sheet['column_count']} cols)")
        
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to get spreadsheet info")]


async def handle_gsheets_export_csv(arguments: dict) -> list[TextContent]:
    """Handle gsheets_export_csv tool call."""
    ensure_authenticated()

    spreadsheet_id = arguments.get("spreadsheet_id", "")
    sheet_name = arguments.get("sheet_name", "")
    local_path = arguments.get("local_path", "")

    if not spreadsheet_id or not sheet_name or not local_path:
        return [TextContent(type="text", text="Please provide spreadsheet_id, sheet_name, and local_path.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(spreadsheet_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {spreadsheet_id}")]
    
    actual_spreadsheet_id = shortcut_info['target_id']

    result = export_csv(actual_spreadsheet_id, sheet_name, local_path)
    
    if result:
        return [TextContent(type="text", text=f"✅ Exported to: {result}")]
    else:
        return [TextContent(type="text", text="❌ Export failed")]


async def handle_gsheets_import_csv(arguments: dict) -> list[TextContent]:
    """Handle gsheets_import_csv tool call."""
    ensure_authenticated()

    spreadsheet_id = arguments.get("spreadsheet_id", "")
    sheet_name = arguments.get("sheet_name", "")
    csv_path = arguments.get("csv_path", "")
    start_cell = arguments.get("start_cell", "A1")

    if not spreadsheet_id or not sheet_name or not csv_path:
        return [TextContent(type="text", text="Please provide spreadsheet_id, sheet_name, and csv_path.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(spreadsheet_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {spreadsheet_id}")]
    
    actual_spreadsheet_id = shortcut_info['target_id']

    if import_csv(actual_spreadsheet_id, sheet_name, csv_path, start_cell):
        return [TextContent(type="text", text=f"✅ Imported CSV to {sheet_name}")]
    else:
        return [TextContent(type="text", text="❌ Import failed")]


# =============================================================================
# Slides Handlers
# =============================================================================

async def handle_gslides_create(arguments: dict) -> list[TextContent]:
    """Handle gslides_create tool call."""
    ensure_authenticated()

    title = arguments.get("title", "")
    folder_id = arguments.get("folder_id")

    if not title:
        return [TextContent(type="text", text="Please provide a title.")]

    result = create_presentation(title, folder_id)
    
    if result:
        lines = [
            "✅ Presentation created!\n",
            f"Title: {result['title']}",
            f"ID: {result['id']}",
            f"URL: {result['url']}",
        ]
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to create presentation")]


async def handle_gslides_read(arguments: dict) -> list[TextContent]:
    """Handle gslides_read tool call."""
    ensure_authenticated()

    presentation_id = arguments.get("presentation_id", "")
    if not presentation_id:
        return [TextContent(type="text", text="Please provide presentation_id.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(presentation_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {presentation_id}")]
    
    actual_presentation_id = shortcut_info['target_id']
    shortcut_note = ""
    if shortcut_info['is_shortcut']:
        shortcut_note = f"📎 (Shortcut: {shortcut_info['shortcut_name']})\n\n"

    info = get_presentation(actual_presentation_id)
    
    if info:
        lines = [
            shortcut_note,
            f"📽️ {info['title']}\n",
            f"ID: {info['id']}",
            f"URL: {info['url']}",
            f"Slides: {info['slide_count']}",
        ]
        
        # Include detailed slide content
        for slide in info.get('slides', []):
            lines.append(f"\n--- Slide {slide['index'] + 1} (ID: {slide['slide_id']}) ---")
            
            # Extract text content from elements
            text_elements = []
            for elem in slide.get('elements', []):
                if elem.get('text'):
                    text_elements.append(f"  [{elem['type']}] {elem['text']}")
                elif elem['type'] not in ('IMAGE', 'VIDEO', 'LINE'):
                    # Show non-text elements without content
                    text_elements.append(f"  [{elem['type']}] (no text)")
            
            if text_elements:
                lines.extend(text_elements)
            else:
                lines.append("  (empty slide)")
        
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to get presentation info")]


async def handle_gslides_add_slide(arguments: dict) -> list[TextContent]:
    """Handle gslides_add_slide tool call."""
    ensure_authenticated()

    presentation_id = arguments.get("presentation_id", "")
    layout = arguments.get("layout", "blank")
    index = arguments.get("index")

    if not presentation_id:
        return [TextContent(type="text", text="Please provide presentation_id.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(presentation_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {presentation_id}")]
    
    actual_presentation_id = shortcut_info['target_id']

    result = add_slide(actual_presentation_id, layout, index)
    
    if result:
        lines = [
            "✅ Slide added!\n",
            f"Slide ID: {result['slide_id']}",
            f"Layout: {result['layout']}",
        ]
        return [TextContent(type="text", text="\n".join(lines))]
    else:
        return [TextContent(type="text", text="❌ Failed to add slide")]


async def handle_gslides_add_text(arguments: dict) -> list[TextContent]:
    """Handle gslides_add_text tool call."""
    ensure_authenticated()

    presentation_id = arguments.get("presentation_id", "")
    slide_id = arguments.get("slide_id", "")
    text = arguments.get("text", "")
    x = arguments.get("x", 100)
    y = arguments.get("y", 100)
    width = arguments.get("width", 300)
    height = arguments.get("height", 100)

    if not presentation_id or not slide_id or not text:
        return [TextContent(type="text", text="Please provide presentation_id, slide_id, and text.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(presentation_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {presentation_id}")]
    
    actual_presentation_id = shortcut_info['target_id']

    result = add_text_box(actual_presentation_id, slide_id, text, x, y, width, height)
    
    if result:
        return [TextContent(type="text", text=f"✅ Text box added: {result}")]
    else:
        return [TextContent(type="text", text="❌ Failed to add text box")]


async def handle_gslides_export_pdf(arguments: dict) -> list[TextContent]:
    """Handle gslides_export_pdf tool call."""
    ensure_authenticated()

    presentation_id = arguments.get("presentation_id", "")
    local_path = arguments.get("local_path", "")

    if not presentation_id or not local_path:
        return [TextContent(type="text", text="Please provide presentation_id and local_path.")]

    # Resolve shortcut if necessary
    shortcut_info = resolve_shortcut(presentation_id)
    if shortcut_info is None:
        return [TextContent(type="text", text=f"❌ Failed to access file: {presentation_id}")]
    
    actual_presentation_id = shortcut_info['target_id']

    result = slides_export_pdf(actual_presentation_id, local_path)
    
    if result:
        return [TextContent(type="text", text=f"✅ Exported to: {result}")]
    else:
        return [TextContent(type="text", text="❌ Export failed")]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

