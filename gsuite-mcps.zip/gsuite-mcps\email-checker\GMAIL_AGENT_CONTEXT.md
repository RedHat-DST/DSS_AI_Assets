# Gmail Agent Implementation Context

**Purpose:** This document provides comprehensive implementation context for building an AI email agent with Gmail integration. It captures authentication patterns, email operations, and advanced email-to-data correlation strategies that can be re-implemented in other projects.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Authentication System](#authentication-system)
3. [Gmail Operations API](#gmail-operations-api)
4. [Email Correlation Engine](#email-correlation-engine)
5. [Integration Patterns](#integration-patterns)
6. [Configuration Requirements](#configuration-requirements)
7. [Complete Code Reference](#complete-code-reference)

---

## Architecture Overview

### Component Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Gmail Agent System                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐     ┌─────────────────┐     ┌───────────────┐ │
│  │  Authentication │     │ Gmail Operations│     │Token Manager  │ │
│  │     Module      │────▶│     Module      │◀────│    Module     │ │
│  │                 │     │                 │     │               │ │
│  │ • OAuth 2.0     │     │ • Search        │     │ • Persistence │ │
│  │ • Desktop flow  │     │ • Read          │     │ • Refresh     │ │
│  │ • Container flow│     │ • Draft         │     │ • Validation  │ │
│  └─────────────────┘     └─────────────────┘     └───────────────┘ │
│           │                       │                                 │
│           │                       ▼                                 │
│           │              ┌─────────────────┐                       │
│           │              │ Email Correlator│                       │
│           │              │     Engine      │                       │
│           │              │                 │                       │
│           │              │ • Search emails │                       │
│           │              │ • Match to goals│                       │
│           │              │ • Score matches │                       │
│           │              │ • Cluster topics│                       │
│           │              └─────────────────┘                       │
│           │                       │                                 │
│           ▼                       ▼                                 │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Google Gmail API                          │   │
│  │  • gmail.readonly scope                                      │   │
│  │  • users.messages.list / get                                │   │
│  │  • users.getProfile                                          │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Data Flow

```
User Request
     │
     ▼
┌────────────┐    ┌─────────────┐    ┌──────────────┐
│ Check Token│───▶│ Load/Refresh│───▶│ Build Gmail  │
│   Status   │    │    Token    │    │   Service    │
└────────────┘    └─────────────┘    └──────────────┘
                                            │
     ┌──────────────────────────────────────┘
     │
     ▼
┌────────────┐    ┌─────────────┐    ┌──────────────┐
│  Execute   │───▶│   Process   │───▶│   Return     │
│Gmail Query │    │  Results    │    │   Data       │
└────────────┘    └─────────────┘    └──────────────┘
                        │
                        ▼ (optional)
               ┌─────────────────┐
               │ Email Correlation│
               │  & Analysis      │
               └─────────────────┘
```

---

## Authentication System

### OAuth 2.0 Scopes

```python
SCOPES = [
    'https://www.googleapis.com/auth/drive',           # Full Drive access
    'https://www.googleapis.com/auth/drive.file',      # File-level access
    'https://www.googleapis.com/auth/drive.readonly',  # Read-only Drive
    'https://www.googleapis.com/auth/gmail.readonly'   # Gmail read-only (key for email agent)
]
```

### Core Authentication Class

```python
"""
Google OAuth 2.0 Authentication Handler

This class manages the complete OAuth lifecycle:
- Initial authorization flow (desktop or container)
- Token persistence and refresh
- Service building for Gmail API
"""

import os
import json
from pathlib import Path
from typing import Optional

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build


class GoogleDriveAuth:
    """Handles Google OAuth 2.0 authentication for Gmail and Drive APIs."""

    SCOPES = [
        'https://www.googleapis.com/auth/drive',
        'https://www.googleapis.com/auth/drive.file',
        'https://www.googleapis.com/auth/drive.readonly',
        'https://www.googleapis.com/auth/gmail.readonly'
    ]

    def __init__(self, credentials_file: str = "credentials.json", token_file: str = "gdrive_token.json"):
        """
        Initialize authentication handler.

        Args:
            credentials_file: Path to OAuth client credentials (from Google Cloud Console)
            token_file: Path to store/load user authorization tokens
        """
        self.credentials_file = Path(credentials_file)
        self.token_file = Path(token_file)
        self.credentials: Optional[Credentials] = None
        self.service = None

    def authenticate(self) -> bool:
        """
        Authenticate with Google APIs.

        Flow:
        1. Check for existing token file
        2. Load and validate credentials
        3. Refresh if expired (with refresh_token)
        4. Start OAuth flow if no valid credentials

        Returns:
            True if authentication successful, False otherwise
        """
        try:
            # Check credentials.json exists
            if not self.credentials_file.exists():
                print(f"❌ credentials.json not found: {self.credentials_file}")
                return False

            # Load existing token
            if self.token_file.exists():
                try:
                    self.credentials = Credentials.from_authorized_user_file(
                        str(self.token_file), self.SCOPES
                    )
                except Exception as e:
                    self.credentials = None

            # Refresh if expired
            if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                try:
                    self.credentials.refresh(Request())
                except Exception:
                    self.credentials = None

            # Start OAuth flow if needed
            if not self.credentials or not self.credentials.valid:
                if not self._start_oauth_flow():
                    return False

            # Save token for future use
            self._save_token()
            return True

        except Exception as e:
            print(f"❌ Authentication failed: {e}")
            return False

    def _start_oauth_flow(self) -> bool:
        """Start OAuth 2.0 authorization flow."""
        # Prevent automatic browser opening in containers
        os.environ['BROWSER'] = ''

        flow = InstalledAppFlow.from_client_secrets_file(
            str(self.credentials_file), self.SCOPES
        )

        # Detect environment
        in_container = (
            os.path.exists('/.dockerenv') or
            os.environ.get('HOSTNAME') == 'aimt' or
            os.path.exists('/workspace')
        )

        if in_container:
            return self._container_oauth_flow(flow)
        else:
            return self._desktop_oauth_flow(flow)

    def _desktop_oauth_flow(self, flow) -> bool:
        """OAuth flow for desktop environments with browser support."""
        import http.server
        import socketserver
        import webbrowser
        from urllib.parse import urlparse, parse_qs

        port = 8081  # Standard OAuth callback port

        # Set redirect URI
        flow.redirect_uri = f'http://localhost:{port}/'
        auth_url, state = flow.authorization_url(prompt='select_account')

        # Open browser
        webbrowser.open(auth_url)

        # Set up callback handler
        callback_result = {'done': False, 'code': None, 'error': None}

        class CallbackHandler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass  # Suppress logs

            def do_GET(self):
                parsed = urlparse(self.path)
                query_params = parse_qs(parsed.query)

                if 'code' in query_params:
                    callback_result['code'] = query_params['code'][0]
                    callback_result['done'] = True
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(b'<html><body><h1>Authentication successful!</h1></body></html>')
                elif 'error' in query_params:
                    callback_result['error'] = query_params['error'][0]
                    callback_result['done'] = True
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(b'<html><body><h1>Authentication failed</h1></body></html>')

        # Start server and wait for callback
        with socketserver.TCPServer(("", port), CallbackHandler) as httpd:
            import time
            timeout = 180  # 3 minutes
            start_time = time.time()

            while not callback_result['done']:
                httpd.handle_request()
                if time.time() - start_time > timeout:
                    return False

        # Exchange code for token
        if callback_result['code']:
            flow.fetch_token(code=callback_result['code'])
            self.credentials = flow.credentials
            return True

        return False

    def _container_oauth_flow(self, flow) -> bool:
        """OAuth flow for container environments without browser."""
        import http.server
        import socketserver
        import threading
        from urllib.parse import urlparse, parse_qs

        callback_port = 8081
        callback_result = {'code': None, 'error': None, 'done': False}

        class OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                query_params = parse_qs(parsed.query)

                if 'code' in query_params:
                    callback_result['code'] = query_params['code'][0]
                    callback_result['done'] = True
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(b'<html><body><h1>Authorized!</h1></body></html>')
                elif 'error' in query_params:
                    callback_result['error'] = query_params['error'][0]
                    callback_result['done'] = True
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(b'<html><body><h1>Authorization Failed</h1></body></html>')

            def log_message(self, format, *args):
                pass

        # Start callback server
        server = socketserver.TCPServer(("", callback_port), OAuthCallbackHandler)
        server_thread = threading.Thread(target=server.serve_forever)
        server_thread.daemon = True
        server_thread.start()

        # Generate and display authorization URL
        flow.redirect_uri = f'http://127.0.0.1:{callback_port}'
        auth_url, _ = flow.authorization_url(prompt='select_account')

        print("=" * 60)
        print("GOOGLE AUTHORIZATION REQUIRED")
        print("=" * 60)
        print(f"\nClick this URL to authorize:\n\n{auth_url}\n")

        # Wait for authorization (3 minutes max)
        import time
        timeout = 180
        elapsed = 0

        while elapsed < timeout and not callback_result['done']:
            time.sleep(1)
            elapsed += 1

        server.shutdown()
        server.server_close()

        if callback_result['code']:
            flow.fetch_token(code=callback_result['code'])
            self.credentials = flow.credentials
            return True

        return False

    def _save_token(self):
        """Save credentials to token file with secure permissions."""
        try:
            with open(self.token_file, 'w') as token:
                token.write(self.credentials.to_json())
            self.token_file.chmod(0o600)  # Secure permissions
        except Exception as e:
            print(f"⚠️ Failed to save token: {e}")

    def get_gmail_service(self):
        """Get authenticated Gmail API service."""
        if not self.credentials or not self.credentials.valid:
            if not self.authenticate():
                raise RuntimeError("Failed to authenticate")
        return build('gmail', 'v1', credentials=self.credentials)

    def is_authenticated(self) -> bool:
        """Check if currently authenticated."""
        return self.credentials is not None and self.credentials.valid
```

### Token Manager (Advanced Token Handling)

```python
"""
Token Management with Automatic Refresh

Features:
- Persistent storage (pickle + JSON backup)
- Automatic refresh before expiry (5-minute buffer)
- Token validation and status reporting
"""

import json
import pickle
import time
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request


@dataclass
class GoogleTokenData:
    """Stored Google token data with metadata."""
    access_token: str
    refresh_token: Optional[str] = None
    token_uri: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    scopes: Optional[list] = None
    expires_at: Optional[float] = None
    user_info: Optional[Dict[str, Any]] = None

    def to_credentials(self) -> Credentials:
        """Convert to Google Credentials object."""
        return Credentials(
            token=self.access_token,
            refresh_token=self.refresh_token,
            token_uri=self.token_uri,
            client_id=self.client_id,
            client_secret=self.client_secret,
            scopes=self.scopes
        )

    @classmethod
    def from_credentials(cls, credentials: Credentials, user_info: Optional[Dict] = None) -> 'GoogleTokenData':
        """Create from Google Credentials object."""
        expires_at = None
        if hasattr(credentials, 'expiry') and credentials.expiry:
            expires_at = credentials.expiry.timestamp()

        return cls(
            access_token=credentials.token,
            refresh_token=credentials.refresh_token,
            token_uri=credentials.token_uri,
            client_id=credentials.client_id,
            client_secret=credentials.client_secret,
            scopes=credentials.scopes,
            expires_at=expires_at,
            user_info=user_info
        )


@dataclass
class TokenValidationResult:
    """Token validation result."""
    is_valid: bool
    is_expired: bool
    needs_refresh: bool
    expires_in: Optional[int] = None


class GoogleTokenManager:
    """Manages Google OAuth tokens with automatic refresh."""

    def __init__(self, token_dir: Optional[str] = None, auto_save: bool = True):
        self.auto_save = auto_save
        self.token_data: Optional[GoogleTokenData] = None

        if token_dir:
            self.token_dir = Path(token_dir)
        else:
            self.token_dir = Path.home() / '.ai-managers' / 'google-drive'

        self.token_dir.mkdir(parents=True, exist_ok=True)
        self.token_file = self.token_dir / 'oauth_token.pickle'
        self.json_backup = self.token_dir / 'token_backup.json'

    def get_credentials(self) -> Optional[Credentials]:
        """Get current credentials, refreshing if needed."""
        self._load_tokens_if_needed()

        if not self.token_data:
            return None

        credentials = self.token_data.to_credentials()

        # Check if refresh is needed (5 minutes before expiry)
        if self._needs_refresh(credentials):
            if self._refresh_credentials(credentials):
                self.token_data = GoogleTokenData.from_credentials(
                    credentials, self.token_data.user_info
                )
                if self.auto_save:
                    self._persist_tokens()

        return credentials if credentials.valid else None

    def validate_token(self) -> TokenValidationResult:
        """Validate current token status."""
        self._load_tokens_if_needed()

        if not self.token_data:
            return TokenValidationResult(is_valid=False, is_expired=False, needs_refresh=False)

        credentials = self.token_data.to_credentials()
        now = time.time()

        is_expired = False
        needs_refresh = False
        expires_in = None

        if credentials.expiry:
            expires_at = credentials.expiry.timestamp()
            is_expired = now >= expires_at
            needs_refresh = now >= (expires_at - 300)  # 5-minute buffer
            expires_in = max(0, int(expires_at - now))

        return TokenValidationResult(
            is_valid=credentials.valid and not is_expired,
            is_expired=is_expired,
            needs_refresh=needs_refresh and bool(credentials.refresh_token),
            expires_in=expires_in
        )

    def _needs_refresh(self, credentials: Credentials) -> bool:
        """Check if credentials need refreshing."""
        if not credentials.expiry:
            return False
        time_until_expiry = credentials.expiry.timestamp() - time.time()
        return time_until_expiry <= 300 and credentials.refresh_token is not None

    def _refresh_credentials(self, credentials: Credentials) -> bool:
        """Refresh the given credentials."""
        try:
            credentials.refresh(Request())
            return True
        except Exception:
            return False

    def _load_tokens_if_needed(self) -> None:
        """Load tokens from storage if not already loaded."""
        if self.token_data:
            return

        if self.token_file.exists():
            try:
                with open(self.token_file, 'rb') as f:
                    credentials = pickle.load(f)
                if isinstance(credentials, Credentials):
                    self.token_data = GoogleTokenData.from_credentials(credentials)
                    return
            except Exception:
                pass

        # Fallback to JSON backup
        if self.json_backup.exists():
            try:
                with open(self.json_backup, 'r') as f:
                    data = json.load(f)
                if isinstance(data, dict) and 'access_token' in data:
                    self.token_data = GoogleTokenData(**data)
            except Exception:
                pass

    def _persist_tokens(self) -> None:
        """Persist tokens to storage."""
        if not self.token_data:
            return

        try:
            # Save as pickle
            credentials = self.token_data.to_credentials()
            with open(self.token_file, 'wb') as f:
                pickle.dump(credentials, f)
            self.token_file.chmod(0o600)

            # Save JSON backup
            data = asdict(self.token_data)
            with open(self.json_backup, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            self.json_backup.chmod(0o600)
        except Exception:
            pass
```

---

## Gmail Operations API

### Core Gmail Functions

```python
"""
Gmail Operations Module

Provides high-level functions for Gmail interactions:
- Search emails with Gmail query syntax
- Read email content
- Create draft compose URLs
"""

import base64
import urllib.parse
from typing import Optional, List, Dict, Any
from googleapiclient.discovery import build


def search_gmail(
    gmail_service,
    query: str,
    max_results: int = 10
) -> List[Dict[str, Any]]:
    """
    Search Gmail messages using Gmail query syntax.

    Args:
        gmail_service: Authenticated Gmail API service
        query: Gmail search query (supports all Gmail operators)
        max_results: Maximum number of results to return

    Returns:
        List of message dictionaries with metadata

    Gmail Query Examples:
        "from:user@example.com"
        "subject:report after:2024/01/01"
        "has:attachment"
        "in:inbox is:unread"
        "label:important"
    """
    try:
        # Get message IDs matching query
        results = gmail_service.users().messages().list(
            userId='me',
            q=query,
            maxResults=max_results
        ).execute()

        message_ids = results.get('messages', [])

        if not message_ids:
            return []

        # Fetch details for each message
        messages = []
        for msg in message_ids:
            message = gmail_service.users().messages().get(
                userId='me',
                id=msg['id'],
                format='metadata',
                metadataHeaders=['From', 'Subject', 'Date', 'To', 'Cc']
            ).execute()

            # Extract headers
            headers = message.get('payload', {}).get('headers', [])
            msg_data = {
                'id': msg['id'],
                'subject': 'No Subject',
                'from': 'Unknown',
                'to': '',
                'cc': '',
                'date': 'Unknown',
                'labels': message.get('labelIds', []),
                'url': f"https://mail.google.com/mail/u/0/#inbox/{msg['id']}"
            }

            for header in headers:
                name = header.get('name', '').lower()
                value = header.get('value', '')
                if name == 'subject':
                    msg_data['subject'] = value
                elif name == 'from':
                    msg_data['from'] = value
                elif name == 'to':
                    msg_data['to'] = value
                elif name == 'cc':
                    msg_data['cc'] = value
                elif name == 'date':
                    msg_data['date'] = value

            messages.append(msg_data)

        return messages

    except Exception as e:
        print(f"Gmail search failed: {e}")
        return []


def inbox_search(
    gmail_service,
    query: str = "",
    max_results: int = 10
) -> List[Dict[str, Any]]:
    """
    Search inbox messages (convenience wrapper).

    Args:
        gmail_service: Authenticated Gmail API service
        query: Optional search query (in:inbox is automatically added)
        max_results: Maximum results

    Returns:
        List of inbox messages
    """
    full_query = f"{query} in:inbox" if query else "in:inbox"
    return search_gmail(gmail_service, full_query, max_results)


def read_email(
    gmail_service,
    message_id: str
) -> Optional[Dict[str, Any]]:
    """
    Read full email content by message ID.

    Args:
        gmail_service: Authenticated Gmail API service
        message_id: Gmail message ID

    Returns:
        Dictionary with email headers and body content
    """
    try:
        message = gmail_service.users().messages().get(
            userId='me',
            id=message_id,
            format='full'
        ).execute()

        # Extract headers
        headers = message.get('payload', {}).get('headers', [])
        result = {
            'id': message_id,
            'subject': 'No Subject',
            'from': 'Unknown',
            'to': 'Unknown',
            'cc': '',
            'date': 'Unknown',
            'body': '',
            'url': f"https://mail.google.com/mail/u/0/#inbox/{message_id}"
        }

        for header in headers:
            name = header.get('name', '').lower()
            value = header.get('value', '')
            if name == 'subject':
                result['subject'] = value
            elif name == 'from':
                result['from'] = value
            elif name == 'to':
                result['to'] = value
            elif name == 'cc':
                result['cc'] = value
            elif name == 'date':
                result['date'] = value

        # Extract body
        result['body'] = _extract_body(message['payload'])

        return result

    except Exception as e:
        print(f"Failed to read email: {e}")
        return None


def _extract_body(payload: Dict[str, Any]) -> str:
    """
    Recursively extract email body from payload.

    Prioritizes text/plain, falls back to text/html.

    Args:
        payload: Email payload from Gmail API

    Returns:
        Plain text body content
    """
    body = ""

    if 'parts' in payload:
        # Multi-part message - recurse
        for part in payload['parts']:
            body += _extract_body(part)
    elif 'body' in payload and 'data' in payload['body']:
        # Single part message
        mime_type = payload.get('mimeType', '')
        data = payload['body']['data']
        text = base64.urlsafe_b64decode(data).decode('utf-8', errors='replace')

        if 'text/plain' in mime_type:
            body += text
        elif 'text/html' in mime_type and not body:
            # Only use HTML if no plain text available
            body += text

    return body


def create_draft_url(
    to: str = "",
    subject: str = "",
    body: str = "",
    cc: str = "",
    bcc: str = ""
) -> str:
    """
    Generate Gmail compose URL with pre-filled fields.

    NOTE: This does NOT require API permissions - just URL generation.

    Args:
        to: Recipient email
        subject: Email subject
        body: Email body (use \\n for line breaks)
        cc: CC recipients
        bcc: BCC recipients

    Returns:
        Gmail compose URL string
    """
    params = {}

    if to:
        params['to'] = to
    if subject:
        params['su'] = subject
    if body:
        # Convert \n to actual newlines
        params['body'] = body.replace('\\n', '\n')
    if cc:
        params['cc'] = cc
    if bcc:
        params['bcc'] = bcc

    if not params:
        return ""

    query_string = urllib.parse.urlencode(params)
    return f"https://mail.google.com/mail/?view=cm&{query_string}"


def get_user_profile(gmail_service) -> Dict[str, Any]:
    """
    Get Gmail user profile information.

    Args:
        gmail_service: Authenticated Gmail API service

    Returns:
        Dictionary with email, messagesTotal, threadsTotal
    """
    try:
        profile = gmail_service.users().getProfile(userId='me').execute()
        return {
            'email': profile.get('emailAddress', 'Unknown'),
            'total_messages': profile.get('messagesTotal', 0),
            'total_threads': profile.get('threadsTotal', 0),
            'history_id': profile.get('historyId', 'Unknown')
        }
    except Exception as e:
        print(f"Failed to get profile: {e}")
        return {}
```

### Gmail Search Operators Reference

```
# Basic Operators
from:sender@email.com       - Emails from specific sender
to:recipient@email.com      - Emails to specific recipient
cc:person@email.com         - Emails where person is CC'd
subject:keyword             - Subject contains keyword
"exact phrase"              - Exact phrase match

# Date Operators
after:2024/01/01           - After date (YYYY/MM/DD)
before:2024/12/31          - Before date
older_than:7d              - Older than 7 days (d=days, m=months, y=years)
newer_than:3m              - Newer than 3 months

# Location Operators
in:inbox                   - In inbox
in:sent                    - In sent folder
in:trash                   - In trash
in:spam                    - In spam
in:anywhere                - All mail including spam/trash

# Status Operators
is:unread                  - Unread emails
is:read                    - Read emails
is:starred                 - Starred emails
is:important               - Important emails
has:attachment             - Has attachments

# Label Operators
label:work                 - Has specific label
-label:processed           - Does NOT have label

# Combining Operators
from:boss@work.com subject:urgent          - AND (implicit)
{from:boss@work.com from:manager@work.com} - OR
-from:newsletter@spam.com                   - NOT
(from:team@work.com OR from:client@work.com) subject:project
```

---

## Email Correlation Engine

The email correlation engine matches emails to goals/tasks using multiple strategies with confidence scoring.

### Core Correlator Class

```python
"""
Email Correlator for Goal-Based Analysis

Correlates Gmail emails with goals/objectives using:
- Jira ticket matching
- Keyword extraction and matching
- Confidence scoring (high/medium/low)
- Topic clustering for unmatched emails
"""

import re
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional, Any
from collections import defaultdict

logger = logging.getLogger(__name__)


class EmailCorrelator:
    """Correlates Gmail emails with goals/objectives."""

    def __init__(self, gmail_service, goals_data: List[Dict[str, Any]]):
        """
        Initialize email correlator.

        Args:
            gmail_service: Authenticated Gmail API service object
            goals_data: List of goal dictionaries with 'Goal' key
        """
        self.gmail_service = gmail_service
        self.goals_data = goals_data

    def search_emails_for_person(
        self,
        person_name: str,
        person_email: Optional[str] = None,
        alias_email: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        max_results: int = 500
    ) -> List[Dict[str, Any]]:
        """
        Search emails where a person is mentioned or is a participant.

        Args:
            person_name: Full name of person
            person_email: Primary email address (optional but improves accuracy)
            alias_email: Alias email address (optional)
            start_date: Start date for search
            end_date: End date for search
            max_results: Maximum emails to retrieve

        Returns:
            List of email dictionaries with metadata and content
        """
        try:
            query_parts = []

            # Build email address filters (most accurate)
            email_filters = []
            if person_email:
                email_filters.append(
                    f'(from:{person_email} OR to:{person_email} OR cc:{person_email})'
                )
            if alias_email and alias_email != person_email:
                email_filters.append(
                    f'(from:{alias_email} OR to:{alias_email} OR cc:{alias_email})'
                )

            if email_filters:
                if len(email_filters) > 1:
                    query_parts.append(f'({" OR ".join(email_filters)})')
                else:
                    query_parts.append(email_filters[0])

            # Also search by name (catches mentions)
            if person_name:
                query_parts.append(f'"{person_name}"')

            # Combine with OR
            if len(query_parts) > 1:
                name_or_email = f'({" OR ".join(query_parts)})'
            elif query_parts:
                name_or_email = query_parts[0]
            else:
                logger.warning("No search criteria provided")
                return []

            # Add date range
            date_filters = []
            if start_date:
                date_filters.append(f'after:{start_date.strftime("%Y/%m/%d")}')
            if end_date:
                date_filters.append(f'before:{end_date.strftime("%Y/%m/%d")}')

            if date_filters:
                query = f'{name_or_email} {" ".join(date_filters)}'
            else:
                query = name_or_email

            logger.info(f"Gmail search query: {query}")

            # Execute search
            results = self.gmail_service.users().messages().list(
                userId='me',
                q=query,
                maxResults=min(max_results, 500)
            ).execute()

            message_ids = results.get('messages', [])

            if not message_ids:
                return []

            # Fetch full details for each message
            emails = []
            for msg in message_ids:
                email_data = self._get_email_details(msg['id'])
                if email_data:
                    emails.append(email_data)

            return emails

        except Exception as e:
            logger.error(f"Failed to search emails: {e}")
            return []

    def _get_email_details(self, message_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed information for a specific email."""
        try:
            import base64
            from email.utils import parsedate_to_datetime

            message = self.gmail_service.users().messages().get(
                userId='me',
                id=message_id,
                format='full'
            ).execute()

            headers = message.get('payload', {}).get('headers', [])
            result = {
                'id': message_id,
                'subject': 'No Subject',
                'from': 'Unknown',
                'to': 'Unknown',
                'cc': '',
                'date': 'Unknown',
                'date_obj': None,
                'body': '',
                'jira_tickets': [],
                'url': f'https://mail.google.com/mail/u/0/#inbox/{message_id}'
            }

            for header in headers:
                name = header.get('name', '').lower()
                value = header.get('value', '')
                if name == 'subject':
                    result['subject'] = value
                elif name == 'from':
                    result['from'] = value
                elif name == 'to':
                    result['to'] = value
                elif name == 'cc':
                    result['cc'] = value
                elif name == 'date':
                    result['date'] = value
                    try:
                        result['date_obj'] = parsedate_to_datetime(value)
                    except:
                        pass

            # Extract body
            result['body'] = self._extract_body(message['payload'])

            # Extract Jira tickets from subject and body
            result['jira_tickets'] = self._extract_jira_tickets(
                result['subject'] + ' ' + result['body']
            )

            return result

        except Exception as e:
            logger.error(f"Failed to get email details: {e}")
            return None

    def _extract_body(self, payload: Dict[str, Any]) -> str:
        """Recursively extract plain text body from email payload."""
        import base64

        body = ""

        if 'parts' in payload:
            for part in payload['parts']:
                body += self._extract_body(part)
        elif 'body' in payload and 'data' in payload['body']:
            mime_type = payload.get('mimeType', '')
            if 'text/plain' in mime_type:
                try:
                    data = payload['body']['data']
                    body += base64.urlsafe_b64decode(data).decode('utf-8', errors='replace')
                except:
                    pass

        return body

    def _extract_jira_tickets(self, text: str) -> List[str]:
        """
        Extract Jira ticket references from text.

        Pattern: PROJECT-NUMBER (e.g., AIMT-123, RHEL-456)
        """
        pattern = r'\b([A-Z]{2,10}-\d+)\b'
        matches = re.findall(pattern, text)
        return list(set(matches))

    def match_email_to_goals(
        self,
        email: Dict[str, Any],
        goals: List[Dict[str, Any]]
    ) -> List[Tuple[Dict[str, Any], str, str]]:
        """
        Match an email to goals using multiple strategies.

        Args:
            email: Email dictionary
            goals: List of goal dictionaries

        Returns:
            List of tuples: (goal, confidence_level, match_reason)
            confidence_level: 'high', 'medium', or 'low'
        """
        matches = []

        for goal in goals:
            result = self._calculate_match_confidence(email, goal)
            if result:
                confidence, reason = result
                matches.append((goal, confidence, reason))

        return matches

    def _calculate_match_confidence(
        self,
        email: Dict[str, Any],
        goal: Dict[str, Any]
    ) -> Optional[Tuple[str, str]]:
        """
        Calculate confidence level for email-goal match.

        Confidence Criteria:
        - HIGH: Jira ticket match OR 2+ keywords in subject
        - MEDIUM: 1 keyword in subject OR 3+ keywords in body
        - LOW: 1+ keywords in body

        Returns:
            Tuple of (confidence_level, match_reason) or None
        """
        goal_text = str(goal.get('Goal', '')).lower()
        email_subject = email.get('subject', '').lower()
        email_body = email.get('body', '').lower()
        email_jira_tickets = email.get('jira_tickets', [])

        # Extract Jira tickets from goal
        goal_jira_tickets = self._extract_jira_tickets(str(goal.get('Goal', '')))

        # Extract keywords from goal
        goal_keywords = self._extract_keywords(goal_text)

        # Count keyword matches
        subject_matches = sum(1 for kw in goal_keywords if kw in email_subject)
        body_matches = sum(1 for kw in goal_keywords if kw in email_body)

        # Get matched keywords for reporting
        matched_subject_kws = [kw for kw in goal_keywords if kw in email_subject]
        matched_body_kws = [kw for kw in goal_keywords if kw in email_body]

        # HIGH CONFIDENCE: Jira ticket match
        if email_jira_tickets and goal_jira_tickets:
            common_tickets = set(email_jira_tickets) & set(goal_jira_tickets)
            if common_tickets:
                return ('high', f"References Jira ticket(s): {', '.join(common_tickets)}")

        # HIGH CONFIDENCE: Multiple keywords in subject
        if subject_matches >= 2:
            return ('high', f"Subject contains keywords: {', '.join(matched_subject_kws[:3])}")

        # MEDIUM CONFIDENCE: Single keyword in subject
        if subject_matches >= 1:
            return ('medium', f"Subject mentions '{matched_subject_kws[0]}'")

        # MEDIUM CONFIDENCE: Multiple keywords in body
        if body_matches >= 3:
            return ('medium', f"Body contains keywords: {', '.join(matched_body_kws[:3])}")

        # LOW CONFIDENCE: Some keyword overlap
        if body_matches >= 1:
            return ('low', f"Mentions '{', '.join(matched_body_kws[:2])}'")

        return None

    def _extract_keywords(self, text: str, min_length: int = 4) -> List[str]:
        """
        Extract meaningful keywords from text.

        Filters out common stop words and short words.
        """
        stop_words = {
            'the', 'and', 'for', 'that', 'this', 'with', 'from', 'have',
            'will', 'been', 'were', 'are', 'was', 'has', 'had', 'what',
            'when', 'where', 'which', 'who', 'why', 'how', 'their', 'there',
            'these', 'those', 'than', 'then', 'them', 'they', 'would', 'should',
            'could', 'about', 'into', 'through', 'during', 'before', 'after'
        }

        words = re.findall(r'\b[a-z0-9]+\b', text.lower())

        keywords = [w for w in words if len(w) >= min_length and w not in stop_words]

        # Return unique keywords (preserving order)
        seen = set()
        unique = []
        for kw in keywords:
            if kw not in seen:
                seen.add(kw)
                unique.append(kw)

        return unique[:10]  # Top 10 keywords

    def generate_evidence_summary(
        self,
        goals: List[Dict[str, Any]],
        emails: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate email evidence summary organized by goals.

        Returns:
            Dictionary with:
            - goal_emails: Dict mapping goal_id to {high: [], medium: [], low: []}
            - unmatched_emails: List of emails not matching any goal
            - goals_without_emails: List of goals with no email activity
            - total_emails: Total emails analyzed
            - matched_emails: Count of matched emails
            - unmatched_count: Count of unmatched emails
        """
        goal_emails = defaultdict(lambda: {'high': [], 'medium': [], 'low': []})
        unmatched_emails = []

        for email in emails:
            matches = self.match_email_to_goals(email, goals)

            if matches:
                for goal, confidence, reason in matches:
                    goal_id = goal.get('Goal', '')[:100]
                    goal_emails[goal_id][confidence].append({
                        'email': email,
                        'goal': goal,
                        'reason': reason
                    })
            else:
                unmatched_emails.append(email)

        # Find goals with no emails
        goals_with_emails = set(goal_emails.keys())
        all_goal_ids = {goal.get('Goal', '')[:100] for goal in goals}
        goals_without_emails = list(all_goal_ids - goals_with_emails)

        return {
            'goal_emails': dict(goal_emails),
            'unmatched_emails': unmatched_emails,
            'goals_without_emails': goals_without_emails,
            'total_emails': len(emails),
            'matched_emails': len(emails) - len(unmatched_emails),
            'unmatched_count': len(unmatched_emails)
        }

    def cluster_emails_by_topic(
        self,
        emails: List[Dict[str, Any]],
        min_cluster_size: int = 2
    ) -> List[Dict[str, Any]]:
        """
        Cluster emails by common keywords/topics.

        Useful for analyzing unmatched emails to find patterns.

        Args:
            emails: List of email dictionaries
            min_cluster_size: Minimum emails to form a cluster

        Returns:
            List of cluster dictionaries with 'topic', 'count', 'emails'
        """
        if not emails:
            return []

        # Extract keywords from each email
        email_keywords = []
        for email in emails:
            text = f"{email.get('subject', '')} {email.get('body', '')[:500]}".lower()
            keywords = set(self._extract_keywords(text))
            email_keywords.append({'email': email, 'keywords': keywords})

        # Find clusters by keyword overlap
        clusters = []
        used = set()

        for i, item in enumerate(email_keywords):
            if i in used:
                continue

            cluster_emails = [item['email']]
            cluster_keywords = item['keywords'].copy()
            used.add(i)

            # Find similar emails
            for j, other in enumerate(email_keywords):
                if j <= i or j in used:
                    continue

                overlap = cluster_keywords & other['keywords']
                if len(overlap) >= 2:
                    cluster_emails.append(other['email'])
                    cluster_keywords.update(other['keywords'])
                    used.add(j)

            if len(cluster_emails) >= min_cluster_size:
                topic = ' '.join(list(cluster_keywords)[:3])
                clusters.append({
                    'topic': topic,
                    'count': len(cluster_emails),
                    'emails': cluster_emails
                })

        clusters.sort(key=lambda c: c['count'], reverse=True)
        return clusters
```

### Confidence Scoring Summary

| Confidence | Criteria | Use Case |
|------------|----------|----------|
| **HIGH** | Jira ticket in both email and goal | Direct work reference |
| **HIGH** | 2+ goal keywords in email subject | Clear topic match |
| **MEDIUM** | 1 keyword in subject | Likely related |
| **MEDIUM** | 3+ keywords in body | Contextual match |
| **LOW** | 1+ keywords in body | Possible relation |
| **NONE** | No keyword overlap | Unrelated |

---

## Integration Patterns

### Basic Gmail Integration

```python
"""
Example: Basic Gmail Integration
"""

def get_recent_emails(query: str = "", max_results: int = 10):
    """Get recent emails with optional search filter."""

    # Initialize authentication
    auth = GoogleDriveAuth(
        credentials_file='credentials.json',
        token_file='gdrive_token.json'
    )

    if not auth.authenticate():
        print("Authentication failed")
        return []

    # Build Gmail service
    gmail_service = build('gmail', 'v1', credentials=auth.credentials)

    # Search emails
    return search_gmail(gmail_service, query, max_results)


# Usage
emails = get_recent_emails("from:boss@company.com", max_results=20)
for email in emails:
    print(f"Subject: {email['subject']}")
    print(f"From: {email['from']}")
    print(f"Date: {email['date']}")
    print("---")
```

### Email Correlation Integration

```python
"""
Example: Email Correlation with Goals
"""

def correlate_emails_with_goals(
    person_name: str,
    person_email: str,
    goals: List[Dict[str, Any]],
    days_back: int = 90
):
    """Correlate a person's emails with their goals."""

    # Initialize authentication
    auth = GoogleDriveAuth(
        credentials_file='credentials.json',
        token_file='gdrive_token.json'
    )

    if not auth.authenticate():
        print("Authentication failed")
        return None

    # Build Gmail service
    gmail_service = build('gmail', 'v1', credentials=auth.credentials)

    # Calculate date range
    from datetime import datetime, timedelta
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days_back)

    # Initialize correlator
    correlator = EmailCorrelator(gmail_service, goals)

    # Search emails
    print(f"Searching emails for {person_name}...")
    emails = correlator.search_emails_for_person(
        person_name=person_name,
        person_email=person_email,
        start_date=start_date,
        end_date=end_date,
        max_results=500
    )

    if not emails:
        print("No emails found")
        return None

    print(f"Found {len(emails)} emails")

    # Generate evidence summary
    summary = correlator.generate_evidence_summary(goals, emails)

    print(f"Matched: {summary['matched_emails']} emails")
    print(f"Unmatched: {summary['unmatched_count']} emails")
    print(f"Goals without activity: {len(summary['goals_without_emails'])}")

    return summary


# Usage
goals = [
    {'Goal': 'Complete AIMT-123 email integration feature'},
    {'Goal': 'Improve team documentation'},
    {'Goal': 'Quarterly planning and roadmap review'}
]

summary = correlate_emails_with_goals(
    person_name="Jane Doe",
    person_email="jane.doe@company.com",
    goals=goals,
    days_back=90
)

# Access results
for goal_id, matches in summary['goal_emails'].items():
    print(f"\nGoal: {goal_id[:50]}...")
    print(f"  High confidence: {len(matches['high'])} emails")
    print(f"  Medium confidence: {len(matches['medium'])} emails")
    print(f"  Low confidence: {len(matches['low'])} emails")
```

### Graceful Degradation Pattern

```python
"""
Example: Graceful degradation when Gmail is unavailable
"""

def get_data_with_optional_email_correlation(
    person_name: str,
    goals: List[Dict[str, Any]]
):
    """Get data with optional email correlation (graceful fallback)."""

    email_data = None

    try:
        # Check if credentials exist
        credentials_file = Path('credentials.json')
        token_file = Path('gdrive_token.json')

        if not credentials_file.exists():
            print("Gmail credentials not found - skipping email correlation")
        elif not token_file.exists():
            print("Gmail not authorized - skipping email correlation")
        else:
            # Attempt authentication
            auth = GoogleDriveAuth(
                credentials_file=str(credentials_file),
                token_file=str(token_file)
            )

            if auth.authenticate():
                gmail_service = build('gmail', 'v1', credentials=auth.credentials)

                # Perform correlation
                correlator = EmailCorrelator(gmail_service, goals)
                emails = correlator.search_emails_for_person(
                    person_name=person_name,
                    start_date=datetime.now() - timedelta(days=90),
                    end_date=datetime.now()
                )

                if emails:
                    email_data = correlator.generate_evidence_summary(goals, emails)
                    print(f"Email correlation complete: {email_data['matched_emails']} matches")
            else:
                print("Gmail authentication failed - skipping email correlation")

    except Exception as e:
        print(f"Email correlation failed: {e}")
        print("Continuing without email data...")

    # Return data regardless of email correlation success
    return {
        'goals': goals,
        'email_evidence': email_data  # May be None
    }
```

---

## Configuration Requirements

### Google Cloud Console Setup

1. **Create a Google Cloud Project**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing

2. **Enable Required APIs**
   - Gmail API
   - Google Drive API (if also using Drive features)

3. **Create OAuth 2.0 Credentials**
   - Go to APIs & Services > Credentials
   - Create OAuth 2.0 Client ID
   - Application type: **Desktop application**
   - Download as `credentials.json`

4. **Configure OAuth Consent Screen**
   - Set up consent screen (can be internal for organization use)
   - Add required scopes:
     - `https://www.googleapis.com/auth/gmail.readonly`
     - `https://www.googleapis.com/auth/drive.readonly` (if using Drive)

### File Structure

```
project/
├── credentials.json        # OAuth client credentials (from Google Cloud Console)
├── gdrive_token.json       # User authorization token (generated after first auth)
├── auth/
│   ├── __init__.py
│   ├── simple_auth.py      # Core authentication class
│   └── token_manager.py    # Advanced token management
├── gmail/
│   ├── __init__.py
│   ├── operations.py       # Gmail search, read, draft functions
│   └── correlator.py       # Email correlation engine
└── main.py                 # Application entry point
```

### Security Best Practices

```python
# File permissions for token storage
import os
from pathlib import Path

def secure_save_token(token_path: str, content: str):
    """Save token with secure permissions."""
    path = Path(token_path)

    # Write token
    with open(path, 'w') as f:
        f.write(content)

    # Set secure permissions (owner read/write only)
    path.chmod(0o600)

# Never commit tokens to version control
# .gitignore should include:
# gdrive_token.json
# *.pickle
# token_backup.json
```

### Environment Detection

```python
def detect_environment() -> str:
    """Detect if running in container or desktop environment."""
    import os

    # Check for container indicators
    if os.path.exists('/.dockerenv'):
        return 'container'

    if os.environ.get('HOSTNAME') == 'aimt':
        return 'container'

    if os.path.exists('/workspace'):
        return 'container'

    if 'CONTAINER' in os.environ.get('TERM_PROGRAM', ''):
        return 'container'

    return 'desktop'
```

---

## Complete Code Reference

### Dependencies

```txt
# requirements.txt
google-api-python-client>=2.0.0
google-auth>=2.0.0
google-auth-oauthlib>=0.5.0
google-auth-httplib2>=0.1.0
```

### Installation

```bash
pip install google-api-python-client google-auth google-auth-oauthlib google-auth-httplib2
```

### Quick Start

```python
"""
Quick Start: Gmail Agent Setup
"""

from pathlib import Path

# 1. Place credentials.json in your project directory

# 2. Initialize and authenticate
auth = GoogleDriveAuth(
    credentials_file='credentials.json',
    token_file='gdrive_token.json'
)

# 3. First-time auth will open browser for authorization
if auth.authenticate():
    print("Authentication successful!")

    # 4. Build Gmail service
    gmail_service = build('gmail', 'v1', credentials=auth.credentials)

    # 5. Get user profile
    profile = gmail_service.users().getProfile(userId='me').execute()
    print(f"Authenticated as: {profile.get('emailAddress')}")

    # 6. Search emails
    results = search_gmail(gmail_service, "is:unread", max_results=5)
    for email in results:
        print(f"- {email['subject']}")
else:
    print("Authentication failed")
```

---

## GTD Email Categorization

The system includes a GTD (Getting Things Done) email categorization workflow that helps triage inbox emails using AI-assisted labeling.

### GTD Labels

| Label | Purpose | Can Combine |
|-------|---------|-------------|
| **GTD/Urgent** | Needs immediate attention | Yes (with Action/Reply/Delegate) |
| **GTD/Action** | Requires user to DO something | With Urgent |
| **GTD/Reply Needed** | Needs written response | With Urgent |
| **GTD/Waiting For** | Tracking - waiting on someone else | No |
| **GTD/Delegate** | Should be handed off to team | With Urgent |
| **GTD/Review** | Read/digest, no action needed | No |
| **GTD/Ignore** | Safe to skip or archive | No |
| **GTD/Needs Review** | AI confidence too low | Fallback |

### Setup

1. **Create GTD labels** (run once):
   ```bash
   python -m src.cli setup-labels
   ```

2. **Configure your network** (optional but recommended):
   Edit `config/network.yaml` to add:
   - Important contacts with relationships
   - Domain-level rules
   - Priority keywords

### Categorization Workflow

**Via MCP (Interactive in Cursor):**

1. List uncategorized emails:
   ```
   gmail_list_uncategorized
   ```

2. Read an email to understand context:
   ```
   gmail_read <message_id>
   ```

3. Apply appropriate GTD label(s):
   ```
   gmail_apply_gtd_label <message_id> ["GTD/Action"]
   ```
   or for urgent items:
   ```
   gmail_apply_gtd_label <message_id> ["GTD/Urgent", "GTD/Action"]
   ```

**Via CLI:**

```bash
# List uncategorized emails
python -m src.cli uncategorized

# Apply a label
python -m src.cli apply-label <message_id> Action
```

### MCP Tools for GTD

| Tool | Description |
|------|-------------|
| `gmail_setup_gtd_labels` | Create GTD labels (run once) |
| `gmail_list_uncategorized` | List emails without GTD labels |
| `gmail_apply_gtd_label` | Apply one or more GTD labels |
| `gmail_remove_gtd_label` | Remove GTD labels |
| `gmail_get_labels` | List all labels |

### AI Categorization Prompt

The `prompts/categorize.md` file contains a prompt template for AI-assisted categorization. When categorizing emails, the AI:

1. Analyzes email content, sender, and context
2. Considers the user's network config (`config/network.yaml`)
3. Assigns confidence level (High/Medium/Low)
4. Applies "Needs Review" if confidence is below 60%

### Configuration Files

- **`config/config.yaml`**: VIP senders, keywords, scoring weights
- **`config/network.yaml`**: Contact relationships, domain rules, priority keywords
- **`prompts/categorize.md`**: AI prompt template for categorization

---

## Summary

This document provides a complete implementation reference for building a Gmail-integrated AI email agent. Key components include:

1. **Authentication**: OAuth 2.0 with desktop and container support
2. **Token Management**: Automatic refresh and secure storage
3. **Gmail Operations**: Search, read, and draft creation
4. **Email Correlation**: Multi-strategy matching with confidence scoring
5. **Integration Patterns**: Graceful degradation and error handling
6. **GTD Categorization**: AI-assisted email triage with Gmail labels

The code patterns are designed to be:
- **Modular**: Each component can be used independently
- **Resilient**: Graceful fallback when services unavailable
- **Secure**: Proper token handling and permissions
- **Flexible**: Works in desktop and container environments

For implementation in a new project, start with the authentication module, then add Gmail operations, and optionally integrate the correlation engine based on your use case.

