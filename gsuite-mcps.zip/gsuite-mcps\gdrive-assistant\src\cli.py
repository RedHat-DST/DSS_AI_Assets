"""
Google Drive Assistant CLI.

Command-line interface for Google Drive, Docs, Sheets, and Slides operations.

Usage:
    python -m src.cli list [folder_id]        # List files
    python -m src.cli search "query"          # Search files
    python -m src.cli download <id> [path]    # Download file
    python -m src.cli upload <path> [folder]  # Upload file
    python -m src.cli mkdir <name> [parent]   # Create folder
    python -m src.cli share <id> <email>      # Share file
    python -m src.cli docs create "Title"     # Create Google Doc
    python -m src.cli sheets create "Title"   # Create Google Sheet
    python -m src.cli auth_status             # Check auth status
"""

import sys
from pathlib import Path
from typing import Optional

import click

from .auth import get_auth, DriveAuth
from .drive_ops import (
    list_files, search_files, get_file_metadata, download_file, upload_file,
    create_folder, move_file, copy_file, delete_file, share_file, get_share_link
)
from .docs_ops import (
    create_doc, read_doc, read_doc_as_markdown, export_doc, append_to_doc,
    create_doc_from_file, list_tabs, read_tab, read_tab_as_markdown, export_tab,
    insert_content_at, create_tab, update_tab, delete_tab
)
from .sheets_ops import (
    create_spreadsheet, read_range, write_range, get_spreadsheet_info, export_csv
)
from .slides_ops import (
    create_presentation, get_presentation, add_slide, export_pdf as slides_export_pdf
)


def format_size(size: Optional[int]) -> str:
    """Format file size for display."""
    if not size:
        return "-"
    if size >= 1024 * 1024 * 1024:
        return f"{size / (1024*1024*1024):.1f} GB"
    elif size >= 1024 * 1024:
        return f"{size / (1024*1024):.1f} MB"
    elif size >= 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size} B"


def truncate(text: str, length: int) -> str:
    """Truncate text to specified length."""
    if len(text) <= length:
        return text
    return text[:length - 3] + "..."


@click.group()
@click.pass_context
def cli(ctx):
    """Google Drive Assistant - Manage files, docs, sheets, and slides."""
    ctx.ensure_object(dict)


# =============================================================================
# Drive Commands
# =============================================================================

@cli.command()
@click.argument('folder_id', required=False)
@click.option('-n', '--num', default=50, help='Number of files to show')
@click.option('-t', '--type', 'file_type', help='Filter by type: document, spreadsheet, presentation, folder')
@click.pass_context
def list(ctx, folder_id: Optional[str], num: int, file_type: Optional[str]):
    """List files in Drive or a specific folder."""
    click.echo(click.style("\n📁 Google Drive Files", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        file_types = [file_type] if file_type else None
        files = list_files(folder_id=folder_id, file_types=file_types, max_results=num)

        if not files:
            click.echo("No files found.")
            return

        click.echo(f"Found {len(files)} files:\n")
        
        for f in files:
            icon = {'folder': '📁', 'document': '📄', 'spreadsheet': '📊', 
                    'presentation': '📽️', 'file': '📎'}.get(f['type'], '📎')
            name = truncate(f['name'], 45)
            size = format_size(f['size']) if f['size'] else "-"
            shared = "🔗" if f['shared'] else ""
            
            click.echo(f"{icon} {name.ljust(47)} {size.rjust(8)} {shared}")
            click.echo(click.style(f"   ID: {f['id']}", fg='bright_black'))

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('query')
@click.option('-n', '--num', default=25, help='Number of results')
@click.pass_context
def search(ctx, query: str, num: int):
    """Search for files in Drive."""
    click.echo(click.style(f"\n🔍 Searching: {query}", fg='green', bold=True))
    click.echo()

    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        files = search_files(query, max_results=num)

        if not files:
            click.echo("No files found.")
            return

        click.echo(f"Found {len(files)} files:\n")
        
        for f in files:
            icon = {'folder': '📁', 'document': '📄', 'spreadsheet': '📊', 
                    'presentation': '📽️', 'file': '📎'}.get(f['type'], '📎')
            
            click.echo(f"{icon} {f['name']}")
            click.echo(click.style(f"   ID: {f['id']}  Type: {f['type']}", fg='bright_black'))
            if f['web_link']:
                click.echo(click.style(f"   URL: {f['web_link']}", fg='cyan'))
            click.echo()

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('file_id')
@click.argument('local_path', required=False)
@click.option('-f', '--format', 'export_format', help='Export format: pdf, docx, xlsx, csv, txt')
@click.pass_context
def download(ctx, file_id: str, local_path: Optional[str], export_format: Optional[str]):
    """Download a file from Drive."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = download_file(file_id, local_path, export_format)
        
        if result:
            click.echo(click.style(f"✅ Downloaded: {result}", fg='green'))
        else:
            click.echo(click.style("❌ Download failed", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('local_path')
@click.argument('folder_id', required=False)
@click.option('--name', help='Name for the file in Drive')
@click.option('--convert', is_flag=True, help='Convert to Google format')
@click.pass_context
def upload(ctx, local_path: str, folder_id: Optional[str], name: Optional[str], convert: bool):
    """Upload a file to Drive."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = upload_file(local_path, folder_id, name, convert_to_google=convert)
        
        if result:
            click.echo(click.style("\n✅ File uploaded!", fg='green'))
            click.echo(f"Name: {result['name']}")
            click.echo(f"ID: {result['id']}")
            if result['web_link']:
                click.echo(f"URL: {result['web_link']}")
        else:
            click.echo(click.style("❌ Upload failed", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('name')
@click.argument('parent_id', required=False)
@click.pass_context
def mkdir(ctx, name: str, parent_id: Optional[str]):
    """Create a new folder in Drive."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = create_folder(name, parent_id)
        
        if result:
            click.echo(click.style("\n✅ Folder created!", fg='green'))
            click.echo(f"Name: {result['name']}")
            click.echo(f"ID: {result['id']}")
            if result['web_link']:
                click.echo(f"URL: {result['web_link']}")
        else:
            click.echo(click.style("❌ Failed to create folder", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('file_id')
@click.argument('email')
@click.option('--role', default='reader', help='Permission: reader, writer, commenter')
@click.option('--message', help='Message to include in notification')
@click.pass_context
def share(ctx, file_id: str, email: str, role: str, message: Optional[str]):
    """Share a file with another user."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        if share_file(file_id, email, role, message=message):
            click.echo(click.style(f"✅ Shared with {email} as {role}", fg='green'))
        else:
            click.echo(click.style("❌ Share failed", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@cli.command()
@click.argument('file_id')
@click.pass_context
def info(ctx, file_id: str):
    """Get detailed information about a file."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        info = get_file_metadata(file_id)
        
        if info:
            click.echo(click.style("\n📋 File Information", fg='green', bold=True))
            click.echo()
            click.echo(f"Name:     {info['name']}")
            click.echo(f"ID:       {info['id']}")
            click.echo(f"Type:     {info['type']}")
            click.echo(f"MIME:     {info['mime_type']}")
            if info['size']:
                click.echo(f"Size:     {format_size(info['size'])}")
            click.echo(f"Created:  {info['created_time']}")
            click.echo(f"Modified: {info['modified_time']}")
            click.echo(f"Owners:   {', '.join(info['owners'])}")
            click.echo(f"Shared:   {info['shared']}")
            if info['web_link']:
                click.echo(f"URL:      {info['web_link']}")
        else:
            click.echo(click.style("❌ File not found", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


# =============================================================================
# Docs Commands
# =============================================================================

@cli.group()
@click.pass_context
def docs(ctx):
    """Google Docs operations."""
    pass


@docs.command('create')
@click.argument('title')
@click.option('--from-md', 'md_file', help='Create from markdown file')
@click.option('--content', help='Initial content (markdown)')
@click.option('--folder', 'folder_id', help='Folder ID to create in')
@click.pass_context
def docs_create(ctx, title: str, md_file: Optional[str], content: Optional[str], folder_id: Optional[str]):
    """Create a new Google Doc."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        if md_file:
            result = create_doc_from_file(md_file, title, folder_id)
        else:
            result = create_doc(title, content, 'markdown', folder_id)
        
        if result:
            click.echo(click.style("\n✅ Document created!", fg='green'))
            click.echo(f"Title: {result['title']}")
            click.echo(f"ID:    {result['id']}")
            click.echo(f"URL:   {result['url']}")
        else:
            click.echo(click.style("❌ Failed to create document", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs.command('read')
@click.argument('doc_id_or_url', metavar='DOC_ID_OR_URL')
@click.option('--markdown', is_flag=True, help='Output as markdown')
@click.option('--tab', 'tab_id', help='Tab ID to read (optional if included in URL fragment)')
@click.option('--tab-index', type=int, help='Tab index (0-based)')
@click.pass_context
def docs_read(ctx, doc_id_or_url: str, markdown: bool, tab_id: Optional[str], tab_index: Optional[int]):
    """Read a Google Doc's content (or specific tab). Accepts document ID or full URL with optional tab fragment."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        # Check if reading a specific tab
        if tab_id or tab_index is not None:
            if markdown:
                content = read_tab_as_markdown(doc_id_or_url, tab_id=tab_id, tab_index=tab_index or 0)
                if content:
                    click.echo(content)
                else:
                    click.echo(click.style("❌ Failed to read tab", fg='red'))
                    sys.exit(1)
            else:
                result = read_tab(doc_id_or_url, tab_id=tab_id, tab_index=tab_index or 0)
                if result:
                    click.echo(click.style(f"\n📄 {result['title']} - {result['tab_title']}", fg='green', bold=True))
                    click.echo(f"Document ID: {result['id']}")
                    click.echo(f"Tab ID:      {result['tab_id'] or 'N/A'}")
                    click.echo(f"Tab Index:   {result['tab_index']}")
                    click.echo(f"URL:         {result['url']}")
                    click.echo(click.style("\n--- Tab Content ---\n", fg='bright_black'))
                    click.echo(result['text'])
                else:
                    click.echo(click.style("❌ Failed to read tab", fg='red'))
                    sys.exit(1)
        else:
            # Read entire document
            if markdown:
                content = read_doc_as_markdown(doc_id_or_url)
                if content:
                    click.echo(content)
                else:
                    click.echo(click.style("❌ Failed to read document", fg='red'))
                    sys.exit(1)
            else:
                result = read_doc(doc_id_or_url)
                if result:
                    click.echo(click.style(f"\n📄 {result['title']}", fg='green', bold=True))
                    click.echo(f"ID:  {result['id']}")
                    click.echo(f"URL: {result['url']}")
                    click.echo(click.style("\n--- Content ---\n", fg='bright_black'))
                    click.echo(result['text'])
                else:
                    click.echo(click.style("❌ Failed to read document", fg='red'))
                    sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs.command('export')
@click.argument('doc_id_or_url', metavar='DOC_ID_OR_URL')
@click.argument('local_path')
@click.option('-f', '--format', 'fmt', default='pdf', help='Format: pdf, docx, txt, html, md')
@click.option('--tab', 'tab_id', help='Tab ID to export (optional if included in URL fragment)')
@click.option('--tab-index', type=int, help='Tab index (0-based)')
@click.pass_context
def docs_export(ctx, doc_id_or_url: str, local_path: str, fmt: str, tab_id: Optional[str], tab_index: Optional[int]):
    """Export a Google Doc (or specific tab) to a file. Accepts document ID or full URL with optional tab fragment."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        # Check if exporting a specific tab
        if tab_id:
            result = export_tab(doc_id_or_url, tab_id=tab_id, local_path=local_path, format=fmt)
        elif tab_index is not None:
            # Get tab ID from index
            tabs = list_tabs(doc_id_or_url)
            if not tabs or tab_index >= len(tabs):
                click.echo(click.style(f"❌ Invalid tab index: {tab_index}", fg='red'))
                sys.exit(1)
            target_tab_id = tabs[tab_index]['tab_id']
            if not target_tab_id:
                click.echo(click.style("❌ Tab ID not available for this document", fg='red'))
                sys.exit(1)
            result = export_tab(doc_id_or_url, tab_id=target_tab_id, local_path=local_path, format=fmt)
        else:
            # Export entire document
            result = export_doc(doc_id_or_url, local_path, fmt)
        
        if result:
            click.echo(click.style(f"✅ Exported: {result}", fg='green'))
        else:
            click.echo(click.style("❌ Export failed", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs.command('tabs')
@click.argument('doc_id_or_url', metavar='DOC_ID_OR_URL')
@click.option('--no-children', is_flag=True, help='Exclude nested child tabs')
@click.pass_context
def docs_tabs(ctx, doc_id_or_url: str, no_children: bool):
    """List all tabs in a Google Doc. Accepts document ID or full URL."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        tabs = list_tabs(doc_id_or_url, include_children=not no_children)
        
        if not tabs:
            click.echo(click.style("❌ Failed to list tabs", fg='red'))
            sys.exit(1)

        click.echo(click.style(f"\n📑 Tabs in Document ({len(tabs)} total)\n", fg='green', bold=True))
        
        for tab in tabs:
            # Visual indicator of nesting level
            indent = "  " * tab['level']
            icon = "📑" if tab['level'] == 0 else "└─"
            
            click.echo(f"{indent}{icon} {tab['title']}")
            if tab['tab_id']:
                click.echo(click.style(f"{indent}   ID: {tab['tab_id']}", fg='bright_black'))
            click.echo(click.style(f"{indent}   Index: {tab['index']}", fg='bright_black'))

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs.group('tab')
def docs_tab():
    """Create, update, or delete tabs in a Google Doc."""
    pass


@docs_tab.command('create')
@click.argument('doc_id_or_url', metavar='DOC_ID_OR_URL')
@click.argument('title')
@click.option('--index', type=int, help='0-based index within parent (insert position)')
@click.option('--parent-tab', 'parent_tab_id', help='Parent tab ID for child tab')
@click.option('--icon', 'icon_emoji', help='Single emoji for tab icon')
@click.pass_context
def docs_tab_create(ctx, doc_id_or_url: str, title: str, index: Optional[int], parent_tab_id: Optional[str], icon_emoji: Optional[str]):
    """Create a new tab in a Google Doc. Use 'docs tabs DOC_ID' to list tab IDs."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)
        result = create_tab(doc_id_or_url, title=title, index=index, parent_tab_id=parent_tab_id, icon_emoji=icon_emoji)
        if result:
            click.echo(click.style(f"✅ Created tab: {title}", fg='green'))
            if result.get('tab_id'):
                click.echo(f"Tab ID: {result['tab_id']}")
            click.echo(f"URL: {result.get('url', '')}")
        else:
            click.echo(click.style("❌ Failed to create tab", fg='red'))
            sys.exit(1)
    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs_tab.command('update')
@click.argument('doc_id_or_url', metavar='DOC_ID_OR_URL')
@click.argument('tab_id')
@click.option('--title', help='New tab title')
@click.option('--icon', 'icon_emoji', help='New icon emoji')
@click.pass_context
def docs_tab_update(ctx, doc_id_or_url: str, tab_id: str, title: Optional[str], icon_emoji: Optional[str]):
    """Update a tab's title or icon. At least one of --title or --icon is required."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)
        if title is None and icon_emoji is None:
            click.echo(click.style("❌ Provide at least one of --title or --icon", fg='red'))
            sys.exit(1)
        result = update_tab(doc_id_or_url, tab_id=tab_id, title=title, icon_emoji=icon_emoji)
        if result:
            click.echo(click.style(f"✅ Updated tab: {tab_id}", fg='green'))
        else:
            click.echo(click.style("❌ Failed to update tab", fg='red'))
            sys.exit(1)
    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs_tab.command('delete')
@click.argument('doc_id_or_url', metavar='DOC_ID_OR_URL')
@click.argument('tab_id')
@click.option('--yes', '-y', is_flag=True, help='Skip confirmation')
@click.pass_context
def docs_tab_delete(ctx, doc_id_or_url: str, tab_id: str, yes: bool):
    """Delete a tab (and its child tabs) from a Google Doc."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)
        if not yes:
            click.confirm(f"Delete tab {tab_id}? Child tabs will be deleted too.", abort=True)
        result = delete_tab(doc_id_or_url, tab_id=tab_id)
        if result:
            click.echo(click.style(f"✅ Deleted tab: {tab_id}", fg='green'))
        else:
            click.echo(click.style("❌ Failed to delete tab", fg='red'))
            sys.exit(1)
    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@docs.command('insert')
@click.argument('doc_id')
@click.argument('content')
@click.option('--tab', 'tab_id', help='Tab ID to insert into')
@click.option('--index', type=int, help='Character index position')
@click.option('--search', 'search_text', help='Search for this text')
@click.option('--heading', help='Find this heading')
@click.option('--position', default='after', type=click.Choice(['before', 'after', 'end']), 
              help='Position relative to search/heading')
@click.option('--plain', is_flag=True, help='Insert as plain text (default: markdown)')
@click.pass_context
def docs_insert(ctx, doc_id: str, content: str, tab_id: Optional[str], 
                index: Optional[int], search_text: Optional[str], 
                heading: Optional[str], position: str, plain: bool):
    """Insert formatted content at a specific location in a Google Doc.
    
    Examples:
    
      # Insert at start of document
      python -m src.cli docs insert DOC_ID "## New Section"
      
      # Insert at specific index
      python -m src.cli docs insert DOC_ID "Some text" --index 150
      
      # Insert after heading
      python -m src.cli docs insert DOC_ID "New content" --heading "Introduction"
      
      # Insert after search text in specific tab
      python -m src.cli docs insert DOC_ID "Content" --search "TODO" --tab t.xyz123
    """
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        content_type = 'plain' if plain else 'markdown'
        
        result = insert_content_at(
            doc_id, 
            content, 
            content_type,
            tab_id=tab_id,
            index=index,
            search_text=search_text,
            heading=heading,
            position=position
        )
        
        if result:
            # Build descriptive message
            location_parts = []
            if index is not None:
                location_parts.append(f"at index {index}")
            elif search_text:
                location_parts.append(f"{position} '{search_text}'")
            elif heading:
                location_parts.append(f"{position} heading '{heading}'")
            else:
                location_parts.append("at start")
            
            if tab_id:
                location_parts.append(f"in tab {tab_id}")
            
            click.echo(click.style(f"✅ Content inserted {' '.join(location_parts)}", fg='green'))
        else:
            click.echo(click.style("❌ Failed to insert content", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


# =============================================================================
# Sheets Commands
# =============================================================================

@cli.group()
@click.pass_context
def sheets(ctx):
    """Google Sheets operations."""
    pass


@sheets.command('create')
@click.argument('title')
@click.option('--sheets', 'sheet_names', help='Comma-separated sheet names')
@click.option('--folder', 'folder_id', help='Folder ID to create in')
@click.pass_context
def sheets_create(ctx, title: str, sheet_names: Optional[str], folder_id: Optional[str]):
    """Create a new Google Sheets spreadsheet."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        names = sheet_names.split(',') if sheet_names else None
        result = create_spreadsheet(title, names, folder_id)
        
        if result:
            click.echo(click.style("\n✅ Spreadsheet created!", fg='green'))
            click.echo(f"Title:  {result['title']}")
            click.echo(f"ID:     {result['id']}")
            click.echo(f"URL:    {result['url']}")
            click.echo(f"Sheets: {', '.join(s['title'] for s in result['sheets'])}")
        else:
            click.echo(click.style("❌ Failed to create spreadsheet", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@sheets.command('read')
@click.argument('spreadsheet_id')
@click.argument('range_notation')
@click.pass_context
def sheets_read(ctx, spreadsheet_id: str, range_notation: str):
    """Read a range of cells from a spreadsheet."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        values = read_range(spreadsheet_id, range_notation)
        
        if values is not None:
            if not values:
                click.echo(f"Range {range_notation} is empty")
                return
            
            click.echo(click.style(f"\n📊 Data from {range_notation}\n", fg='green', bold=True))
            
            # Find max column widths
            col_widths = []
            for row in values:
                for i, cell in enumerate(row):
                    while len(col_widths) <= i:
                        col_widths.append(0)
                    col_widths[i] = max(col_widths[i], len(str(cell)))
            
            # Print data
            for row in values:
                line = ""
                for i, cell in enumerate(row):
                    width = min(col_widths[i], 30) if i < len(col_widths) else 10
                    line += str(cell).ljust(width + 2)
                click.echo(line)
        else:
            click.echo(click.style("❌ Failed to read range", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@sheets.command('info')
@click.argument('spreadsheet_id')
@click.pass_context
def sheets_info(ctx, spreadsheet_id: str):
    """Get information about a spreadsheet."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        info = get_spreadsheet_info(spreadsheet_id)
        
        if info:
            click.echo(click.style(f"\n📊 {info['title']}", fg='green', bold=True))
            click.echo()
            click.echo(f"ID:  {info['id']}")
            click.echo(f"URL: {info['url']}")
            click.echo(f"\nSheets ({len(info['sheets'])}):")
            
            for sheet in info['sheets']:
                click.echo(f"  • {sheet['title']} ({sheet['row_count']} rows × {sheet['column_count']} cols)")
        else:
            click.echo(click.style("❌ Failed to get spreadsheet info", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@sheets.command('export')
@click.argument('spreadsheet_id')
@click.argument('sheet_name')
@click.argument('local_path')
@click.pass_context
def sheets_export(ctx, spreadsheet_id: str, sheet_name: str, local_path: str):
    """Export a sheet to CSV."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = export_csv(spreadsheet_id, sheet_name, local_path)
        
        if result:
            click.echo(click.style(f"✅ Exported: {result}", fg='green'))
        else:
            click.echo(click.style("❌ Export failed", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


# =============================================================================
# Slides Commands
# =============================================================================

@cli.group()
@click.pass_context
def slides(ctx):
    """Google Slides operations."""
    pass


@slides.command('create')
@click.argument('title')
@click.option('--folder', 'folder_id', help='Folder ID to create in')
@click.pass_context
def slides_create(ctx, title: str, folder_id: Optional[str]):
    """Create a new Google Slides presentation."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = create_presentation(title, folder_id)
        
        if result:
            click.echo(click.style("\n✅ Presentation created!", fg='green'))
            click.echo(f"Title: {result['title']}")
            click.echo(f"ID:    {result['id']}")
            click.echo(f"URL:   {result['url']}")
        else:
            click.echo(click.style("❌ Failed to create presentation", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@slides.command('info')
@click.argument('presentation_id')
@click.pass_context
def slides_info(ctx, presentation_id: str):
    """Get information about a presentation."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        info = get_presentation(presentation_id)
        
        if info:
            click.echo(click.style(f"\n📽️ {info['title']}", fg='green', bold=True))
            click.echo()
            click.echo(f"ID:     {info['id']}")
            click.echo(f"URL:    {info['url']}")
            click.echo(f"Slides: {info['slide_count']}")
        else:
            click.echo(click.style("❌ Failed to get presentation info", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


@slides.command('export')
@click.argument('presentation_id')
@click.argument('local_path')
@click.pass_context
def slides_export(ctx, presentation_id: str, local_path: str):
    """Export a presentation to PDF."""
    try:
        auth = get_auth()
        if not auth.authenticate():
            click.echo(click.style("❌ Authentication failed", fg='red'))
            sys.exit(1)

        result = slides_export_pdf(presentation_id, local_path)
        
        if result:
            click.echo(click.style(f"✅ Exported: {result}", fg='green'))
        else:
            click.echo(click.style("❌ Export failed", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"❌ Error: {e}", fg='red'))
        sys.exit(1)


# =============================================================================
# Auth Commands
# =============================================================================

@cli.command()
@click.pass_context
def auth_status(ctx):
    """Check authentication status."""
    click.echo(click.style("\n🔐 Authentication Status", fg='green', bold=True))
    click.echo()

    auth = DriveAuth()

    if auth.token_file.exists():
        click.echo(f"Token file: {click.style('Found', fg='green')} ({auth.token_file})")
    else:
        click.echo(f"Token file: {click.style('Not found', fg='yellow')}")
        click.echo("  Run any command to start authentication.")

    if auth.credentials_file.exists():
        click.echo(f"Credentials: {click.style('Found', fg='green')}")
    else:
        click.echo(f"Credentials: {click.style('Not found', fg='red')}")
        click.echo("  Please follow SETUP.md to configure Google Cloud credentials.")
        return

    # Try to authenticate
    if auth.authenticate():
        click.echo(f"Status: {click.style('Authenticated', fg='green')}")
        email = auth.get_user_email()
        if email:
            click.echo(f"Account: {email}")
    else:
        click.echo(f"Status: {click.style('Not authenticated', fg='red')}")


def main():
    """Main entry point."""
    cli(obj={})


if __name__ == '__main__':
    main()

